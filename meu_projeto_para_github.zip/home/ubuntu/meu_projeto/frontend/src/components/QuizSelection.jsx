import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Brain, Building, Cog, Zap, Factory, Code, FlaskConical, Home } from 'lucide-react';

  const QuizSelection = ({ onSelectQuizType }) => {
  const handleBackToHome = () => {
    window.location.href = '/';
  };
  const quizTypes = [
    {
      id: 'civil',
      title: 'Engenharia Civil',
      description: 'Estruturas, fundações, materiais e construção',
      icon: Building,
      color: 'bg-blue-500',
      hoverColor: 'hover:bg-blue-600'
    },
    {
      id: 'arquitetura',
      title: 'Arquitetura',
      description: 'Projeto, design e planejamento urbano',
      icon: Building,
      color: 'bg-purple-500',
      hoverColor: 'hover:bg-purple-600'
    },
    {
      id: 'mecanica',
      title: 'Engenharia Mecânica',
      description: 'Máquinas, motores e sistemas mecânicos',
      icon: Cog,
      color: 'bg-orange-500',
      hoverColor: 'hover:bg-orange-600'
    },
    {
      id: 'eletrica',
      title: 'Engenharia Elétrica',
      description: 'Circuitos, energia e sistemas elétricos',
      icon: Zap,
      color: 'bg-yellow-500',
      hoverColor: 'hover:bg-yellow-600'
    },
    {
      id: 'producao',
      title: 'Engenharia de Produção',
      description: 'Processos, qualidade e gestão industrial',
      icon: Factory,
      color: 'bg-green-500',
      hoverColor: 'hover:bg-green-600'
    },
    {
      id: 'software',
      title: 'Engenharia de Software',
      description: 'Desenvolvimento, arquitetura e sistemas',
      icon: Code,
      color: 'bg-indigo-500',
      hoverColor: 'hover:bg-indigo-600'
    },
    {
      id: 'quimica',
      title: 'Engenharia Química',
      description: 'Processos químicos e transformações',
      icon: FlaskConical,
      color: 'bg-red-500',
      hoverColor: 'hover:bg-red-600'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-4">
            <Button 
              onClick={handleBackToHome}
              variant="outline"
              className="flex items-center space-x-2 mr-4"
            >
              <Home className="w-5 h-5" />
              <span>Início</span>
            </Button>
            <h1 className="text-4xl font-bold text-gray-800 flex items-center">
              <Brain className="w-10 h-10 mr-4 text-blue-600" />
              Quiz de Engenharia
            </h1>
          </div>
          <p className="text-xl text-gray-600">
            Escolha sua área de especialização e teste seus conhecimentos
          </p>
          <p className="text-lg text-gray-500 mt-2">
            50 perguntas de dificuldade crescente para cada área
          </p>
        </div>

        {/* Grid de seleção */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizTypes.map((quiz) => {
            const IconComponent = quiz.icon;
            return (
              <Card 
                key={quiz.id} 
                className="cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-lg border-2 hover:border-gray-300"
                onClick={() => onSelectQuizType(quiz.id)}
              >
                <CardHeader className="text-center pb-4">
                  <div className={`w-16 h-16 ${quiz.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <IconComponent className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-xl font-bold text-gray-800">
                    {quiz.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-gray-600 mb-6">
                    {quiz.description}
                  </p>
                  <Button 
                    className={`w-full ${quiz.color} ${quiz.hoverColor} text-white font-semibold py-3`}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectQuizType(quiz.id);
                    }}
                  >
                    Iniciar Quiz
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Informações adicionais */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="text-lg text-gray-800">Como Funciona</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="font-semibold text-gray-800 mb-2">Regras do Quiz</h3>
                <ul className="space-y-1 text-sm text-gray-600">
                  <li>• 50 perguntas de dificuldade crescente</li>
                  <li>• Acertou? Avança para a próxima pergunta</li>
                  <li>• Errou? O quiz reinicia do começo</li>
                  <li>• Seu progresso máximo é salvo automaticamente</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-gray-800 mb-2">Níveis de Dificuldade</h3>
                <ul className="space-y-1 text-sm text-gray-600">
                  <li>• <span className="inline-block w-3 h-3 bg-green-500 rounded mr-2"></span>Básico (1-10)</li>
                  <li>• <span className="inline-block w-3 h-3 bg-yellow-500 rounded mr-2"></span>Intermediário (11-20)</li>
                  <li>• <span className="inline-block w-3 h-3 bg-orange-500 rounded mr-2"></span>Avançado (21-35)</li>
                  <li>• <span className="inline-block w-3 h-3 bg-red-500 rounded mr-2"></span>Especialista (36-45)</li>
                  <li>• <span className="inline-block w-3 h-3 bg-purple-500 rounded mr-2"></span>Mestre (46-50)</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default QuizSelection;


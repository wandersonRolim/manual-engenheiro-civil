import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { 
  Users, 
  UserCheck, 
  UserX, 
  Calendar, 
  Trash2, 
  Plus, 
  Minus,
  Shield,
  Clock,
  Mail,
  Phone,
  ArrowLeft,
  RefreshCw,
  BarChart3
} from 'lucide-react'

const AdminPanel = ({ onBack, token }) => {
  const [users, setUsers] = useState([])
  const [stats, setStats] = useState({})
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const fetchUsers = async () => {
    try {
     const response = await fetch("https://5000-ioor3y1ypvoe7fh4z0u9b-b947c44b.manusvm.computer/api/users", {        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setUsers(data)
      } else {
        setError('Erro ao carregar usuários')
      }
    } catch (err) {
      setError('Erro de conexão')
    }
  }

  const fetchStats = async () => {
    try {
      const response = await fetch("https://5000-ioor3y1ypvoe7fh4z0u9b-b947c44b.manusvm.computer/api/stats", {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        const data = await response.json()
        setStats(data)
      }
    } catch (err) {
      console.error('Erro ao carregar estatísticas:', err)
    }
  }

  useEffect(() => {
    const loadData = async () => {
      setLoading(true)
      await Promise.all([fetchUsers(), fetchStats()])
      setLoading(false)
    }
    loadData()
  }, [token])

  const extendAccess = async (userId, months) => {
    try {
      const response = await fetch(`/api/users/${userId}/extend-access`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ months })
      })

      const data = await response.json()

      if (response.ok) {
        setSuccess(`Acesso estendido por ${months} meses`)
        fetchUsers()
        fetchStats()
      } else {
        setError(data.message || 'Erro ao estender acesso')
      }
    } catch (err) {
      setError('Erro de conexão')
    }
  }

  const revokeAccess = async (userId) => {
    try {
      const response = await fetch(`/api/users/${userId}/revoke-access`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      const data = await response.json()

      if (response.ok) {
        setSuccess('Acesso revogado')
        fetchUsers()
        fetchStats()
      } else {
        setError(data.message || 'Erro ao revogar acesso')
      }
    } catch (err) {
      setError('Erro de conexão')
    }
  }

  const restoreAccess = async (userId) => {
    try {
      const response = await fetch(`/api/users/${userId}/restore-access`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      const data = await response.json()

      if (response.ok) {
        setSuccess('Acesso restaurado')
        fetchUsers()
        fetchStats()
      } else {
        setError(data.message || 'Erro ao restaurar acesso')
      }
    } catch (err) {
      setError('Erro de conexão')
    }
  }

  const deleteUser = async (userId) => {
    if (!confirm('Tem certeza que deseja deletar este usuário?')) return

    try {
      const response = await fetch(`/api/users/${userId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      })

      if (response.ok) {
        setSuccess('Usuário deletado')
        fetchUsers()
        fetchStats()
      } else {
        const data = await response.json()
        setError(data.message || 'Erro ao deletar usuário')
      }
    } catch (err) {
      setError('Erro de conexão')
    }
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'Nunca'
    return new Date(dateString).toLocaleDateString('pt-BR')
  }

  const getAccessStatus = (user) => {
    if (!user.is_active) return { text: 'Bloqueado', color: 'bg-red-500' }
    if (!user.has_valid_access) return { text: 'Expirado', color: 'bg-orange-500' }
    return { text: 'Ativo', color: 'bg-green-500' }
  }

  const getDaysUntilExpiry = (dateString) => {
    if (!dateString) return null
    const expiry = new Date(dateString)
    const now = new Date()
    const diffTime = expiry - now
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-purple-500" />
          <p>Carregando painel administrativo...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onBack}
              className="mr-4"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="bg-purple-500 w-10 h-10 rounded-full flex items-center justify-center mr-3">
              <Shield className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-800">Painel Administrativo</h1>
          </div>
          
          <Button onClick={() => { fetchUsers(); fetchStats(); }} variant="outline" size="sm">
            <RefreshCw className="w-4 h-4 mr-2" />
            Atualizar
          </Button>
        </div>

        {/* Alertas */}
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="border-green-200 bg-green-50 mb-4">
            <AlertDescription className="text-green-800">{success}</AlertDescription>
          </Alert>
        )}

        {/* Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <Users className="w-8 h-8 text-blue-500 mr-3" />
                <div>
                  <p className="text-sm text-gray-600">Total de Usuários</p>
                  <p className="text-2xl font-bold">{stats.total_users || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <UserCheck className="w-8 h-8 text-green-500 mr-3" />
                <div>
                  <p className="text-sm text-gray-600">Usuários Ativos</p>
                  <p className="text-2xl font-bold">{stats.active_users || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <Clock className="w-8 h-8 text-orange-500 mr-3" />
                <div>
                  <p className="text-sm text-gray-600">Acessos Expirados</p>
                  <p className="text-2xl font-bold">{stats.expired_users || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center">
                <Shield className="w-8 h-8 text-purple-500 mr-3" />
                <div>
                  <p className="text-sm text-gray-600">Administradores</p>
                  <p className="text-2xl font-bold">{stats.admin_users || 0}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Lista de Usuários */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="w-5 h-5 mr-2" />
              Gerenciamento de Usuários
            </CardTitle>
            <CardDescription>
              Gerencie o acesso e permissões dos usuários
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {users.map((user) => {
                const status = getAccessStatus(user)
                const daysUntilExpiry = getDaysUntilExpiry(user.access_expires_at)
                
                return (
                  <div key={user.id} className="border rounded-lg p-4 bg-white">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold">{user.email}</h3>
                          {user.is_admin && (
                            <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                              <Shield className="w-3 h-3 mr-1" />
                              Admin
                            </Badge>
                          )}
                          <Badge className={`${status.color} text-white`}>
                            {status.text}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm text-gray-600">
                          <div className="flex items-center">
                            <Phone className="w-4 h-4 mr-1" />
                            {user.whatsapp}
                          </div>
                          <div className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            Criado: {formatDate(user.created_at)}
                          </div>
                          <div className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            Último login: {formatDate(user.last_login)}
                          </div>
                        </div>
                        
                        {user.access_expires_at && (
                          <div className="mt-2">
                            <p className="text-sm">
                              <strong>Expira em:</strong> {formatDate(user.access_expires_at)}
                              {daysUntilExpiry !== null && (
                                <span className={`ml-2 ${daysUntilExpiry <= 7 ? 'text-red-600' : daysUntilExpiry <= 30 ? 'text-orange-600' : 'text-green-600'}`}>
                                  ({daysUntilExpiry > 0 ? `${daysUntilExpiry} dias restantes` : 'Expirado'})
                                </span>
                              )}
                            </p>
                          </div>
                        )}
                      </div>

                      {!user.is_admin && (
                        <div className="flex flex-wrap gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => extendAccess(user.id, 1)}
                            className="text-green-600 border-green-600 hover:bg-green-50"
                          >
                            <Plus className="w-4 h-4 mr-1" />
                            +1 mês
                          </Button>
                          
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => extendAccess(user.id, 3)}
                            className="text-blue-600 border-blue-600 hover:bg-blue-50"
                          >
                            <Plus className="w-4 h-4 mr-1" />
                            +3 meses
                          </Button>
                          
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => extendAccess(user.id, 12)}
                            className="text-purple-600 border-purple-600 hover:bg-purple-50"
                          >
                            <Plus className="w-4 h-4 mr-1" />
                            +1 ano
                          </Button>

                          {user.is_active ? (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => revokeAccess(user.id)}
                              className="text-orange-600 border-orange-600 hover:bg-orange-50"
                            >
                              <UserX className="w-4 h-4 mr-1" />
                              Bloquear
                            </Button>
                          ) : (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => restoreAccess(user.id)}
                              className="text-green-600 border-green-600 hover:bg-green-50"
                            >
                              <UserCheck className="w-4 h-4 mr-1" />
                              Restaurar
                            </Button>
                          )}

                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => deleteUser(user.id)}
                            className="text-red-600 border-red-600 hover:bg-red-50"
                          >
                            <Trash2 className="w-4 h-4 mr-1" />
                            Deletar
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                )
              })}

              {users.length === 0 && (
                <div className="text-center py-8 text-gray-500">
                  <Users className="w-16 h-16 mx-auto mb-4 opacity-50" />
                  <p>Nenhum usuário encontrado</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default AdminPanel


import { useState, useRef } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Checkbox } from '@/components/ui/checkbox.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { ArrowLeft, ArrowRight, Calendar, DollarSign, Clock, FileText, Download, Share, Calculator, Building, Hammer, Zap, Droplets, Paintbrush, Home, CheckCircle, Edit, RefreshCw, Users, MapPin, BarChart3, Maximize, Minimize, ChevronDown, ZoomIn, ZoomOut, X } from 'lucide-react'
import screenfull from 'screenfull';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import GanttChart from './GanttChart.jsx';
import { adicionarDiasUteis, converterDiasCorridosParaUteis } from '../utils/dateUtils.js';

const tiposObra = [
  { value: 'residencial_popular', label: 'Residencial Popular', custoBase: 1200 },
  { value: 'residencial_padrao', label: 'Residencial Padrão', custoBase: 1600 },
  { value: 'residencial_alto', label: 'Residencial Alto Padrão', custoBase: 2400 },
  { value: 'comercial_simples', label: 'Comercial Simples', custoBase: 1800 },
  { value: 'comercial_complexo', label: 'Comercial Complexo', custoBase: 2800 },
  { value: 'industrial', label: 'Industrial', custoBase: 3200 }
]

// Dados das etapas baseados na pesquisa e na planilha fornecida
const etapasBase = [
  {
    id: 'projeto',
    nome: 'Projeto',
    categoria: 'Planejamento',
    icone: FileText,
    duracaoDias: 30,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 35, mao_obra: '1 arquiteto + 1 desenhista', equipe: 1, tempo_m2_dias: 0.4 },
      'residencial_padrao': { custo_m2: 50, mao_obra: '1 arquiteto + 2 desenhistas', equipe: 1, tempo_m2_dias: 0.5 },
      'residencial_alto': { custo_m2: 75, mao_obra: '2 arquitetos + 3 desenhistas', equipe: 1, tempo_m2_dias: 0.6 },
      'comercial_simples': { custo_m2: 60, mao_obra: '1 arquiteto + 2 desenhistas', equipe: 1, tempo_m2_dias: 0.55 },
      'comercial_complexo': { custo_m2: 90, mao_obra: '2 arquitetos + 4 desenhistas', equipe: 1, tempo_m2_dias: 0.7 },
      'industrial': { custo_m2: 120, mao_obra: 'Equipe especializada', equipe: 1, tempo_m2_dias: 0.8 }
    },
    cor: 'bg-blue-300',
    descricao: 'Elaboração dos projetos arquitetônicos e complementares'
  },
  {
    id: 'documentacao',
    nome: 'Documentação',
    categoria: 'Planejamento',
    icone: FileText,
    duracaoDias: 45,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 20, mao_obra: '1 despachante + 1 auxiliar', equipe: 1, tempo_m2_dias: 0.3 },
      'residencial_padrao': { custo_m2: 30, mao_obra: '1 despachante + 2 auxiliares', equipe: 1, tempo_m2_dias: 0.4 },
      'residencial_alto': { custo_m2: 45, mao_obra: '2 despachantes + 3 auxiliares', equipe: 1, tempo_m2_dias: 0.5 },
      'comercial_simples': { custo_m2: 35, mao_obra: '1 despachante + 2 auxiliares', equipe: 1, tempo_m2_dias: 0.45 },
      'comercial_complexo': { custo_m2: 55, mao_obra: '2 despachantes + 4 auxiliares', equipe: 1, tempo_m2_dias: 0.6 },
      'industrial': { custo_m2: 70, mao_obra: 'Equipe de legalização', equipe: 1, tempo_m2_dias: 0.7 }
    },
    cor: 'bg-blue-400',
    descricao: 'Aprovação de projetos, licenças e alvarás'
  },
  {
    id: 'limpeza_terreno_movimentacao_terra',
    nome: 'Limpeza do Terreno e Movimentação de Terra',
    categoria: 'Preparação',
    icone: Building,
    duracaoDias: 7,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 8, mao_obra: '1 operador + 1 ajudante', equipe: 2, tempo_m2_dias: 0.07 },
      'residencial_padrao': { custo_m2: 10, mao_obra: '1 operador + 2 ajudantes', equipe: 2, tempo_m2_dias: 0.08 },
      'residencial_alto': { custo_m2: 15, mao_obra: '2 operadores + 2 ajudantes', equipe: 2, tempo_m2_dias: 0.1 },
      'comercial_simples': { custo_m2: 12, mao_obra: '1 operador + 2 ajudantes', equipe: 2, tempo_m2_dias: 0.09 },
      'comercial_complexo': { custo_m2: 18, mao_obra: '2 operadores + 3 ajudantes', equipe: 2, tempo_m2_dias: 0.12 },
      'industrial': { custo_m2: 25, mao_obra: 'Equipe especializada em terraplanagem', equipe: 2, tempo_m2_dias: 0.15 }
    },
    cor: 'bg-green-400',
    descricao: 'Preparação inicial do terreno'
  },
  {
    id: 'ligamento_energia',
    nome: 'Ligamento para Energia ao Canteiro de Obra',
    categoria: 'Preparação',
    icone: Zap,
    duracaoDias: 5,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 5, mao_obra: '1 eletricista + 1 ajudante', equipe: 2, tempo_m2_dias: 0.05 },
      'residencial_padrao': { custo_m2: 8, mao_obra: '1 eletricista + 1 ajudante', equipe: 2, tempo_m2_dias: 0.07 },
      'residencial_alto': { custo_m2: 12, mao_obra: '2 eletricistas + 2 ajudantes', equipe: 2, tempo_m2_dias: 0.1 },
      'comercial_simples': { custo_m2: 10, mao_obra: '1 eletricista + 1 ajudante', equipe: 2, tempo_m2_dias: 0.08 },
      'comercial_complexo': { custo_m2: 15, mao_obra: '2 eletricistas + 2 ajudantes', equipe: 2, tempo_m2_dias: 0.12 },
      'industrial': { custo_m2: 20, mao_obra: 'Equipe especializada', equipe: 2, tempo_m2_dias: 0.15 }
    },
    cor: 'bg-green-500',
    descricao: 'Instalação provisória de energia elétrica no canteiro de obras'
  },
  {
    id: 'locacao',
    nome: 'Locação',
    categoria: 'Preparação',
    icone: MapPin,
    duracaoDias: 3,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 4, mao_obra: '1 topógrafo + 1 auxiliar', equipe: 2, tempo_m2_dias: 0.04 },
      'residencial_padrao': { custo_m2: 6, mao_obra: '1 topógrafo + 1 auxiliar', equipe: 2, tempo_m2_dias: 0.05 },
      'residencial_alto': { custo_m2: 9, mao_obra: '1 topógrafo + 2 auxiliares', equipe: 2, tempo_m2_dias: 0.07 },
      'comercial_simples': { custo_m2: 7, mao_obra: '1 topógrafo + 1 auxiliar', equipe: 2, tempo_m2_dias: 0.06 },
      'comercial_complexo': { custo_m2: 10, mao_obra: '1 topógrafo + 2 auxiliares', equipe: 2, tempo_m2_dias: 0.08 },
      'industrial': { custo_m2: 15, mao_obra: 'Equipe de topografia especializada', equipe: 2, tempo_m2_dias: 0.1 }
    },
    cor: 'bg-green-600',
    descricao: 'Marcação da obra no terreno conforme projeto'
  },
  {
    id: 'contencao_movimentacao_terra',
    nome: 'Contenção/Movimentação de Terra',
    categoria: 'Preparação',
    icone: Building,
    duracaoDias: 10,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 15, mao_obra: '1 operador de máquina + 2 ajudantes', equipe: 2, tempo_m2_dias: 0.1 },
      'residencial_padrao': { custo_m2: 20, mao_obra: '1 operador de máquina + 3 ajudantes', equipe: 2, tempo_m2_dias: 0.15 },
      'residencial_alto': { custo_m2: 30, mao_obra: '2 operadores + 4 ajudantes', equipe: 2, tempo_m2_dias: 0.2 },
      'comercial_simples': { custo_m2: 25, mao_obra: '1 operador + 3 ajudantes', equipe: 2, tempo_m2_dias: 0.18 },
      'comercial_complexo': { custo_m2: 40, mao_obra: '2 operadores + 5 ajudantes', equipe: 2, tempo_m2_dias: 0.25 },
      'industrial': { custo_m2: 60, mao_obra: 'Equipe especializada em terraplanagem', equipe: 2, tempo_m2_dias: 0.3 }
    },
    cor: 'bg-green-700',
    descricao: 'Escavação, aterro e contenção do solo'
  },
  {
    id: 'fundacao',
    nome: 'Fundação (sapatas e vigas baldrames)',
    categoria: 'Estrutura',
    icone: Hammer,
    duracaoDias: 21,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 120, mao_obra: '2 pedreiros + 2 ajudantes + 1 armador', equipe: 3, tempo_m2_dias: 0.2 },
      'residencial_padrao': { custo_m2: 150, mao_obra: '3 pedreiros + 3 ajudantes + 2 armadores', equipe: 3, tempo_m2_dias: 0.25 },
      'residencial_alto': { custo_m2: 200, mao_obra: '4 pedreiros + 4 ajudantes + 3 armadores', equipe: 3, tempo_m2_dias: 0.3 },
      'comercial_simples': { custo_m2: 180, mao_obra: '3 pedreiros + 3 ajudantes + 2 armadores', equipe: 3, tempo_m2_dias: 0.28 },
      'comercial_complexo': { custo_m2: 250, mao_obra: '5 pedreiros + 5 ajudantes + 4 armadores', equipe: 3, tempo_m2_dias: 0.35 },
      'industrial': { custo_m2: 350, mao_obra: 'Equipe especializada em fundações', equipe: 3, tempo_m2_dias: 0.45 }
    },
    cor: 'bg-gray-600',
    descricao: 'Execução das fundações'
  },
  {
    id: 'impermeabilizacao',
    nome: 'Impermeabilização',
    categoria: 'Estrutura',
    icone: Droplets,
    duracaoDias: 7,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 20, mao_obra: '1 aplicador + 1 ajudante', equipe: 3, tempo_m2_dias: 0.1 },
      'residencial_padrao': { custo_m2: 30, mao_obra: '2 aplicadores + 1 ajudante', equipe: 3, tempo_m2_dias: 0.15 },
      'residencial_alto': { custo_m2: 50, mao_obra: '2 aplicadores + 2 ajudantes', equipe: 3, tempo_m2_dias: 0.2 },
      'comercial_simples': { custo_m2: 40, mao_obra: '2 aplicadores + 1 ajudante', equipe: 3, tempo_m2_dias: 0.18 },
      'comercial_complexo': { custo_m2: 70, mao_obra: '3 aplicadores + 2 ajudantes', equipe: 3, tempo_m2_dias: 0.25 },
      'industrial': { custo_m2: 100, mao_obra: 'Equipe especializada', equipe: 3, tempo_m2_dias: 0.3 }
    },
    cor: 'bg-gray-700',
    descricao: 'Aplicação de produtos para evitar infiltrações'
  },
  {
    id: 'aterro',
    nome: 'Aterro',
    categoria: 'Preparação',
    icone: Building,
    duracaoDias: 5,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 10, mao_obra: '1 operador de máquina + 2 ajudantes', equipe: 2, tempo_m2_dias: 0.08 },
      'residencial_padrao': { custo_m2: 15, mao_obra: '1 operador de máquina + 3 ajudantes', equipe: 2, tempo_m2_dias: 0.1 },
      'residencial_alto': { custo_m2: 25, mao_obra: '2 operadores + 4 ajudantes', equipe: 2, tempo_m2_dias: 0.15 },
      'comercial_simples': { custo_m2: 20, mao_obra: '1 operador + 3 ajudantes', equipe: 2, tempo_m2_dias: 0.12 },
      'comercial_complexo': { custo_m2: 35, mao_obra: '2 operadores + 5 ajudantes', equipe: 2, tempo_m2_dias: 0.2 },
      'industrial': { custo_m2: 50, mao_obra: 'Equipe de terraplanagem', equipe: 2, tempo_m2_dias: 0.25 }
    },
    cor: 'bg-green-800',
    descricao: 'Preenchimento de áreas com terra ou material granular'
  },
  {
    id: 'alvenaria_terreo',
    nome: 'Alvenaria do Térreo',
    categoria: 'Vedação',
    icone: Building,
    duracaoDias: 20,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 90, mao_obra: '3 pedreiros + 3 ajudantes', equipe: 5, tempo_m2_dias: 0.25 },
      'residencial_padrao': { custo_m2: 120, mao_obra: '4 pedreiros + 4 ajudantes', equipe: 5, tempo_m2_dias: 0.3 },
      'residencial_alto': { custo_m2: 160, mao_obra: '6 pedreiros + 6 ajudantes', equipe: 5, tempo_m2_dias: 0.35 },
      'comercial_simples': { custo_m2: 130, mao_obra: '4 pedreiros + 4 ajudantes', equipe: 5, tempo_m2_dias: 0.32 },
      'comercial_complexo': { custo_m2: 190, mao_obra: '8 pedreiros + 8 ajudantes', equipe: 5, tempo_m2_dias: 0.4 },
      'industrial': { custo_m2: 230, mao_obra: 'Equipe especializada', equipe: 5, tempo_m2_dias: 0.45 }
    },
    cor: 'bg-orange-500',
    descricao: 'Construção das paredes do pavimento térreo'
  },
  {
    id: 'fossa_sumidouro',
    nome: 'Fossa/Sumidouro',
    categoria: 'Instalações',
    icone: Droplets,
    duracaoDias: 10,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 60, mao_obra: '2 pedreiros + 2 ajudantes', equipe: 8, tempo_m2_dias: 0.15 },
      'residencial_padrao': { custo_m2: 80, mao_obra: '3 pedreiros + 3 ajudantes', equipe: 8, tempo_m2_dias: 0.2 },
      'residencial_alto': { custo_m2: 120, mao_obra: '4 pedreiros + 4 ajudantes', equipe: 8, tempo_m2_dias: 0.25 },
      'comercial_simples': { custo_m2: 100, mao_obra: '3 pedreiros + 3 ajudantes', equipe: 8, tempo_m2_dias: 0.22 },
      'comercial_complexo': { custo_m2: 150, mao_obra: '5 pedreiros + 5 ajudantes', equipe: 8, tempo_m2_dias: 0.3 },
      'industrial': { custo_m2: 200, mao_obra: 'Equipe especializada', equipe: 8, tempo_m2_dias: 0.35 }
    },
    cor: 'bg-blue-600',
    descricao: 'Construção de fossa séptica e sumidouro'
  },
  {
    id: 'infra_eletrica',
    nome: 'Infra Elétrica',
    categoria: 'Instalações',
    icone: Zap,
    duracaoDias: 7,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 40, mao_obra: '1 eletricista + 1 ajudante', equipe: 7, tempo_m2_dias: 0.1 },
      'residencial_padrao': { custo_m2: 55, mao_obra: '2 eletricistas + 1 ajudante', equipe: 7, tempo_m2_dias: 0.12 },
      'residencial_alto': { custo_m2: 80, mao_obra: '2 eletricistas + 2 ajudantes', equipe: 7, tempo_m2_dias: 0.15 },
      'comercial_simples': { custo_m2: 70, mao_obra: '2 eletricistas + 1 ajudante', equipe: 7, tempo_m2_dias: 0.14 },
      'comercial_complexo': { custo_m2: 100, mao_obra: '3 eletricistas + 2 ajudantes', equipe: 7, tempo_m2_dias: 0.18 },
      'industrial': { custo_m2: 130, mao_obra: 'Equipe especializada', equipe: 7, tempo_m2_dias: 0.2 }
    },
    cor: 'bg-purple-500',
    descricao: 'Instalação da infraestrutura para a parte elétrica'
  },
  {
    id: 'cabeamento_eletrica',
    nome: 'Cabeamento Elétrica',
    categoria: 'Instalações',
    icone: Zap,
    duracaoDias: 5,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 30, mao_obra: '1 eletricista + 1 ajudante', equipe: 7, tempo_m2_dias: 0.08 },
      'residencial_padrao': { custo_m2: 45, mao_obra: '2 eletricistas + 1 ajudante', equipe: 7, tempo_m2_dias: 0.1 },
      'residencial_alto': { custo_m2: 65, mao_obra: '2 eletricistas + 2 ajudantes', equipe: 7, tempo_m2_dias: 0.12 },
      'comercial_simples': { custo_m2: 55, mao_obra: '2 eletricistas + 1 ajudante', equipe: 7, tempo_m2_dias: 0.11 },
      'comercial_complexo': { custo_m2: 85, mao_obra: '3 eletricistas + 2 ajudantes', equipe: 7, tempo_m2_dias: 0.15 },
      'industrial': { custo_m2: 110, mao_obra: 'Equipe especializada', equipe: 7, tempo_m2_dias: 0.18 }
    },
    cor: 'bg-purple-600',
    descricao: 'Passagem de cabos e fiação elétrica'
  },
  {
    id: 'instalacoes_hidrossanitarias',
    nome: 'Instalações Hidrossanitárias',
    categoria: 'Instalações',
    icone: Droplets,
    duracaoDias: 15,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 60, mao_obra: '2 encanadores + 2 ajudantes', equipe: 8, tempo_m2_dias: 0.15 },
      'residencial_padrao': { custo_m2: 80, mao_obra: '3 encanadores + 3 ajudantes', equipe: 8, tempo_m2_dias: 0.2 },
      'residencial_alto': { custo_m2: 120, mao_obra: '4 encanadores + 4 ajudantes', equipe: 8, tempo_m2_dias: 0.25 },
      'comercial_simples': { custo_m2: 100, mao_obra: '3 encanadores + 3 ajudantes', equipe: 8, tempo_m2_dias: 0.22 },
      'comercial_complexo': { custo_m2: 150, mao_obra: '5 encanadores + 5 ajudantes', equipe: 8, tempo_m2_dias: 0.3 },
      'industrial': { custo_m2: 200, mao_obra: 'Equipe especializada', equipe: 8, tempo_m2_dias: 0.35 }
    },
    cor: 'bg-blue-500',
    descricao: 'Instalação de tubulações de água e esgoto'
  },
  {
    id: 'contramarcos',
    nome: 'Contramarcos',
    categoria: 'Esquadrias',
    icone: Home,
    duracaoDias: 3,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 15, mao_obra: '1 carpinteiro + 1 ajudante', equipe: 9, tempo_m2_dias: 0.05 },
      'residencial_padrao': { custo_m2: 20, mao_obra: '1 carpinteiro + 1 ajudante', equipe: 9, tempo_m2_dias: 0.07 },
      'residencial_alto': { custo_m2: 30, mao_obra: '2 carpinteiros + 2 ajudantes', equipe: 9, tempo_m2_dias: 0.1 },
      'comercial_simples': { custo_m2: 25, mao_obra: '1 carpinteiro + 1 ajudante', equipe: 9, tempo_m2_dias: 0.08 },
      'comercial_complexo': { custo_m2: 35, mao_obra: '2 carpinteiros + 2 ajudantes', equipe: 9, tempo_m2_dias: 0.12 },
      'industrial': { custo_m2: 45, mao_obra: 'Equipe especializada', equipe: 9, tempo_m2_dias: 0.15 }
    },
    cor: 'bg-yellow-500',
    descricao: 'Instalação de contramarcos para portas e janelas'
  },
  {
    id: 'reboco_interno',
    nome: 'Reboco Interno',
    categoria: 'Acabamento',
    icone: Paintbrush,
    duracaoDias: 15,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 35, mao_obra: '2 pedreiros + 2 ajudantes', equipe: 10, tempo_m2_dias: 0.15 },
      'residencial_padrao': { custo_m2: 45, mao_obra: '3 pedreiros + 3 ajudantes', equipe: 10, tempo_m2_dias: 0.2 },
      'residencial_alto': { custo_m2: 60, mao_obra: '4 pedreiros + 4 ajudantes', equipe: 10, tempo_m2_dias: 0.25 },
      'comercial_simples': { custo_m2: 50, mao_obra: '3 pedreiros + 3 ajudantes', equipe: 10, tempo_m2_dias: 0.22 },
      'comercial_complexo': { custo_m2: 70, mao_obra: '5 pedreiros + 5 ajudantes', equipe: 10, tempo_m2_dias: 0.3 },
      'industrial': { custo_m2: 90, mao_obra: 'Equipe especializada', equipe: 10, tempo_m2_dias: 0.35 }
    },
    cor: 'bg-gray-400',
    descricao: 'Aplicação de argamassa nas paredes internas'
  },
  {
    id: 'reboco_externo',
    nome: 'Reboco Externo',
    categoria: 'Acabamento',
    icone: Paintbrush,
    duracaoDias: 10,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 40, mao_obra: '2 pedreiros + 2 ajudantes', equipe: 10, tempo_m2_dias: 0.15 },
      'residencial_padrao': { custo_m2: 50, mao_obra: '3 pedreiros + 3 ajudantes', equipe: 10, tempo_m2_dias: 0.2 },
      'residencial_alto': { custo_m2: 70, mao_obra: '4 pedreiros + 4 ajudantes', equipe: 10, tempo_m2_dias: 0.25 },
      'comercial_simples': { custo_m2: 60, mao_obra: '3 pedreiros + 3 ajudantes', equipe: 10, tempo_m2_dias: 0.22 },
      'comercial_complexo': { custo_m2: 80, mao_obra: '5 pedreiros + 5 ajudantes', equipe: 10, tempo_m2_dias: 0.3 },
      'industrial': { custo_m2: 100, mao_obra: 'Equipe especializada', equipe: 10, tempo_m2_dias: 0.35 }
    },
    cor: 'bg-gray-500',
    descricao: 'Aplicação de argamassa nas paredes externas'
  },
  {
    id: 'revestimento_interno',
    nome: 'Revestimento Interno',
    categoria: 'Acabamento',
    icone: Paintbrush,
    duracaoDias: 20,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 50, mao_obra: '2 azulejistas + 2 ajudantes', equipe: 11, tempo_m2_dias: 0.2 },
      'residencial_padrao': { custo_m2: 70, mao_obra: '3 azulejistas + 3 ajudantes', equipe: 11, tempo_m2_dias: 0.25 },
      'residencial_alto': { custo_m2: 100, mao_obra: '4 azulejistas + 4 ajudantes', equipe: 11, tempo_m2_dias: 0.3 },
      'comercial_simples': { custo_m2: 80, mao_obra: '3 azulejistas + 3 ajudantes', equipe: 11, tempo_m2_dias: 0.28 },
      'comercial_complexo': { custo_m2: 120, mao_obra: '5 azulejistas + 5 ajudantes', equipe: 11, tempo_m2_dias: 0.35 },
      'industrial': { custo_m2: 150, mao_obra: 'Equipe especializada', equipe: 11, tempo_m2_dias: 0.4 }
    },
    cor: 'bg-yellow-600',
    descricao: 'Instalação de pisos e revestimentos nas áreas internas'
  },
  {
    id: 'revestimento_externo',
    nome: 'Revestimento Externo',
    categoria: 'Acabamento',
    icone: Paintbrush,
    duracaoDias: 15,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 60, mao_obra: '2 azulejistas + 2 ajudantes', equipe: 11, tempo_m2_dias: 0.2 },
      'residencial_padrao': { custo_m2: 80, mao_obra: '3 azulejistas + 3 ajudantes', equipe: 11, tempo_m2_dias: 0.25 },
      'residencial_alto': { custo_m2: 110, mao_obra: '4 azulejistas + 4 ajudantes', equipe: 11, tempo_m2_dias: 0.3 },
      'comercial_simples': { custo_m2: 90, mao_obra: '3 azulejistas + 3 ajudantes', equipe: 11, tempo_m2_dias: 0.28 },
      'comercial_complexo': { custo_m2: 130, mao_obra: '5 azulejistas + 5 ajudantes', equipe: 11, tempo_m2_dias: 0.35 },
      'industrial': { custo_m2: 160, mao_obra: 'Equipe especializada', equipe: 11, tempo_m2_dias: 0.4 }
    },
    cor: 'bg-yellow-700',
    descricao: 'Instalação de pisos e revestimentos nas áreas externas'
  },
  {
    id: 'forro_gesso',
    nome: 'Forro de Gesso',
    categoria: 'Acabamento',
    icone: Home,
    duracaoDias: 10,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 30, mao_obra: '2 gesseiros + 2 ajudantes', equipe: 12, tempo_m2_dias: 0.1 },
      'residencial_padrao': { custo_m2: 40, mao_obra: '3 gesseiros + 3 ajudantes', equipe: 12, tempo_m2_dias: 0.12 },
      'residencial_alto': { custo_m2: 60, mao_obra: '4 gesseiros + 4 ajudantes', equipe: 12, tempo_m2_dias: 0.15 },
      'comercial_simples': { custo_m2: 50, mao_obra: '3 gesseiros + 3 ajudantes', equipe: 12, tempo_m2_dias: 0.14 },
      'comercial_complexo': { custo_m2: 70, mao_obra: '5 gesseiros + 5 ajudantes', equipe: 12, tempo_m2_dias: 0.18 },
      'industrial': { custo_m2: 90, mao_obra: 'Equipe especializada', equipe: 12, tempo_m2_dias: 0.2 }
    },
    cor: 'bg-indigo-500',
    descricao: 'Instalação de forros de gesso'
  },
  {
    id: 'loucas_metais_bancadas_soleiras_divibox',
    nome: 'Louças, Metais, Bancadas, Soleiras e Divibox',
    categoria: 'Acabamento',
    icone: Home,
    duracaoDias: 10,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 40, mao_obra: '2 instaladores + 2 ajudantes', equipe: 12, tempo_m2_dias: 0.1 },
      'residencial_padrao': { custo_m2: 55, mao_obra: '3 instaladores + 3 ajudantes', equipe: 12, tempo_m2_dias: 0.12 },
      'residencial_alto': { custo_m2: 80, mao_obra: '4 instaladores + 4 ajudantes', equipe: 12, tempo_m2_dias: 0.15 },
      'comercial_simples': { custo_m2: 70, mao_obra: '3 instaladores + 3 ajudantes', equipe: 12, tempo_m2_dias: 0.14 },
      'comercial_complexo': { custo_m2: 100, mao_obra: '5 instaladores + 5 ajudantes', equipe: 12, tempo_m2_dias: 0.18 },
      'industrial': { custo_m2: 130, mao_obra: 'Equipe especializada', equipe: 12, tempo_m2_dias: 0.2 }
    },
    cor: 'bg-indigo-600',
    descricao: 'Instalação de louças, metais, bancadas, soleiras e divisórias de banheiro'
  },
  {
    id: 'pintura_interna_externa',
    nome: 'Pintura Interna e Externa',
    categoria: 'Acabamento',
    icone: Paintbrush,
    duracaoDias: 15,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 25, mao_obra: '2 pintores + 2 ajudantes', equipe: 13, tempo_m2_dias: 0.1 },
      'residencial_padrao': { custo_m2: 35, mao_obra: '3 pintores + 3 ajudantes', equipe: 13, tempo_m2_dias: 0.12 },
      'residencial_alto': { custo_m2: 50, mao_obra: '4 pintores + 4 ajudantes', equipe: 13, tempo_m2_dias: 0.15 },
      'comercial_simples': { custo_m2: 40, mao_obra: '3 pintores + 3 ajudantes', equipe: 13, tempo_m2_dias: 0.14 },
      'comercial_complexo': { custo_m2: 60, mao_obra: '5 pintores + 5 ajudantes', equipe: 13, tempo_m2_dias: 0.18 },
      'industrial': { custo_m2: 80, mao_obra: 'Equipe especializada', equipe: 13, tempo_m2_dias: 0.2 }
    },
    cor: 'bg-pink-500',
    descricao: 'Aplicação de pintura nas áreas internas e externas'
  },
  {
    id: 'esquadrias',
    nome: 'Esquadrias',
    categoria: 'Acabamento',
    icone: Home,
    duracaoDias: 7,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 30, mao_obra: '2 instaladores + 2 ajudantes', equipe: 9, tempo_m2_dias: 0.08 },
      'residencial_padrao': { custo_m2: 40, mao_obra: '3 instaladores + 3 ajudantes', equipe: 9, tempo_m2_dias: 0.1 },
      'residencial_alto': { custo_m2: 60, mao_obra: '4 instaladores + 4 ajudantes', equipe: 9, tempo_m2_dias: 0.12 },
      'comercial_simples': { custo_m2: 50, mao_obra: '3 instaladores + 3 ajudantes', equipe: 9, tempo_m2_dias: 0.11 },
      'comercial_complexo': { custo_m2: 80, mao_obra: '5 instaladores + 5 ajudantes', equipe: 9, tempo_m2_dias: 0.15 },
      'industrial': { custo_m2: 100, mao_obra: 'Equipe especializada', equipe: 9, tempo_m2_dias: 0.18 }
    },
    cor: 'bg-yellow-800',
    descricao: 'Instalação de portas e janelas'
  },
  {
    id: 'serralheria',
    nome: 'Serralheria',
    categoria: 'Acabamento',
    icone: Hammer,
    duracaoDias: 5,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 20, mao_obra: '1 serralheiro + 1 ajudante', equipe: 9, tempo_m2_dias: 0.05 },
      'residencial_padrao': { custo_m2: 30, mao_obra: '2 serralheiros + 2 ajudantes', equipe: 9, tempo_m2_dias: 0.07 },
      'residencial_alto': { custo_m2: 45, mao_obra: '3 serralheiros + 3 ajudantes', equipe: 9, tempo_m2_dias: 0.1 },
      'comercial_simples': { custo_m2: 35, mao_obra: '2 serralheiros + 2 ajudantes', equipe: 9, tempo_m2_dias: 0.08 },
      'comercial_complexo': { custo_m2: 55, mao_obra: '4 serralheiros + 4 ajudantes', equipe: 9, tempo_m2_dias: 0.12 },
      'industrial': { custo_m2: 70, mao_obra: 'Equipe especializada', equipe: 9, tempo_m2_dias: 0.15 }
    },
    cor: 'bg-yellow-900',
    descricao: 'Instalação de grades, portões e estruturas metálicas'
  },
  {
    id: 'colocacao_grama_brita',
    nome: 'Colocação de Grama e Brita',
    categoria: 'Paisagismo',
    icone: Home,
    duracaoDias: 3,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 10, mao_obra: '2 jardineiros + 2 ajudantes', equipe: 14, tempo_m2_dias: 0.05 },
      'residencial_padrao': { custo_m2: 15, mao_obra: '3 jardineiros + 3 ajudantes', equipe: 14, tempo_m2_dias: 0.07 },
      'residencial_alto': { custo_m2: 20, mao_obra: '4 jardineiros + 4 ajudantes', equipe: 14, tempo_m2_dias: 0.1 },
      'comercial_simples': { custo_m2: 18, mao_obra: '3 jardineiros + 3 ajudantes', equipe: 14, tempo_m2_dias: 0.08 },
      'comercial_complexo': { custo_m2: 25, mao_obra: '5 jardineiros + 5 ajudantes', equipe: 14, tempo_m2_dias: 0.12 },
      'industrial': { custo_m2: 30, mao_obra: 'Equipe especializada', equipe: 14, tempo_m2_dias: 0.15 }
    },
    cor: 'bg-green-900',
    descricao: 'Instalação de gramado e brita em áreas externas'
  },
  {
    id: 'instalacao_portas',
    nome: 'Instalação Portas',
    categoria: 'Acabamento',
    icone: Home,
    duracaoDias: 5,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 25, mao_obra: '2 carpinteiros + 2 ajudantes', equipe: 9, tempo_m2_dias: 0.07 },
      'residencial_padrao': { custo_m2: 35, mao_obra: '3 carpinteiros + 3 ajudantes', equipe: 9, tempo_m2_dias: 0.09 },
      'residencial_alto': { custo_m2: 50, mao_obra: '4 carpinteiros + 4 ajudantes', equipe: 9, tempo_m2_dias: 0.12 },
      'comercial_simples': { custo_m2: 40, mao_obra: '3 carpinteiros + 3 ajudantes', equipe: 9, tempo_m2_dias: 0.1 },
      'comercial_complexo': { custo_m2: 60, mao_obra: '5 carpinteiros + 5 ajudantes', equipe: 9, tempo_m2_dias: 0.15 },
      'industrial': { custo_m2: 80, mao_obra: 'Equipe especializada', equipe: 9, tempo_m2_dias: 0.18 }
    },
    cor: 'bg-yellow-900',
    descricao: 'Instalação de portas internas e externas'
  },
  {
    id: 'acabamento_final',
    nome: 'Acabamento Final (Elétrico e Hidrossanitário)',
    categoria: 'Acabamento',
    icone: CheckCircle,
    duracaoDias: 10,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 40, mao_obra: '1 eletricista + 1 encanador + 2 ajudantes', equipe: 15, tempo_m2_dias: 0.1 },
      'residencial_padrao': { custo_m2: 60, mao_obra: '2 eletricistas + 2 encanadores + 3 ajudantes', equipe: 15, tempo_m2_dias: 0.15 },
      'residencial_alto': { custo_m2: 90, mao_obra: '3 eletricistas + 3 encanadores + 4 ajudantes', equipe: 15, tempo_m2_dias: 0.2 },
      'comercial_simples': { custo_m2: 70, mao_obra: '2 eletricistas + 2 encanadores + 3 ajudantes', equipe: 15, tempo_m2_dias: 0.18 },
      'comercial_complexo': { custo_m2: 110, mao_obra: '4 eletricistas + 4 encanadores + 5 ajudantes', equipe: 15, tempo_m2_dias: 0.25 },
      'industrial': { custo_m2: 150, mao_obra: 'Equipe especializada', equipe: 15, tempo_m2_dias: 0.3 }
    },
    cor: 'bg-green-700',
    descricao: 'Instalação de luminárias, tomadas, interruptores, louças, metais e testes finais'
  },
  {
    id: 'limpeza_final',
    nome: 'Limpeza Final',
    categoria: 'Finalização',
    icone: Home,
    duracaoDias: 3,
    custosPorTipo: {
      'residencial_popular': { custo_m2: 5, mao_obra: '2 ajudantes de limpeza', equipe: 16, tempo_m2_dias: 0.03 },
      'residencial_padrao': { custo_m2: 8, mao_obra: '3 ajudantes de limpeza', equipe: 16, tempo_m2_dias: 0.05 },
      'residencial_alto': { custo_m2: 12, mao_obra: '4 ajudantes de limpeza', equipe: 16, tempo_m2_dias: 0.07 },
      'comercial_simples': { custo_m2: 10, mao_obra: '3 ajudantes de limpeza', equipe: 16, tempo_m2_dias: 0.06 },
      'comercial_complexo': { custo_m2: 15, mao_obra: '5 ajudantes de limpeza', equipe: 16, tempo_m2_dias: 0.09 },
      'industrial': { custo_m2: 20, mao_obra: 'Equipe especializada', equipe: 16, tempo_m2_dias: 0.1 }
    },
    cor: 'bg-green-800',
    descricao: 'Limpeza geral da obra antes da entrega'
  }
];

// Mapeamento de equipes para cores
const equipeCores = {
  1: 'bg-blue-300', // Planejamento
  2: 'bg-green-500', // Preparação do Terreno
  3: 'bg-gray-600', // Fundação
  4: 'bg-blue-700', // Estrutura
  5: 'bg-orange-500', // Alvenaria
  6: 'bg-red-500', // Cobertura
  7: 'bg-purple-500', // Elétrica
  8: 'bg-blue-500', // Hidrossanitária
  9: 'bg-yellow-800', // Esquadrias/Serralheria
  10: 'bg-gray-400', // Reboco
  11: 'bg-yellow-600', // Revestimentos
  12: 'bg-indigo-500', // Gesso/Louças
  13: 'bg-pink-500', // Pintura
  14: 'bg-green-900', // Paisagismo
  15: 'bg-green-700', // Acabamento Final
  16: 'bg-green-800' // Limpeza Final
};

// Componente EquipeCard com funcionalidade de colapsar/expandir
const EquipeCard = ({ equipe }) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-medium flex items-center justify-between">
          <Badge style={{ backgroundColor: equipe.cor.replace('bg-', '#') }}>{equipe.nome}</Badge>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 h-auto"
          >
            <ChevronDown className={`h-4 w-4 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
          </Button>
        </CardTitle>
        <CardDescription className="text-sm">
          Entrada: {new Date(equipe.dataEntrada).toLocaleDateString('pt-BR')}<br />
          Saída: {new Date(equipe.dataSaida).toLocaleDateString('pt-BR')}
        </CardDescription>
      </CardHeader>
      {isExpanded && (
        <CardContent>
          <ul className="list-disc list-inside text-sm text-muted-foreground">
            {equipe.etapas && equipe.etapas.map((etapa, idx) => (
              <li key={idx}>{etapa}</li>
            ))}
          </ul>
        </CardContent>
      )}
    </Card>
  );
};

export default function CronogramaOrcamento() {
  const [etapaAtual, setEtapaAtual] = useState(0);
  const [tipoObra, setTipoObra] = useState('');
  const [areaTotal, setAreaTotal] = useState('');
  const [dataInicio, setDataInicio] = useState('');
  const [incluirMaoDeObra, setIncluirMaoDeObra] = useState(false);
  const [considerarDiasUteis, setConsiderarDiasUteis] = useState(true);
  const [etapasSelecionadas, setEtapasSelecionadas] = useState(() => {
    // Garante que tiposObra[0] exista antes de tentar acessá-lo
    const initialTipoObraValue = tiposObra.length > 0 ? tiposObra[0].value : '';
    return etapasBase.map(etapa => ({
      ...etapa,
      selecionada: false,
      // Garante que custo_m2 e tempo_m2_dias existam para o tipo de obra inicial
      custo_m2_personalizado: etapa.custosPorTipo[initialTipoObraValue]?.custo_m2 || 0,
      tempo_m2_dias_personalizado: etapa.custosPorTipo[initialTipoObraValue]?.tempo_m2_dias || 0
    }));
  });
  const [etapasPersonalizadas, setEtapasPersonalizadas] = useState([]);
  const [showModalNovaEtapa, setShowModalNovaEtapa] = useState(false);
  const [novaEtapa, setNovaEtapa] = useState({
    nome: '',
    descricao: '',
    custo_m2: '',
    tempo_m2_dias: '',
    etapaAnterior: ''
  });
  const [resultados, setResultados] = useState(null);
  const resultadosRef = useRef(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleNext = () => {
    setEtapaAtual(etapaAtual + 1);
  };

  const handleBack = () => {
    setEtapaAtual(etapaAtual - 1);
  };

  const handleTipoObraChange = (value) => {
    setTipoObra(value);
    const tipoSelecionado = tiposObra.find(t => t.value === value);
    if (tipoSelecionado) {
      setEtapasSelecionadas(prevEtapas =>
        prevEtapas.map(etapa => ({
          ...etapa,
          custo_m2_personalizado: etapa.custosPorTipo[tipoSelecionado.value]?.custo_m2 || 0,
          tempo_m2_dias_personalizado: etapa.custosPorTipo[tipoSelecionado.value]?.tempo_m2_dias || 0
        }))
      );
    }
  };

  const handleEtapaSelection = (id) => {
    setEtapasSelecionadas(prevEtapas =>
      prevEtapas.map(etapa =>
        etapa.id === id ? { ...etapa, selecionada: !etapa.selecionada } : etapa
      )
    );
  };

  const handleSelecionarTodas = () => {
    const todasSelecionadas = etapasSelecionadas.every(etapa => etapa.selecionada);
    setEtapasSelecionadas(prevEtapas =>
      prevEtapas.map(etapa => ({ ...etapa, selecionada: !todasSelecionadas }))
    );
  };

  const handleCustoM2Change = (id, value) => {
    setEtapasSelecionadas(prevEtapas =>
      prevEtapas.map(etapa =>
        etapa.id === id ? { ...etapa, custo_m2_personalizado: parseFloat(value) || 0 } : etapa
      )
    );
  };

  const handleTempoM2Change = (id, value) => {
    setEtapasSelecionadas(prevEtapas =>
      prevEtapas.map(etapa =>
        etapa.id === id ? { ...etapa, tempo_m2_dias_personalizado: parseFloat(value) || 0 } : etapa
      )
    );
  };

  const handleCriarNovaEtapa = () => {
    if (!novaEtapa.nome || !novaEtapa.custo_m2 || !novaEtapa.tempo_m2_dias) {
      alert('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    const novaEtapaCompleta = {
      id: `custom_${Date.now()}`,
      nome: novaEtapa.nome,
      descricao: novaEtapa.descricao || 'Etapa personalizada',
      custo_m2: parseFloat(novaEtapa.custo_m2),
      tempo_m2_dias: parseFloat(novaEtapa.tempo_m2_dias),
      etapaAnterior: novaEtapa.etapaAnterior,
      selecionada: true,
      cor: 'bg-purple-500',
      icone: () => null,
      isCustom: true
    };

    setEtapasPersonalizadas(prev => [...prev, novaEtapaCompleta]);
    setNovaEtapa({
      nome: '',
      descricao: '',
      custo_m2: '',
      tempo_m2_dias: '',
      etapaAnterior: ''
    });
    setShowModalNovaEtapa(false);
  };

  const handleRemoverEtapaPersonalizada = (id) => {
    setEtapasPersonalizadas(prev => prev.filter(etapa => etapa.id !== id));
  };

  const calcularCronogramaOrcamento = () => {
    console.log("Dados:", { tipoObra, areaTotal, dataInicio });

    if (!tipoObra || !areaTotal || !dataInicio) {
      console.error("Campos obrigatórios não preenchidos");
      alert("Por favor, preencha todos os campos obrigatórios na Etapa 1.");
      return;
    }

    console.log("Validação inicial passou");
    setIsLoading(true);

    try {
      const area = parseFloat(areaTotal);
      const tipo = tiposObra.find((t) => t.value === tipoObra);
      if (!tipo) {
        alert("Tipo de obra selecionado inválido.");
        return;
      }

      // Combina etapas selecionadas com etapas personalizadas
      const etapasParaCalcular = [
        ...etapasSelecionadas.filter((etapa) => etapa.selecionada),
        ...etapasPersonalizadas,
      ];

      console.log("Etapas para calcular:", etapasParaCalcular.length);

      if (etapasParaCalcular.length === 0) {
        console.error("Nenhuma etapa selecionada");
        alert("Por favor, selecione pelo menos uma etapa na Etapa 2.");
        setIsLoading(false);
        return;
      }

      // Função para ordenar etapas considerando dependências das etapas personalizadas
      const ordenarEtapasPorDependencias = (etapas) => {
        const etapasOrdenadas = [];
        const etapasProcessadas = new Set();

        // Primeiro, adiciona etapas sem dependências ou etapas padrão
        etapas.forEach((etapa) => {
          if (!etapa.isCustom || !etapa.etapaAnterior) {
            etapasOrdenadas.push(etapa);
            etapasProcessadas.add(etapa.id);
          }
        });

        // Depois, adiciona etapas personalizadas respeitando suas dependências
        let etapasRestantes = etapas.filter(
          (etapa) => etapa.isCustom && etapa.etapaAnterior
        );

        while (etapasRestantes.length > 0) {
          const etapasAdicionadas = [];

          etapasRestantes.forEach((etapa) => {
            if (etapasProcessadas.has(etapa.etapaAnterior)) {
              // Encontra a posição da etapa anterior
              const posicaoAnterior = etapasOrdenadas.findIndex(
                (e) => e.id === etapa.etapaAnterior
              );
              // Insere a nova etapa logo após a etapa anterior
              etapasOrdenadas.splice(posicaoAnterior + 1, 0, etapa);
              etapasProcessadas.add(etapa.id);
              etapasAdicionadas.push(etapa);
            }
          });

          // Remove etapas que foram adicionadas
          etapasRestantes = etapasRestantes.filter(
            (etapa) => !etapasAdicionadas.includes(etapa)
          );

          // Se não conseguiu adicionar nenhuma etapa, adiciona as restantes no final
          if (etapasAdicionadas.length === 0 && etapasRestantes.length > 0) {
            etapasOrdenadas.push(...etapasRestantes);
            break;
          }
        }

        return etapasOrdenadas;
      };

      const etapasOrdenadas = ordenarEtapasPorDependencias(etapasParaCalcular);

      let custoTotal = 0;
      let dataAtual = new Date(dataInicio);
      let cronogramaDetalhado = [];
      let tarefasGantt = [];
      let equipesResumo = {};

      etapasOrdenadas.forEach((etapa, index) => {
        // Para etapas personalizadas, usa os valores definidos pelo usuário
        let custoEtapaM2, tempoEtapaM2;

        if (etapa.isCustom) {
          custoEtapaM2 = etapa.custo_m2;
          tempoEtapaM2 = etapa.tempo_m2_dias;
        } else {
          custoEtapaM2 = etapa.custosPorTipo[tipoObra]?.custo_m2 || 0;
          tempoEtapaM2 = etapa.custosPorTipo[tipoObra]?.tempo_m2_dias || 0;
        }

        let custoMaterialEtapa = custoEtapaM2 * area;
        let custoMaoDeObraEtapa = incluirMaoDeObra ? custoMaterialEtapa * 0.4 : 0;

        const custoTotalEtapa = custoMaterialEtapa + custoMaoDeObraEtapa;
        custoTotal += custoTotalEtapa;

        let duracaoEtapa = Math.ceil(tempoEtapaM2 * area); // Duração em dias corridos
        if (duracaoEtapa === 0) duracaoEtapa = 1; // Garante no mínimo 1 dia

        let dataInicioEtapa = new Date(dataAtual);
        let dataFimEtapa;

        if (considerarDiasUteis) {
          dataFimEtapa = adicionarDiasUteis(dataInicioEtapa, duracaoEtapa);
        } else {
          dataFimEtapa = new Date(dataInicioEtapa);
          dataFimEtapa.setDate(dataFimEtapa.getDate() + duracaoEtapa);
        }

        cronogramaDetalhado.push({
          nome: etapa.nome,
          custoMaterial: custoMaterialEtapa,
          custoMaoDeObra: custoMaoDeObraEtapa,
          custoTotalEtapa: custoTotalEtapa,
          dataInicio: dataInicioEtapa.toISOString().split("T")[0],
          dataFim: dataFimEtapa.toISOString().split("T")[0],
          duracao: duracaoEtapa,
          equipe: etapa.isCustom ? "Equipe Personalizada" : (etapa.custosPorTipo[tipoObra]?.mao_obra || "Não Definido"),
          equipeId: etapa.isCustom ? 99 : (etapa.custosPorTipo[tipoObra]?.equipe || 0),
          cor: etapa.cor || "bg-purple-500",
        });

        tarefasGantt.push({
          id: etapa.id,
          name: etapa.nome,
          start: dataInicioEtapa,
          end: dataFimEtapa,
          progress: 0,
          type: "task",
          project: "Obra",
          styles: { backgroundColor: etapa.cor.replace("bg-", "#") }, // Adapta a cor para o Gantt
        });

        // Resumo das equipes
        const equipeId = etapa.custosPorTipo[tipoObra]?.equipe || 0;
        if (equipeId !== 0) { // Apenas adiciona se a equipe for definida
          const equipeNome = `Equipe ${equipeId}`;
          const equipeCor = equipeCores[equipeId];

          if (!equipesResumo[equipeId]) {
            equipesResumo[equipeId] = {
              nome: equipeNome,
              cor: equipeCor,
              dataEntrada: dataInicioEtapa,
              dataSaida: dataFimEtapa,
              etapas: [etapa.nome],
              equipeId: equipeId,
            };
          } else {
            if (dataInicioEtapa < equipesResumo[equipeId].dataEntrada) {
              equipesResumo[equipeId].dataEntrada = dataInicioEtapa;
            }
            if (dataFimEtapa > equipesResumo[equipeId].dataSaida) {
              equipesResumo[equipeId].dataSaida = dataFimEtapa;
            }
            equipesResumo[equipeId].etapas.push(etapa.nome);
          }
        }

        // Atualiza a data atual para a próxima etapa
        dataAtual = new Date(dataFimEtapa);
        dataAtual.setDate(dataAtual.getDate() + 1); // Próxima etapa começa no dia seguinte
      });

      const dataFinalObra = new Date(dataAtual);
      dataFinalObra.setDate(dataFinalObra.getDate() - 1); // Ajusta para o último dia da última etapa

      setResultados({
        tipoObra: tipo.label,
        areaTotal: area,
        dataInicio: dataInicio,
        dataFinal: dataFinalObra.toISOString().split("T")[0],
        custoTotal: custoTotal,
        cronogramaDetalhado: cronogramaDetalhado || [],
        tarefasGantt: tarefasGantt || [],
        equipesResumo: Object.values(equipesResumo).sort((a, b) => (a.equipeId || 0) - (b.equipeId || 0)),
      });

      setEtapaAtual(etapaAtual + 1); // Avança para a tela de resultados
      // Scroll suave para a seção de resultados
      setTimeout(() => {
        if (resultadosRef.current) {
          resultadosRef.current.scrollIntoView({ behavior: "smooth" });
        }
        setIsLoading(false);
      }, 100);
    } catch (error) {
      console.error("Erro no cálculo:", error);
      alert("Erro ao gerar cronograma. Tente novamente.");
    } finally {
      setIsLoading(false); // Sempre resetar loading
    }
  };

  const handleSavePdf = () => {
    const input = resultadosRef.current;
    if (input) {
      html2canvas(input, { scale: 2 }).then((canvas) => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');
        const imgWidth = 210; // A4 width in mm
        const pageHeight = 297; // A4 height in mm
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        let heightLeft = imgHeight;
        let position = 0;

        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;

        while (heightLeft >= 0) {
          position = heightLeft - imgHeight;
          pdf.addPage();
          pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
          heightLeft -= pageHeight;
        }
        pdf.save('cronograma_orcamento.pdf');
      });
    }
  };

  const handleVoltarInicio = () => {
    setEtapaAtual(0);
    setTipoObra('');
    setAreaTotal('');
    setDataInicio('');
    setIncluirMaoDeObra(false);
    setConsiderarDiasUteis(true);
    setEtapasSelecionadas(() => {
      // Garante que tiposObra[0] exista antes de tentar acessá-lo
      const initialTipoObraValue = tiposObra.length > 0 ? tiposObra[0].value : '';
      return etapasBase.map(etapa => ({
        ...etapa,
        selecionada: false,
        custo_m2_personalizado: etapa.custosPorTipo[initialTipoObraValue]?.custo_m2 || 0,
        tempo_m2_dias_personalizado: etapa.custosPorTipo[initialTipoObraValue]?.tempo_m2_dias || 0
      }));
    });
    setEtapasPersonalizadas([]); // Resetar etapas personalizadas
    setResultados(null);
  };

  return (
    <div className="container mx-auto p-4">
      {etapaAtual !== 0 && (
        <div className="fixed top-0 left-0 right-0 bg-white p-4 border-b z-10 md:relative md:p-0 md:border-b-0">
          <Button onClick={handleVoltarInicio} className="w-full md:w-auto">
            <ArrowLeft className="mr-2 h-4 w-4" /> Voltar para o Início
          </Button>
        </div>
      )}

      <h1 className="text-3xl font-bold text-center mb-8 mt-16 md:mt-8">Cronograma e Orçamento da Obra</h1>

      {isLoading && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg flex items-center">
            <RefreshCw className="animate-spin mr-3" />
            <span>Gerando cronograma e orçamento...</span>
          </div>
        </div>
      )}

      {etapaAtual === 0 && (
        <Card className="w-full max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle>Etapa 1: Informações Básicas</CardTitle>
            <CardDescription>Preencha os detalhes gerais da sua obra.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="tipoObra">Tipo de Obra</Label>
              <Select value={tipoObra} onValueChange={handleTipoObraChange}>
                <SelectTrigger id="tipoObra">
                  <SelectValue placeholder="Selecione o tipo de obra" />
                </SelectTrigger>
                <SelectContent>
                  {tiposObra.map(tipo => (
                    <SelectItem key={tipo.value} value={tipo.value}>
                      {tipo.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="areaTotal">Área Total (m²)</Label>
              <Input
                id="areaTotal"
                type="number"
                placeholder="Ex: 150"
                value={areaTotal}
                onChange={(e) => setAreaTotal(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="dataInicio">Data de Início</Label>
              <Input
                id="dataInicio"
                type="date"
                value={dataInicio}
                onChange={(e) => setDataInicio(e.target.value)}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="incluirMaoDeObra"
                checked={incluirMaoDeObra}
                onCheckedChange={setIncluirMaoDeObra}
              />
              <Label htmlFor="incluirMaoDeObra">Incluir Mão de Obra (40% a mais no valor)</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="considerarDiasUteis"
                checked={considerarDiasUteis}
                onCheckedChange={setConsiderarDiasUteis}
              />
              <Label htmlFor="considerarDiasUteis">Considerar apenas dias úteis (exclui fins de semana e feriados)</Label>
            </div>
            <Button onClick={handleNext} className="w-full">
              Próximo <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </CardContent>
        </Card>
      )}

      {etapaAtual === 1 && (
        <Card className="w-full max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle>Etapa 2: Seleção de Etapas e Detalhes</CardTitle>
            <CardDescription>Selecione as etapas da obra e ajuste os valores por m² e tempo por m² se necessário.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Etapas Disponíveis</h3>
              <div className="flex gap-2">
                <Button 
                  onClick={handleSelecionarTodas}
                  variant="outline"
                  size="sm"
                >
                  {etapasSelecionadas.every(etapa => etapa.selecionada) ? 'Desmarcar Todas' : 'Selecionar Todas'}
                </Button>
                <Button 
                  onClick={() => setShowModalNovaEtapa(true)}
                  variant="default"
                  size="sm"
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  + Nova Etapa
                </Button>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {etapasSelecionadas.map(etapa => (
                <Card
                  key={etapa.id}
                  className={`cursor-pointer ${etapa.selecionada ? 'border-blue-500 ring-2 ring-blue-500' : ''}`}
                  onClick={() => handleEtapaSelection(etapa.id)}
                >
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">{etapa.nome}</CardTitle>
                    <etapa.icone className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <p className="text-xs text-muted-foreground mb-2">{etapa.descricao}</p>
                    <div className="grid gap-2">
                      <Label htmlFor={`custo-${etapa.id}`} className="text-xs">Custo/m² (R$)</Label>
                      <Input
                        id={`custo-${etapa.id}`}
                        type="number"
                        placeholder="0"
                        value={etapa.custo_m2_personalizado}
                        onChange={(e) => handleCustoM2Change(etapa.id, e.target.value)}
                        onClick={(e) => e.stopPropagation()} // Evita desmarcar ao clicar no input
                        className="text-sm"
                      />
                    </div>
                    <div className="grid gap-2 mt-2">
                      <Label htmlFor={`tempo-${etapa.id}`} className="text-xs">Tempo/m² (dias)</Label>
                      <Input
                        id={`tempo-${etapa.id}`}
                        type="number"
                        step="0.01"
                        placeholder="0"
                        value={etapa.tempo_m2_dias_personalizado}
                        onChange={(e) => handleTempoM2Change(etapa.id, e.target.value)}
                        onClick={(e) => e.stopPropagation()} // Evita desmarcar ao clicar no input
                        className="text-sm"
                      />
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {/* Etapas Personalizadas */}
              {etapasPersonalizadas.map(etapa => (
                <Card
                  key={etapa.id}
                  className="border-purple-500 ring-2 ring-purple-500 bg-purple-50"
                >
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">{etapa.nome}</CardTitle>
                    <Button
                      onClick={() => handleRemoverEtapaPersonalizada(etapa.id)}
                      variant="ghost"
                      size="sm"
                      className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                    >
                      ×
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xs text-muted-foreground mb-2">{etapa.descricao}</p>
                    <div className="grid gap-2">
                      <Label className="text-xs">Custo/m²: R$ {etapa.custo_m2}</Label>
                      <Label className="text-xs">Tempo/m²: {etapa.tempo_m2_dias} dias</Label>
                      {etapa.etapaAnterior && (
                        <Label className="text-xs text-purple-600">
                          Após: {etapasSelecionadas.find(e => e.id === etapa.etapaAnterior)?.nome || 'Etapa removida'}
                        </Label>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            <div className="flex justify-between mt-6">
              <Button onClick={handleBack} variant="outline">
                <ArrowLeft className="mr-2 h-4 w-4" /> Voltar
              </Button>
              <Button onClick={calcularCronogramaOrcamento}>
                Gerar Cronograma e Orçamento <Calculator className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {etapaAtual === 2 && resultados && (
        <div ref={resultadosRef} className="w-full max-w-5xl mx-auto p-4 bg-white shadow-lg rounded-lg">
          <h2 className="text-2xl font-bold text-center mb-4">Resultados do Cronograma e Orçamento</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Tipo de Obra</CardTitle>
                <Building className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{resultados.tipoObra}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Área Total</CardTitle>
                <Home className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{resultados.areaTotal} m²</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Data Início</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{new Date(resultados.dataInicio).toLocaleDateString("pt-BR")}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Data Final</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{new Date(resultados.dataFinal).toLocaleDateString("pt-BR")}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Custo Total Estimado</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {resultados.custoTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                </div>
              </CardContent>
            </Card>
          </div>

          <h3 className="text-xl font-bold mt-6 mb-4">Detalhamento por Etapa</h3>
          <div className="overflow-x-auto">
            <table className="min-w-full bg-white">
              <thead>
                <tr>
                  <th className="py-2 px-4 text-left">Nome</th>
                  <th className="py-2 px-4 text-left">Duração (dias)</th>
                  <th className="py-2 px-4 text-left">Custo Material</th>
                  <th className="py-2 px-4 text-left">Custo Mão de Obra</th>
                  <th className="py-2 px-4 text-left">Custo Total Etapa</th>
                  <th className="py-2 px-4 text-left">Equipe</th>
                </tr>
              </thead>
              <tbody>
                {resultados.cronogramaDetalhado && resultados.cronogramaDetalhado.length > 0 ? resultados.cronogramaDetalhado.map((item, index) => (
                  <tr key={index} className={index % 2 === 0 ? 'bg-gray-50' : ''}>
                    <td className="py-2 px-4 border-b">{item.nome}</td>
                    <td className="py-2 px-4 border-b">{item.duracao}</td>
                    <td className="py-2 px-4 border-b">{item.custoMaterial.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</td>
                    <td className="py-2 px-4 border-b">{item.custoMaoDeObra.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</td>
                    <td className="py-2 px-4 border-b">{item.custoTotalEtapa.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}</td>
                    <td className="py-2 px-4 border-b">
                      <Badge style={{ backgroundColor: item.cor.replace('bg-', '#') }}>{item.equipe}</Badge>
                    </td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan="6" className="py-4 px-4 text-center text-gray-500">
                      Nenhuma etapa encontrada
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <h3 className="text-xl font-bold mt-6 mb-4">Gráfico de Gantt</h3>
          <div className="gantt-chart-container" style={{ height: '400px', overflow: 'auto' }}>
            <GanttChart tasks={resultados.tarefasGantt} />
          </div>

          <h3 className="text-xl font-bold mt-6 mb-4">Resumo das Equipes</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-20 md:mb-8">
            {resultados.equipesResumo && resultados.equipesResumo.length > 0 ? resultados.equipesResumo.map((equipe, index) => (
              <EquipeCard key={index} equipe={equipe} />
            )) : (
              <div className="col-span-full text-center text-gray-500">
                Nenhuma equipe encontrada
              </div>
            )}
          </div>

          {/* Barra de navegação fixa para mobile */}
          <div className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg p-4 md:hidden z-50">
            <div className="flex gap-2">
              <Button onClick={handleBack} variant="outline" className="flex-1">
                <ArrowLeft className="mr-2 h-4 w-4" /> Voltar
              </Button>
              <Button onClick={handleSavePdf} className="flex-1">
                <Download className="mr-2 h-4 w-4" /> PDF
              </Button>
            </div>
          </div>

          {/* Botões para desktop */}
          <div className="hidden md:flex justify-between mt-8">
            <Button onClick={handleBack} variant="outline">
              <ArrowLeft className="mr-2 h-4 w-4" /> Voltar
            </Button>
            <Button onClick={handleSavePdf}>
              Salvar como PDF <Download className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Modal para Nova Etapa */}
      {showModalNovaEtapa && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md mx-4">
            <h3 className="text-lg font-semibold mb-4">Criar Nova Etapa</h3>
          
            <div className="space-y-4">
              <div>
                <Label htmlFor="nome-etapa">Nome da Etapa *</Label>
                <Input
                  id="nome-etapa"
                  value={novaEtapa.nome}
                  onChange={(e) => setNovaEtapa(prev => ({ ...prev, nome: e.target.value }))}
                  placeholder="Ex: Instalação de Piso"
                />
              </div>
              
              <div>
                <Label htmlFor="descricao-etapa">Descrição</Label>
                <Input
                  id="descricao-etapa"
                  value={novaEtapa.descricao}
                  onChange={(e) => setNovaEtapa(prev => ({ ...prev, descricao: e.target.value }))}
                  placeholder="Descrição da etapa"
                />
              </div>
              
              <div>
                <Label htmlFor="custo-etapa">Custo por m² (R$) *</Label>
                <Input
                  id="custo-etapa"
                  type="number"
                  value={novaEtapa.custo_m2}
                  onChange={(e) => setNovaEtapa(prev => ({ ...prev, custo_m2: e.target.value }))}
                  placeholder="0"
                />
              </div>
              
              <div>
                <Label htmlFor="tempo-etapa">Tempo por m² (dias) *</Label>
                <Input
                  id="tempo-etapa"
                  type="number"
                  step="0.01"
                  value={novaEtapa.tempo_m2_dias}
                  onChange={(e) => setNovaEtapa(prev => ({ ...prev, tempo_m2_dias: e.target.value }))}
                  placeholder="0"
                />
              </div>
              
              <div>
                <Label htmlFor="etapa-anterior">Vem depois de qual etapa?</Label>
                <select
                  id="etapa-anterior"
                  value={novaEtapa.etapaAnterior}
                  onChange={(e) => setNovaEtapa(prev => ({ ...prev, etapaAnterior: e.target.value }))}
                  className="w-full p-2 border border-gray-300 rounded-md"
                >
                  <option value="">Selecione uma etapa (opcional)</option>
                  {etapasSelecionadas
                    .filter(etapa => etapa.selecionada)
                    .map(etapa => (
                      <option key={etapa.id} value={etapa.id}>
                        {etapa.nome}
                      </option>
                    ))}
                </select>
              </div>
            </div>
            
            <div className="flex justify-end gap-2 mt-6">
              <Button 
                onClick={() => setShowModalNovaEtapa(false)}
                variant="outline"
              >
                Cancelar
              </Button>
              <Button 
                onClick={handleCriarNovaEtapa}
                className="bg-purple-600 hover:bg-purple-700"
              >
                Criar Etapa
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}




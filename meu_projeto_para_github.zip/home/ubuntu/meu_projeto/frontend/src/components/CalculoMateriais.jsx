import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { ArrowLeft, Calculator, Building2, Package, Droplets, Hammer, Zap, MapPin, Paintbrush, Home, CheckCircle, FileText, ChevronDown, ChevronUp, Wrench, Palette, DoorOpen, Plus, Trash2, Edit } from 'lucide-react'

// Seções reorganizadas e otimizadas
const secoes = [
  {
    id: 'alvenaria',
    nome: 'Alvenaria',
    icone: Building2,
    descricao: 'Tijolos/blocos, argamassa, cimento, areia'
  },
  {
    id: 'fundacao',
    nome: 'Fundação',
    icone: Hammer,
    descricao: 'Sapatas, vigas baldrame, pilares'
  },
  {
    id: 'estrutura',
    nome: 'Estrutura',
    icone: Building2,
    descricao: 'Pilares, vigas, lajes, ferragem'
  },
  {
    id: 'cobertura',
    nome: 'Cobertura',
    icone: Home,
    descricao: 'Telhas, madeiramento, calhas, rufos'
  },
  {
    id: 'instalacoes_hidraulicas',
    nome: 'Instalações Hidráulicas',
    icone: Droplets,
    descricao: 'Tubos, conexões, caixas d\'água'
  },
  {
    id: 'instalacoes_eletricas',
    nome: 'Instalações Elétricas',
    icone: Zap,
    descricao: 'Fios, cabos, disjuntores, tomadas'
  },
  {
    id: 'reboco',
    nome: 'Reboco',
    icone: Wrench,
    descricao: 'Argamassa, cimento, areia, cal'
  },
  {
    id: 'revestimento',
    nome: 'Revestimento',
    icone: Package,
    descricao: 'Pisos, azulejos, argamassa colante'
  },
  {
    id: 'pintura',
    nome: 'Pintura',
    icone: Palette,
    descricao: 'Tinta, primer, massa corrida'
  },
  {
    id: 'esquadrias',
    nome: 'Esquadrias',
    icone: DoorOpen,
    descricao: 'Portas, janelas, ferragens'
  }
]

// Tipos de sapatas
const tiposSapata = [
  { id: 'isolada', nome: 'Sapata Isolada', descricao: 'Para pilares individuais' },
  { id: 'corrida', nome: 'Sapata Corrida', descricao: 'Para paredes' },
  { id: 'associada', nome: 'Sapata Associada', descricao: 'Para múltiplos pilares' }
]

// Tipos de blocos/tijolos para alvenaria
const tiposBlocos = [
  { 
    id: 'tijolo_ceramico', 
    nome: 'Tijolo Cerâmico Comum', 
    dimensoes: '9x19x19cm',
    consumo: 25, // unidades por m²
    argamassa: 0.020 // m³ por m²
  },
  { 
    id: 'bloco_ceramico_14', 
    nome: 'Bloco Cerâmico 14cm', 
    dimensoes: '14x19x19cm',
    consumo: 12.5,
    argamassa: 0.015
  },
  { 
    id: 'bloco_ceramico_19', 
    nome: 'Bloco Cerâmico 19cm', 
    dimensoes: '14x19x29cm',
    consumo: 8.5,
    argamassa: 0.015
  },
  { 
    id: 'bloco_concreto_14', 
    nome: 'Bloco de Concreto 14cm', 
    dimensoes: '14x19x39cm',
    consumo: 6.4,
    argamassa: 0.012
  },
  { 
    id: 'bloco_concreto_19', 
    nome: 'Bloco de Concreto 19cm', 
    dimensoes: '19x19x39cm',
    consumo: 6.4,
    argamassa: 0.012
  }
]

// Traços de argamassa
const tracosArgamassa = [
  {
    id: 'assentamento',
    nome: 'Assentamento (1:3)',
    descricao: 'Cimento:Areia:Água',
    cimento: 300, // kg por m³
    cal: 0, // kg por m³
    areia: 1.0, // m³ por m³
    agua: 0.2 // m³ por m³
  },
  {
    id: 'reboco',
    nome: 'Reboco (1:3)',
    descricao: 'Cimento:Areia',
    cimento: 400, // kg por m³
    cal: 0,
    areia: 1.2, // m³ por m³
    agua: 0.2 // m³ por m³
  }
]

// Resistências de concreto
const resistenciasConcreto = [
  { id: 'c20', nome: 'C20', fck: 20, traco: { cimento: 320, areia: 0.55, brita: 0.75 }, tracoVolume: '1:2.0:2.5' },
  { id: 'c25', nome: 'C25', fck: 25, traco: { cimento: 350, areia: 0.50, brita: 0.65 }, tracoVolume: '1:2.5:3.0' },
  { id: 'c30', nome: 'C30', fck: 30, traco: { cimento: 380, areia: 0.45, brita: 0.58 }, tracoVolume: '1:2.0:2.5' },
  { id: 'c40', nome: 'C40', fck: 40, traco: { cimento: 420, areia: 0.40, brita: 0.50 }, tracoVolume: '1:2.5:3.0' }
]

// Componente de seção colapsável otimizada para mobile
const SecaoColapsavel = ({ titulo, icone: Icone, isOpen, onToggle, children, badge = null }) => (
  <Card className="mb-2">
    <CardHeader 
      className="p-3 cursor-pointer" 
      onClick={onToggle}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icone className="h-4 w-4" />
          <CardTitle className="text-sm font-medium">{titulo}</CardTitle>
          {badge && <Badge variant="secondary" className="text-xs">{badge}</Badge>}
        </div>
        {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
      </div>
    </CardHeader>
    {isOpen && (
      <CardContent className="p-3 pt-0">
        {children}
      </CardContent>
    )}
  </Card>
)

// Componente de campo de entrada compacto
const CampoCompacto = ({ label, placeholder, value, onChange, type = "text", unit = "" }) => (
  <div className="space-y-1">
    <Label className="text-xs font-medium">{label}</Label>
    <div className="relative">
      <Input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className="h-8 text-sm pr-8"
      />
      {unit && (
        <span className="absolute right-2 top-1/2 transform -translate-y-1/2 text-xs text-gray-500">
          {unit}
        </span>
      )}
    </div>
  </div>
)

// Componente de resultado compacto
const ResultadoCompacto = ({ titulo, valor, unidade, destaque = false }) => (
  <div className={`p-2 rounded-lg ${destaque ? 'bg-blue-50 border border-blue-200' : 'bg-gray-50'}`}>
    <div className="text-xs text-gray-600">{titulo}</div>
    <div className={`text-sm font-semibold ${destaque ? 'text-blue-700' : 'text-gray-900'}`}>
      {valor} {unidade}
    </div>
  </div>
)

// Componente para item de lista (sapata, viga, pilar)
const ItemLista = ({ item, onEdit, onDelete, tipo }) => (
  <div className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
    <div className="flex-1">
      <div className="text-sm font-medium">
        {tipo === 'sapata' && `${item.tipo} - ${item.comprimento}x${item.largura}x${item.altura}m`}
        {tipo === 'viga' && `Viga ${item.largura}x${item.altura}cm - ${item.comprimento}m`}
        {tipo === 'pilar' && `Pilar ${item.largura}x${item.altura}cm - ${item.alturaTotal}m`}
        {tipo === 'cobertura' && `Cobertura: ${item.nome || 'Sem Nome'} - ${item.area}m²`}
      </div>
      <div className="text-xs text-gray-500">
        Qtd: {item.quantidade} | Vol: {item.volume?.toFixed(2)}m³
      </div>
    </div>
    <div className="flex gap-1">
      <Button variant="ghost" size="sm" onClick={() => onEdit(item)}>
        <Edit className="h-3 w-3" />
      </Button>
      <Button variant="ghost" size="sm" onClick={() => onDelete(item.id)}>
        <Trash2 className="h-3 w-3" />
      </Button>
    </div>
  </div>
)

export default function CalculoMateriais({ onBack }) {
  const [secaoSelecionada, setSecaoSelecionada] = useState(null)
  const [secaoAberta, setSecaoAberta] = useState({})
  const [dados, setDados] = useState({})
  const [resultados, setResultados] = useState({})
  
  // Estados específicos para alvenaria
  const [paredes, setParedes] = useState([])
  const [configuracaoAlvenaria, setConfiguracaoAlvenaria] = useState({
    tipoBloco: 'tijolo_ceramico',
    tracoArgamassa: 'assentamento',
    tipoRevestimento: 'nenhum', // 'nenhum', 'reboco'
    ladosReboco: 1, // 1 ou 2 lados
    precoBloco: 0.50, // R$ por unidade
    precoCimento: 0.5, // R$ por kg (para alvenaria, se usar cimento puro)
    precoCal: 0.30, // R$ por kg
    precoPedreiro: 180, // R$/dia
    precoAjudante: 100, // R$/dia
    produtividade: 10, // m²/dia por pedreiro
    precoAgua: 10, // R$/m³
    precoAreia: 30 // R$/m³ (para alvenaria)
  })

  // Estados específicos para fundação avançada
  const [sapatas, setSapatas] = useState([])
  const [vigas, setVigas] = useState([])
  const [pilares, setPilares] = useState([])
  const [editandoItem, setEditandoItem] = useState(null)
  const [tipoEditando, setTipoEditando] = useState(null)
  const [configuracoes, setConfiguracoes] = useState({
    resistenciaConcreto: 'c25',
    taxaAco: 80, // kg/m³
    precoConcreto: 400, // R$/m³ (manter para compatibilidade, mas não será usado diretamente)
    precoCimento: 0.5, // R$/kg (ou R$/saco, dependendo da unidade)
    precoAreia: 30, // R$/m³
    precoBrita: 40, // R$/m³
    precoAco: 7, // R$/kg
    precoArame: 8, // R$/kg
    precoForma: 45 // R$/m²
  })

  // Estados específicos para cobertura
  const [coberturas, setCoberturas] = useState([])
  const [configuracaoCobertura, setConfiguracaoCobertura] = useState({
    tipoTelha: 'ceramica',
    tipoMadeiramento: 'ripa',
    tipoCalha: 'pvc',
    tipoRufo: 'chapa',
    inclinacaoTelhado: '30',
    precoTelha: 1.50,
    precoMadeira: 15.00,
    precoCalha: 20.00,
    precoRufo: 25.00,
    precoPedreiroTelhado: 200,
    precoAjudanteTelhado: 120,
    produtividadeTelhado: 15 // m²/dia
  })

  const adicionarCobertura = () => {
    const novaCobertura = {
      id: Date.now(),
      nome: '',
      area: '',
      tipo: 'telhado_simples',
      quantidadeAguas: 2,
      comprimentoCumeeira: '',
      comprimentoRincao: '',
      comprimentoBeiral: '',
      comprimentoRufo: '',
      larguraCalha: '',
      comprimentoCalha: '',
      volumeMadeira: 0
    }
    setEditandoItem(novaCobertura)
    setTipoEditando('cobertura')
  }

  const salvarCobertura = (cobertura) => {
    const comprimento = parseFloat(cobertura.comprimento) || 0
    const largura = parseFloat(cobertura.largura) || 0
    const area = comprimento * largura
    const comprimentoCumeeira = parseFloat(cobertura.comprimentoCumeeira) || 0
    const comprimentoRincao = parseFloat(cobertura.comprimentoRincao) || 0
    const comprimentoBeiral = parseFloat(cobertura.comprimentoBeiral) || 0
    const comprimentoRufo = parseFloat(cobertura.comprimentoRufo) || 0
    const larguraCalha = parseFloat(cobertura.larguraCalha) || 0
    const comprimentoCalha = parseFloat(cobertura.comprimentoCalha) || 0

    const coberturaComCalculos = {
      ...cobertura,
      area: area.toFixed(2).toString(),
      comprimento: comprimento.toString(),
      largura: largura.toString(),
      comprimentoCumeeira: comprimentoCumeeira.toString(),
      comprimentoRincao: comprimentoRincao.toString(),
      comprimentoBeiral: comprimentoBeiral.toString(),
      comprimentoRufo: comprimentoRufo.toString(),
      larguraCalha: larguraCalha.toString(),
      comprimentoCalha: comprimentoCalha.toString()
    }

    if (coberturas.find(c => c.id === cobertura.id)) {
      setCoberturas(prev => prev.map(c => c.id === cobertura.id ? coberturaComCalculos : c))
    } else {
      setCoberturas(prev => [...prev, coberturaComCalculos])
    }
    setEditandoItem(null)
    setTipoEditando(null)
  }

  const excluirCobertura = (id) => {
    setCoberturas(prev => prev.filter(c => c.id !== id))
  }

  const atualizarConfiguracaoCobertura = (campo, valor) => {
    setConfiguracaoCobertura(prev => ({
      ...prev,
      [campo]: valor
    }))
  }

  const calcularCoberturaCompleta = () => {
    console.log("Iniciando cálculo da cobertura")
    console.log("Coberturas:", coberturas)
    console.log("Configuração:", configuracaoCobertura)

    const areaTotalCobertura = coberturas.reduce((total, cob) => {
      const comprimento = parseFloat(cob.comprimento) || 0;
      const largura = parseFloat(cob.largura) || 0;
      return total + (comprimento * largura || parseFloat(cob.area) || 0);
    }, 0);
    const comprimentoTotalCumeeira = coberturas.reduce((total, cob) => total + (parseFloat(cob.comprimentoCumeeira) || 0), 0);
    const comprimentoTotalRincao = coberturas.reduce((total, cob) => total + (parseFloat(cob.comprimentoRincao) || 0), 0);
    const comprimentoTotalBeiral = coberturas.reduce((total, cob) => total + (parseFloat(cob.comprimentoBeiral) || 0), 0);
    const comprimentoTotalRufo = coberturas.reduce((total, cob) => total + (parseFloat(cob.comprimentoRufo) || 0), 0);
    const comprimentoTotalCalha = coberturas.reduce((total, cob) => total + (parseFloat(cob.comprimentoCalha) || 0), 0);
    if (areaTotalCobertura === 0) {
      setResultados({})
      return
    }

    const tipoTelha = tiposTelha.find(t => t.id === configuracaoCobertura.tipoTelha)
    const inclinacao = inclinacoesTelhado.find(i => i.id === configuracaoCobertura.inclinacaoTelhado)
    const tipoMadeiramento = tiposMadeiramento.find(m => m.id === configuracaoCobertura.tipoMadeiramento)
    const tipoCalha = tiposCalha.find(c => c.id === configuracaoCobertura.tipoCalha)
    const tipoRufo = tiposRufo.find(r => r.id === configuracaoCobertura.tipoRufo)

    if (!tipoTelha || !inclinacao || !tipoMadeiramento || !tipoCalha || !tipoRufo) {
      return
    }

    const areaRealTelhado = areaTotalCobertura * inclinacao.fator

    // Telhas
    let quantidadeTelhas;
    if (tipoTelha.id === 'fibrocimento' && tipoTelha.comprimentoTelha && tipoTelha.larguraTelha) {
      // Para telhas de fibrocimento, calcular com base nas dimensões da telha
      const areaTelha = tipoTelha.comprimentoTelha * tipoTelha.larguraTelha; // Área de uma única telha
      quantidadeTelhas = Math.ceil(areaRealTelhado / areaTelha * (1 + tipoTelha.perdas));
    } else {
      // Para outros tipos de telha, usar o consumo por m²
      quantidadeTelhas = Math.ceil(areaRealTelhado * tipoTelha.consumo * (1 + tipoTelha.perdas));
    }
    // Madeiramento
    const quantidadeRipas = Math.ceil(areaRealTelhado * tipoTelha.consumoMadeira.ripa * (1 + tiposMadeiramento.find(m => m.id === 'ripa').perdas))
    const quantidadeCaibros = Math.ceil(areaRealTelhado * tipoTelha.consumoMadeira.caibro * (1 + tiposMadeiramento.find(m => m.id === 'caibro').perdas))
    const quantidadeTesouras = Math.ceil(areaRealTelhado * tipoTelha.consumoMadeira.tesoura * (1 + tiposMadeiramento.find(m => m.id === 'tesoura').perdas))

    // Calhas e Rufos
    const quantidadeCalhas = comprimentoTotalCalha
    const quantidadeRufos = comprimentoTotalRufo
    const quantidadeCumeeiras = comprimentoTotalCumeeira
    const quantidadeRincoes = comprimentoTotalRincao
    const quantidadeBeirais = comprimentoTotalBeiral

    // Custos
    const custoTelhas = quantidadeTelhas * parseFloat(configuracaoCobertura.precoTelha || tipoTelha.preco)
    const custoRipas = quantidadeRipas * parseFloat(configuracaoCobertura.precoMadeira || tiposMadeiramento.find(m => m.id === 'ripa').preco)
    const custoCaibros = quantidadeCaibros * parseFloat(configuracaoCobertura.precoMadeira || tiposMadeiramento.find(m => m.id === 'caibro').preco)
    const custoTesouras = quantidadeTesouras * parseFloat(configuracaoCobertura.precoMadeira || tiposMadeiramento.find(m => m.id === 'tesoura').preco)
    const custoMadeiramento = custoRipas + custoCaibros + custoTesouras
    const custoCalhas = quantidadeCalhas * parseFloat(configuracaoCobertura.precoCalha || tipoCalha.preco)
    const custoRufos = quantidadeRufos * parseFloat(configuracaoCobertura.precoRufo || tipoRufo.preco)
    const custoCumeeiras = quantidadeCumeeiras * parseFloat(configuracaoCobertura.precoTelha || tipoTelha.preco) * 2 // Custo da telha por metro linear, assumindo 2 telhas por metro
    const custoRincoes = quantidadeRincoes * parseFloat(configuracaoCobertura.precoTelha || tipoTelha.preco) * 2 // Custo da telha por metro linear, assumindo 2 telhas por metro
    const custoBeirais = quantidadeBeirais * parseFloat(configuracaoCobertura.precoMadeira || tiposMadeiramento.find(m => m.id === 'ripa').preco) * 0.5 // Custo da ripa por metro linear

    const custoMateriais = custoTelhas + custoMadeiramento + custoCalhas + custoRufos + custoCumeeiras + custoRincoes + custoBeirais

    // Mão de obra
    const precoPedreiroTelhado = parseFloat(configuracaoCobertura.precoPedreiroTelhado || 0)
    const precoAjudanteTelhado = parseFloat(configuracaoCobertura.precoAjudanteTelhado || 0)
    const produtividadeTelhado = parseFloat(configuracaoCobertura.produtividadeTelhado || 0)

    const diasTelhado = produtividadeTelhado > 0 ? areaRealTelhado / produtividadeTelhado : 0
    const custoMaoObra = diasTelhado * (precoPedreiroTelhado + precoAjudanteTelhado)

    const custoTotal = custoMateriais + custoMaoObra

    setResultados({
      areaTotalCobertura: areaTotalCobertura.toFixed(2),
      areaRealTelhado: areaRealTelhado.toFixed(2),
      tipoTelhaNome: tipoTelha.nome,
      quantidadeTelhas: quantidadeTelhas,
      tipoMadeiramentoNome: tipoMadeiramento.nome,
      quantidadeRipas: quantidadeRipas,
      quantidadeCaibros: quantidadeCaibros,
      quantidadeTesouras: quantidadeTesouras,
      tipoCalhaNome: tipoCalha.nome,
      quantidadeCalhas: quantidadeCalhas.toFixed(2),
      tipoRufoNome: tipoRufo.nome,
      quantidadeRufos: quantidadeRufos.toFixed(2),
      quantidadeCumeeiras: quantidadeCumeeiras.toFixed(2),
      quantidadeRincoes: quantidadeRincoes.toFixed(2),
      quantidadeBeirais: quantidadeBeirais.toFixed(2),
      custoTelhas: custoTelhas.toFixed(2),
      custoMadeiramento: custoMadeiramento.toFixed(2),
      custoCalhas: custoCalhas.toFixed(2),
      custoRufos: custoRufos.toFixed(2),
      custoCumeeiras: custoCumeeiras.toFixed(2),
      custoRincoes: custoRincoes.toFixed(2),
      custoBeirais: custoBeirais.toFixed(2),
      custoMateriais: custoMateriais.toFixed(2),
      custoMaoObra: custoMaoObra.toFixed(2),
      custoTotal: custoTotal.toFixed(2),
      prazoEstimado: diasTelhado.toFixed(1)
    })
  }

  // Funções para gerenciar sapatas

  const toggleSecao = (secaoId) => {
    setSecaoAberta(prev => ({
      ...prev,
      [secaoId]: !prev[secaoId]
    }))
  }

  const atualizarDado = (campo, valor) => {
    setDados(prev => ({
      ...prev,
      [campo]: valor
    }))
  }

  const atualizarConfiguracao = (campo, valor) => {
    setConfiguracoes(prev => ({
      ...prev,
      [campo]: valor
    }))
  }

  const atualizarConfiguracaoAlvenaria = (campo, valor) => {
    setConfiguracaoAlvenaria(prev => ({
      ...prev,
      [campo]: valor
    }))
  }

  // Funções para gerenciar paredes (alvenaria)
  const adicionarParede = () => {
    const novaParede = {
      id: Date.now(),
      nome: '',
      comprimento: '',
      altura: '',
      espessura: '',
      descontos: [], // array de {largura, altura, descricao}
      area: 0,
      areaLiquida: 0
    }
    setEditandoItem(novaParede)
    setTipoEditando('parede')
  }

  const salvarParede = (parede) => {
    const comprimento = parseFloat(parede.comprimento) || 0
    const altura = parseFloat(parede.altura) || 0
    const area = comprimento * altura
    
    // Calcular descontos
    const areaDescontos = parede.descontos.reduce((total, desconto) => {
      const larguraDesconto = parseFloat(desconto.largura) || 0
      const alturaDesconto = parseFloat(desconto.altura) || 0
      return total + (larguraDesconto * alturaDesconto)
    }, 0)
    
    const areaLiquida = Math.max(0, area - areaDescontos)
    
    const paredeComArea = { 
      ...parede, 
      comprimento: comprimento.toString(),
      altura: altura.toString(),
      area,
      areaLiquida
    }
    
    if (paredes.find(p => p.id === parede.id)) {
      setParedes(prev => prev.map(p => p.id === parede.id ? paredeComArea : p))
    } else {
      setParedes(prev => [...prev, paredeComArea])
    }
    setEditandoItem(null)
    setTipoEditando(null)
  }

  const excluirParede = (id) => {
    setParedes(prev => prev.filter(p => p.id !== id))
  }

  const adicionarDesconto = (paredeId) => {
    const parede = paredes.find(p => p.id === paredeId)
    if (parede) {
      const novoDesconto = {
        id: Date.now(),
        largura: '',
        altura: '',
        descricao: ''
      }
      const paredeAtualizada = {
        ...parede,
        descontos: [...(parede.descontos || []), novoDesconto]
      }
      setParedes(prev => prev.map(p => p.id === paredeId ? paredeAtualizada : p))
    }
  }

  const removerDesconto = (paredeId, descontoId) => {
    const parede = paredes.find(p => p.id === paredeId)
    if (parede) {
      const paredeAtualizada = {
        ...parede,
        descontos: parede.descontos.filter(d => d.id !== descontoId)
      }
      setParedes(prev => prev.map(p => p.id === paredeId ? paredeAtualizada : p))
    }
  }

  // Funções para gerenciar sapatas
  const adicionarSapata = () => {
    const novaSapata = {
      id: Date.now(),
      tipo: 'Sapata Isolada',
      comprimento: '',
      largura: '',
      altura: '',
      quantidade: 1,
      volume: 0
    }
    setEditandoItem(novaSapata)
    setTipoEditando('sapata')
  }

  const salvarSapata = (sapata) => {
    const comprimento = parseFloat(sapata.comprimento) || 1.20
    const largura = parseFloat(sapata.largura) || 1.20
    const altura = parseFloat(sapata.altura) || 0.30
    const quantidade = parseInt(sapata.quantidade) || 1
    const volume = comprimento * largura * altura * quantidade
    
    console.log('Salvando sapata:', { comprimento, largura, altura, quantidade, volume })
    
    const sapataComVolume = { 
      ...sapata, 
      comprimento: comprimento.toString(),
      largura: largura.toString(),
      altura: altura.toString(),
      quantidade: quantidade.toString(),
      volume 
    }
    
    if (sapatas.find(s => s.id === sapata.id)) {
      setSapatas(prev => prev.map(s => s.id === sapata.id ? sapataComVolume : s))
    } else {
      setSapatas(prev => [...prev, sapataComVolume])
    }
    setEditandoItem(null)
    setTipoEditando(null)
  }

  const excluirSapata = (id) => {
    setSapatas(prev => prev.filter(s => s.id !== id))
  }

  // Funções para gerenciar vigas
  const adicionarViga = () => {
    const novaViga = {
      id: Date.now(),
      largura: '',
      altura: '',
      comprimento: '',
      quantidade: 1,
      volume: 0
    }
    setEditandoItem(novaViga)
    setTipoEditando('viga')
  }

  const salvarViga = (viga) => {
    const volume = parseFloat(viga.largura) * parseFloat(viga.altura) * parseFloat(viga.comprimento) * parseInt(viga.quantidade)
    const vigaComVolume = { ...viga, volume }
    
    if (vigas.find(v => v.id === viga.id)) {
      setVigas(prev => prev.map(v => v.id === viga.id ? vigaComVolume : v))
    } else {
      setVigas(prev => [...prev, vigaComVolume])
    }
    setEditandoItem(null)
    setTipoEditando(null)
  }

  const excluirViga = (id) => {
    setVigas(prev => prev.filter(v => v.id !== id))
  }

  // Funções para gerenciar pilares
  const adicionarPilar = () => {
    const novoPilar = {
      id: Date.now(),
      largura: '',
      altura: '',
      alturaTotal: '',
      quantidade: 1,
      volume: 0
    }
    setEditandoItem(novoPilar)
    setTipoEditando('pilar')
  }

  const salvarPilar = (pilar) => {
    const volume = parseFloat(pilar.largura) * parseFloat(pilar.altura) * parseFloat(pilar.alturaTotal) * parseInt(pilar.quantidade)
    const pilarComVolume = { ...pilar, volume }
    
    if (pilares.find(p => p.id === pilar.id)) {
      setPilares(prev => prev.map(p => p.id === pilar.id ? pilarComVolume : p))
    } else {
      setPilares(prev => [...prev, pilarComVolume])
    }
    setEditandoItem(null)
    setTipoEditando(null)
  }

  const excluirPilar = (id) => {
    setPilares(prev => prev.filter(p => p.id !== id))
  }

  const calcularAlvenariaCompleta = () => {
    console.log("Iniciando cálculo da alvenaria")
    console.log("Paredes:", paredes)
    console.log("Configuração:", configuracaoAlvenaria)
    
    const areaTotal = paredes.reduce((total, parede) => total + (parede.areaLiquida || 0), 0)
    console.log("Área Total Calculada:", areaTotal)
    
    if (areaTotal === 0) {
      console.log("Área total é zero, não calculando")
      setResultados({})
      return
    }

    // Buscar dados do tipo de bloco selecionado
    const tipoBloco = tiposBlocos.find(bloco => bloco.id === configuracaoAlvenaria.tipoBloco)
    const tracoArgamassaAssentamento = tracosArgamassa.find(traco => traco.id === 'assentamento')
    const tracoArgamassaReboco = tracosArgamassa.find(traco => traco.id === 'reboco')

    console.log("Tipo de Bloco:", tipoBloco)
    console.log("Traço de Argamassa de Assentamento:", tracoArgamassaAssentamento)
    console.log("Tipo de Revestimento:", configuracaoAlvenaria.tipoRevestimento)
    console.log("Traço de Argamassa de Reboco:", tracoArgamassaReboco)
    
    if (!tipoBloco || !tracoArgamassaAssentamento) {
      console.log("Tipo de bloco ou traço de assentamento não encontrado")
      return
    }

    // Cálculo de materiais para alvenaria (assentamento)
    const quantidadeBlocos = Math.ceil(areaTotal * tipoBloco.consumo)
    const volumeArgamassaAssentamento = areaTotal * tipoBloco.argamassa * 1.1 // 10% de perda
    
    let cimentoTotal = 0
    let calTotal = 0
    let areiaTotal = 0
    let aguaTotal = 0
    let volumeArgamassaTotal = 0

    // Adicionar materiais de assentamento
    cimentoTotal += Math.ceil((volumeArgamassaAssentamento * tracoArgamassaAssentamento.cimento) / 50) // sacos de 50kg
    calTotal += volumeArgamassaAssentamento * (tracoArgamassaAssentamento.cal || 0) // kg
    areiaTotal += volumeArgamassaAssentamento * tracoArgamassaAssentamento.areia // m³
    aguaTotal += volumeArgamassaAssentamento * (tracoArgamassaAssentamento.agua || 0) // m³
    volumeArgamassaTotal += volumeArgamassaAssentamento

    // Adicionar materiais de revestimento (reboco), se selecionado
    if (configuracaoAlvenaria.tipoRevestimento === 'reboco' && tracoArgamassaReboco) {
      const areaReboco = areaTotal * configuracaoAlvenaria.ladosReboco;
      const volumeArgamassaReboco = areaReboco * 0.015 * 1.1; // 1.5cm de espessura para reboco, 10% de perda
      cimentoTotal += Math.ceil((volumeArgamassaReboco * tracoArgamassaReboco.cimento) / 50);
      calTotal += volumeArgamassaReboco * (tracoArgamassaReboco.cal || 0);
      areiaTotal += volumeArgamassaReboco * tracoArgamassaReboco.areia;
      aguaTotal += volumeArgamassaReboco * (tracoArgamassaReboco.agua || 0);
      volumeArgamassaTotal += volumeArgamassaReboco;
    }

    console.log("Quantidade de Blocos:", quantidadeBlocos)
    console.log("Volume de Argamassa Total:", volumeArgamassaTotal)
    console.log("Cimento Total:", cimentoTotal)
    console.log("Cal Total:", calTotal)
    console.log("Areia Total:", areiaTotal)
    console.log("Água Total:", aguaTotal)

    // Custos dos materiais
    const precoBloco = parseFloat(configuracaoAlvenaria.precoBloco || 0)
    const precoCimentoAlvenaria = parseFloat(configuracaoAlvenaria.precoCimento || 0)
    const precoCal = parseFloat(configuracaoAlvenaria.precoCal || 0)
    const precoAreiaAlvenaria = parseFloat(configuracaoAlvenaria.precoAreia || 0)
    const precoAguaAlvenaria = parseFloat(configuracaoAlvenaria.precoAgua || 0)

    const custoBlocos = quantidadeBlocos * precoBloco
    const custoCimento = cimentoTotal * (precoCimentoAlvenaria * 50) // preço por saco
    const custoCal = calTotal * precoCal
    const custoAreia = areiaTotal * precoAreiaAlvenaria
    const custoAgua = aguaTotal * precoAguaAlvenaria
    const custoMateriais = custoBlocos + custoCimento + custoCal + custoAreia + custoAgua
    console.log("Custo Blocos:", custoBlocos)
    console.log("Custo Cimento:", custoCimento)
    console.log("Custo Cal:", custoCal)
    console.log("Custo Areia:", custoAreia)
    console.log("Custo Água:", custoAgua)
    console.log("Custo Materiais Total:", custoMateriais)

    // Mão de obra e tempo de execução
    const precoPedreiro = parseFloat(configuracaoAlvenaria.precoPedreiro || 0)
    const precoAjudante = parseFloat(configuracaoAlvenaria.precoAjudante || 0)
    const produtividade = parseFloat(configuracaoAlvenaria.produtividade || 0)

    const diasPedreiro = produtividade > 0 ? areaTotal / produtividade : 0
    const diasAjudante = diasPedreiro // Assumindo 1 ajudante por pedreiro

    const custoPedreiro = diasPedreiro * precoPedreiro
    const custoAjudante = diasAjudante * precoAjudante
    const custoMaoObra = custoPedreiro + custoAjudante
    console.log("Custo Mão de Obra:", custoMaoObra)

    const custoTotal = custoMateriais + custoMaoObra
    const prazoEstimado = Math.max(diasPedreiro, diasAjudante)

    setResultados({
      areaTotal: areaTotal.toFixed(2),
      tipoBlocoNome: tipoBloco.nome,
      quantidadeBlocos: quantidadeBlocos,
      tipoTracoNome: tracoArgamassaAssentamento.nome,
      volumeArgamassa: volumeArgamassaTotal.toFixed(2),
      cimentoArgamassa: cimentoTotal,
      calArgamassa: calTotal.toFixed(2),
      areiaArgamassa: areiaTotal.toFixed(2),
      aguaArgamassa: aguaTotal.toFixed(2),
      custoBlocos: custoBlocos.toFixed(2),
      custoCimento: custoCimento.toFixed(2),
      custoCal: custoCal.toFixed(2),
      custoAreia: custoAreia.toFixed(2),
      custoAgua: custoAgua.toFixed(2),
      custoMateriais: custoMateriais.toFixed(2),
      custoPedreiro: custoPedreiro.toFixed(2),
      custoAjudante: custoAjudante.toFixed(2),
      custoMaoObra: custoMaoObra.toFixed(2),
      custoTotal: custoTotal.toFixed(2),
      prazoEstimado: prazoEstimado.toFixed(1),
      diasPedreiro: diasPedreiro.toFixed(1),
      diasAjudante: diasAjudante.toFixed(1),
    })
  }
  const calcularFundacaoCompleta = () => {
    console.log("Iniciando cálculo da fundação")
    console.log('Vigas:', vigas)
    console.log('Pilares:', pilares)
    
    const volumeTotalSapatas = sapatas.reduce((total, sapata) => total + (sapata.volume || 0), 0)
    const volumeTotalVigas = vigas.reduce((total, viga) => total + (viga.volume || 0), 0)
    const volumeTotalPilares = pilares.reduce((total, pilar) => total + (pilar.volume || 0), 0)
    const volumeTotal = volumeTotalSapatas + volumeTotalVigas + volumeTotalPilares

    console.log('Volumes calculados:', { volumeTotalSapatas, volumeTotalVigas, volumeTotalPilares, volumeTotal })

    // Se não há volume, não calcular
    if (volumeTotal === 0) {
      console.log('Volume total é zero, não calculando')
      setResultados({})
      return
    }

    // Materiais
    const concreto = volumeTotal * 1.05 // 5% de perda
    const { cimento: cimentoPorM3, areia: areiaPorM3, brita: britaPorM3 } = resistenciasConcreto.find(res => res.id === configuracoes.resistenciaConcreto)?.traco || { cimento: 0, areia: 0, brita: 0 }

    const cimento = Math.ceil(concreto * (cimentoPorM3 / 50)) // Convertendo kg para sacos (considerando saco de 50kg)
    const areia = concreto * areiaPorM3 // m³ de areia
    const brita = concreto * britaPorM3 // m³ de brita
    const aco = volumeTotal * parseFloat(configuracoes.taxaAco || 80) // kg de aço
    const arame = Math.ceil(aco * 0.05) // 5% do peso do aço em arame
    
    // Cálculo da área de formas (apenas laterais)
    let areaForma = 0
    // Sapatas: perímetro × altura
    sapatas.forEach(sapata => {
      const comprimento = parseFloat(sapata.comprimento) || 0
      const largura = parseFloat(sapata.largura) || 0
      const altura = parseFloat(sapata.altura) || 0
      const quantidade = parseInt(sapata.quantidade) || 0
      const perimetro = 2 * (comprimento + largura)
      areaForma += perimetro * altura * quantidade
    })
    // Vigas: 2 × altura × comprimento (duas faces laterais)
    vigas.forEach(viga => {
      const altura = parseFloat(viga.altura) || 0
      const comprimento = parseFloat(viga.comprimento) || 0
      const quantidade = parseInt(viga.quantidade) || 0
      areaForma += 2 * altura * comprimento * quantidade
    })
    // Pilares: perímetro × altura total
    pilares.forEach(pilar => {
      const largura = parseFloat(pilar.largura) || 0
      const altura = parseFloat(pilar.altura) || 0
      const alturaTotal = parseFloat(pilar.alturaTotal) || 0
      const quantidade = parseInt(pilar.quantidade) || 0
      const perimetro = 2 * (largura + altura)
      areaForma += perimetro * alturaTotal * quantidade
    })

    // Custos materiais
    const custoCimento = cimento * (parseFloat(configuracoes.precoCimento || 0.5) * 50) // Preço por saco de cimento (50kg)
    const custoAreia = areia * parseFloat(configuracoes.precoAreia || 30) // Preço por m³ de areia
    const custoBrita = brita * parseFloat(configuracoes.precoBrita || 40) // Preço por m³ de brita
    const custoConcreto = custoCimento + custoAreia + custoBrita
    const custoAco = aco * parseFloat(configuracoes.precoAco || 7)
    const custoArame = arame * parseFloat(configuracoes.precoArame || 8)
    const custoForma = areaForma * parseFloat(configuracoes.precoForma || 45)
    const custoMateriais = custoConcreto + custoAco + custoArame + custoForma

    // Mão de obra com cálculos granulares baseados na dificuldade
    // Fatores de dificuldade baseados no volume e complexidade
    const fatorDificuldadeEscavacao = volumeTotal > 10 ? 1.2 : volumeTotal > 5 ? 1.1 : 1.0
    const fatorDificuldadeConcretagem = concreto > 15 ? 1.3 : concreto > 8 ? 1.15 : 1.0
    const fatorDificuldadeArmacao = aco > 800 ? 1.25 : aco > 400 ? 1.1 : 1.0
    const fatorDificuldadeFormas = areaForma > 50 ? 1.2 : areaForma > 25 ? 1.1 : 1.0

    // Cálculos granulares (com frações de dias)
    const diasEscavacao = Math.round((volumeTotal * 1.2 / 3) * fatorDificuldadeEscavacao * 10) / 10 // Produtividade: 3m³/dia
    const diasConcretagem = Math.round((concreto * 0.3) * fatorDificuldadeConcretagem * 10) / 10 // Produtividade: 0.3 dias/m³
    const diasArmacao = Math.round((aco / 150) * fatorDificuldadeArmacao * 10) / 10 // Produtividade: 150kg/dia
    const diasFormas = Math.round((areaForma / 10) * fatorDificuldadeFormas * 10) / 10 // Produtividade: 10m²/dia
    
    const diasTotais = Math.max(diasEscavacao, diasConcretagem, diasArmacao, diasFormas)
    
    // Custos de mão de obra
    const custoEscavacao = diasEscavacao * parseFloat(configuracoes.precoAjudante || 100)
    const custoConcretagem = diasConcretagem * (parseFloat(configuracoes.precoPedreiro || 180) + 2 * parseFloat(configuracoes.precoAjudante || 100))
    const custoArmacao = diasArmacao * parseFloat(configuracoes.precoArmador || 200)
    const custoFormas = diasFormas * parseFloat(configuracoes.precoCarpinteiro || 220)
    const custoMaoObra = custoEscavacao + custoConcretagem + custoArmacao + custoFormas

    // Custo total
    const custoTotal = custoMateriais + custoMaoObra

    setResultados({
      volumeTotal: volumeTotal.toFixed(2),
      volumeSapatas: volumeTotalSapatas.toFixed(2),
      volumeVigas: volumeTotalVigas.toFixed(2),
      volumePilares: volumeTotalPilares.toFixed(2),
      concreto: concreto.toFixed(2),
      cimento,
      areia: areia.toFixed(2),
      brita: brita.toFixed(2),
      aco: aco.toFixed(0),
      arame,
      areaForma: areaForma.toFixed(2),
      custoMateriais: custoMateriais.toFixed(2),
      custoMaoObra: custoMaoObra.toFixed(2),
      custoTotal: custoTotal.toFixed(2),
      prazoEstimado: diasTotais.toFixed(1),
      // Detalhamento de custos
      custoConcreto: custoConcreto.toFixed(2),
      custoAco: custoAco.toFixed(2),
      custoArame: custoArame.toFixed(2),
      custoForma: custoForma.toFixed(2),
      custoEscavacao: custoEscavacao.toFixed(2),
      custoConcretagem: custoConcretagem.toFixed(2),
      custoArmacao: custoArmacao.toFixed(2),
      custoFormas: custoFormas.toFixed(2),
      // Detalhamento de dias
      diasEscavacao: diasEscavacao.toFixed(1),
      diasConcretagem: diasConcretagem.toFixed(1),
      diasArmacao: diasArmacao.toFixed(1),
      diasFormas: diasFormas.toFixed(1),
    })
  }

  // Formulário de edição de item
  const renderFormularioEdicao = () => {
    if (!editandoItem) return null

    return (
      <Card className="mb-4 border-blue-200">
        <CardHeader className="p-3">
          <CardTitle className="text-sm">
            {tipoEditando === 'sapata' && 'Adicionar/Editar Sapata'}
            {tipoEditando === 'viga' && 'Adicionar/Editar Viga Baldrame'}
            {tipoEditando === 'pilar' && 'Adicionar/Editar Pilar'}
            {tipoEditando === 'parede' && 'Adicionar/Editar Parede'}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-3 pt-0">
          <div className="space-y-3">
            {tipoEditando === 'parede' && (
              <>
                <CampoCompacto
                  label="Nome da Parede"
                  placeholder="Parede Externa"
                  value={editandoItem.nome}
                  onChange={(e) => setEditandoItem(prev => ({ ...prev, nome: e.target.value }))}
                />
                <div className="grid grid-cols-2 gap-2">
                  <CampoCompacto
                    label="Comprimento"
                    placeholder="5.00"
                    value={editandoItem.comprimento}
                    onChange={(e) => setEditandoItem(prev => ({ ...prev, comprimento: e.target.value }))}
                    unit="m"
                  />
                  <CampoCompacto
                    label="Altura"
                    placeholder="2.80"
                    value={editandoItem.altura}
                    onChange={(e) => setEditandoItem(prev => ({ ...prev, altura: e.target.value }))}
                    unit="m"
                  />
                </div>
                
                {editandoItem.descontos && editandoItem.descontos.length > 0 && (
                  <div>
                    <Label className="text-xs">Descontos (Portas/Janelas)</Label>
                    {editandoItem.descontos.map((desconto, index) => (
                      <div key={desconto.id || index} className="grid grid-cols-3 gap-1 mt-1">
                        <Input
                          placeholder="Largura"
                          value={desconto.largura}
                          onChange={(e) => {
                            const novosDescontos = [...editandoItem.descontos]
                            novosDescontos[index] = { ...desconto, largura: e.target.value }
                            setEditandoItem(prev => ({ ...prev, descontos: novosDescontos }))
                          }}
                          className="h-6 text-xs"
                        />
                        <Input
                          placeholder="Altura"
                          value={desconto.altura}
                          onChange={(e) => {
                            const novosDescontos = [...editandoItem.descontos]
                            novosDescontos[index] = { ...desconto, altura: e.target.value }
                            setEditandoItem(prev => ({ ...prev, descontos: novosDescontos }))
                          }}
                          className="h-6 text-xs"
                        />
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            const novosDescontos = editandoItem.descontos.filter((_, i) => i !== index)
                            setEditandoItem(prev => ({ ...prev, descontos: novosDescontos }))
                          }}
                          className="h-6 px-1"
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    const novoDesconto = { id: Date.now(), largura: '', altura: '', descricao: 'Porta/Janela' }
                    setEditandoItem(prev => ({ 
                      ...prev, 
                      descontos: [...(prev.descontos || []), novoDesconto] 
                    }))
                  }}
                  className="w-full h-6"
                >
                  <Plus className="h-3 w-3 mr-1" />
                  Adicionar Desconto
                </Button>
              </>
            )}

            {tipoEditando === 'sapata' && (
              <>
                <div>
                  <Label className="text-xs">Tipo de Sapata</Label>
                  <Select 
                    value={editandoItem.tipo} 
                    onValueChange={(value) => setEditandoItem(prev => ({ ...prev, tipo: value }))}
                  >
                    <SelectTrigger className="h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {tiposSapata.map(tipo => (
                        <SelectItem key={tipo.id} value={tipo.nome}>{tipo.nome}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <CampoCompacto
                    label="Comprimento"
                    placeholder="1.20"
                    value={editandoItem.comprimento}
                    onChange={(e) => setEditandoItem(prev => ({ ...prev, comprimento: e.target.value }))}
                    unit="m"
                  />
                  <CampoCompacto
                    label="Largura"
                    placeholder="1.20"
                    value={editandoItem.largura}
                    onChange={(e) => setEditandoItem(prev => ({ ...prev, largura: e.target.value }))}
                    unit="m"
                  />
                  <CampoCompacto
                    label="Altura"
                    placeholder="0.30"
                    value={editandoItem.altura}
                    onChange={(e) => setEditandoItem(prev => ({ ...prev, altura: e.target.value }))}
                    unit="m"
                  />
                </div>
              </>
            )}

            {tipoEditando === 'viga' && (
              <div className="grid grid-cols-3 gap-2">
                <CampoCompacto
                  label="Largura"
                  placeholder="0.20"
                  value={editandoItem.largura}
                  onChange={(e) => setEditandoItem(prev => ({ ...prev, largura: e.target.value }))}
                  unit="m"
                />
                <CampoCompacto
                  label="Altura"
                  placeholder="0.40"
                  value={editandoItem.altura}
                  onChange={(e) => setEditandoItem(prev => ({ ...prev, altura: e.target.value }))}
                  unit="m"
                />
                <CampoCompacto
                  label="Comprimento"
                  placeholder="10.00"
                  value={editandoItem.comprimento}
                  onChange={(e) => setEditandoItem(prev => ({ ...prev, comprimento: e.target.value }))}
                  unit="m"
                />
              </div>
            )}

            {tipoEditando === 'pilar' && (
              <div className="grid grid-cols-3 gap-2">
                <CampoCompacto
                  label="Largura"
                  placeholder="0.20"
                  value={editandoItem.largura}
                  onChange={(e) => setEditandoItem(prev => ({ ...prev, largura: e.target.value }))}
                  unit="m"
                />
                <CampoCompacto
                  label="Altura"
                  placeholder="0.20"
                  value={editandoItem.altura}
                  onChange={(e) => setEditandoItem(prev => ({ ...prev, altura: e.target.value }))}
                  unit="m"
                />
                <CampoCompacto
                  label="Altura Total"
                  placeholder="3.00"
                  value={editandoItem.alturaTotal}
                  onChange={(e) => setEditandoItem(prev => ({ ...prev, alturaTotal: e.target.value }))}
                  unit="m"
                />
              </div>
            )}

            {tipoEditando === 'pilar' && (
              <div className="grid grid-cols-3 gap-2">
                <CampoCompacto
                  label="Largura"
                  placeholder="0.20"
                  value={editandoItem.largura}
                  onChange={(e) => setEditandoItem(prev => ({ ...prev, largura: e.target.value }))}
                  unit="m"
                />
                <CampoCompacto
                  label="Altura"
                  placeholder="0.20"
                  value={editandoItem.altura}
                  onChange={(e) => setEditandoItem(prev => ({ ...prev, altura: e.target.value }))}
                  unit="m"
                />
                <CampoCompacto
                  label="Altura Total"
                  placeholder="3.00"
                  value={editandoItem.alturaTotal}
                  onChange={(e) => setEditandoItem(prev => ({ ...prev, alturaTotal: e.target.value }))}
                  unit="m"
                />
              </div>
            )}

            {tipoEditando === 'cobertura' && (
              <>
                <CampoCompacto
                  label="Nome da Cobertura"
                  placeholder="Telhado Principal"
                  value={editandoItem.nome}
                  onChange={(e) => setEditandoItem(prev => ({ ...prev, nome: e.target.value }))}
                />
                <CampoCompacto
                  label="Área da Cobertura"
                  placeholder="100.00"
                  value={editandoItem.area}
                  onChange={(e) => setEditandoItem(prev => ({ ...prev, area: e.target.value }))}
                  unit="m²"
                />
                <div className="grid grid-cols-2 gap-2">
                  <CampoCompacto
                    label="Comprimento"
                    placeholder="10.00"
                    value={editandoItem.comprimento}
                    onChange={(e) => setEditandoItem(prev => ({ ...prev, comprimento: e.target.value }))}
                    unit="m"
                  />
                  <CampoCompacto
                    label="Largura"
                    placeholder="5.00"
                    value={editandoItem.largura}
                    onChange={(e) => setEditandoItem(prev => ({ ...prev, largura: e.target.value }))}
                    unit="m"
                  />
                </div>
                <div>
                  <Label className="text-xs">Tipo de Cobertura</Label>
                  <Select 
                    value={editandoItem.tipo} 
                    onValueChange={(value) => setEditandoItem(prev => ({ ...prev, tipo: value }))}
                  >
                    <SelectTrigger className="h-8">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="telhado_simples">Telhado Simples</SelectItem>
                      <SelectItem value="telhado_multiplas_aguas">Telhado Múltiplas Águas</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {editandoItem.tipo === 'telhado_multiplas_aguas' && (
                  <CampoCompacto
                    label="Quantidade de Águas"
                    placeholder="2"
                    value={editandoItem.quantidadeAguas}
                    onChange={(e) => setEditandoItem(prev => ({ ...prev, quantidadeAguas: e.target.value }))}
                    type="number"
                  />
                )}
                <div className="grid grid-cols-2 gap-2">
                  <CampoCompacto
                    label="Comprimento Cumeeira"
                    placeholder="10.00"
                    value={editandoItem.comprimentoCumeeira}
                    onChange={(e) => setEditandoItem(prev => ({ ...prev, comprimentoCumeeira: e.target.value }))}
                    unit="m"
                  />
                  <CampoCompacto
                    label="Comprimento Rincão"
                    placeholder="5.00"
                    value={editandoItem.comprimentoRincao}
                    onChange={(e) => setEditandoItem(prev => ({ ...prev, comprimentoRincao: e.target.value }))}
                    unit="m"
                  />
                  <CampoCompacto
                    label="Comprimento Beiral"
                    placeholder="20.00"
                    value={editandoItem.comprimentoBeiral}
                    onChange={(e) => setEditandoItem(prev => ({ ...prev, comprimentoBeiral: e.target.value }))}
                    unit="m"
                  />
                  <CampoCompacto
                    label="Comprimento Rufo"
                    placeholder="15.00"
                    value={editandoItem.comprimentoRufo}
                    onChange={(e) => setEditandoItem(prev => ({ ...prev, comprimentoRufo: e.target.value }))}
                    unit="m"
                  />
                  <CampoCompacto
                    label="Comprimento Calha"
                    placeholder="10.00"
                    value={editandoItem.comprimentoCalha}
                    onChange={(e) => setEditandoItem(prev => ({ ...prev, comprimentoCalha: e.target.value }))}
                    unit="m"
                  />
                </div>
              </>
            )}

            {(tipoEditando === 'sapata' || tipoEditando === 'viga' || tipoEditando === 'pilar') && (
              <CampoCompacto
                label="Quantidade"
                placeholder="1"
                value={editandoItem.quantidade}
                onChange={(e) => setEditandoItem(prev => ({ ...prev, quantidade: e.target.value }))}
                unit="un"
              />
            )}

            <div className="flex gap-2">
              <Button 
                onClick={() => {
                  if (tipoEditando === 'sapata') salvarSapata(editandoItem)
                  if (tipoEditando === 'viga') salvarViga(editandoItem)
                  if (tipoEditando === 'pilar') salvarPilar(editandoItem)
                  if (tipoEditando === 'parede') salvarParede(editandoItem)
                  if (tipoEditando === 'cobertura') salvarCobertura(editandoItem)
                }}
                className="flex-1 h-8"
                size="sm"
              >
                Salvar
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setEditandoItem(null)
                  setTipoEditando(null)
                }}
                className="flex-1 h-8"
                size="sm"
              >
                Cancelar
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  const renderFormularioCobertura = () => (
    <div className="space-y-3">
      {renderFormularioEdicao()}

      <SecaoColapsavel
        titulo="Coberturas"
        icone={Home}
        isOpen={secaoAberta.coberturas}
        onToggle={() => toggleSecao("coberturas")}
        badge={coberturas.length > 0 ? `${coberturas.length}` : null}
      >
        <div className="space-y-2">
          {coberturas.map(cobertura => (
            <ItemLista
              key={cobertura.id}
              item={cobertura}
              tipo="cobertura"
              onEdit={(item) => {
                setEditandoItem(item)
                setTipoEditando("cobertura")
              }}
              onDelete={excluirCobertura}
            />
          ))}
          <Button 
            variant="outline" 
            onClick={adicionarCobertura}
            className="w-full h-8"
            size="sm"
          >
            <Plus className="h-3 w-3 mr-1" />
            Adicionar Cobertura
          </Button>
        </div>
      </SecaoColapsavel>

      <SecaoColapsavel
        titulo="Configurações"
        icone={Wrench}
        isOpen={secaoAberta.configuracaoCobertura}
        onToggle={() => toggleSecao("configuracaoCobertura")}
      >
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Tipo de Telha</Label>
            <Select 
              value={configuracaoCobertura.tipoTelha} 
              onValueChange={(value) => {
                const selectedTelha = tiposTelha.find(t => t.id === value);
                setConfiguracaoCobertura(prev => ({
                  ...prev,
                  tipoTelha: value,
                  precoTelha: selectedTelha ? selectedTelha.preco : prev.precoTelha
                }));
              }}
            >
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {tiposTelha.map(telha => (
                  <SelectItem key={telha.id} value={telha.id}>{telha.nome}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Tipo de Madeiramento</Label>
            <Select 
              value={configuracaoCobertura.tipoMadeiramento} 
              onValueChange={(value) => {
                const selectedMadeiramento = tiposMadeiramento.find(m => m.id === value);
                setConfiguracaoCobertura(prev => ({
                  ...prev,
                  tipoMadeiramento: value,
                  precoMadeira: selectedMadeiramento ? selectedMadeiramento.preco : prev.precoMadeira
                }));
              }}
            >
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {tiposMadeiramento.map(madeira => (
                  <SelectItem key={madeira.id} value={madeira.id}>{madeira.nome}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Tipo de Calha</Label>
            <Select 
              value={configuracaoCobertura.tipoCalha} 
              onValueChange={(value) => {
                const selectedCalha = tiposCalha.find(c => c.id === value);
                setConfiguracaoCobertura(prev => ({
                  ...prev,
                  tipoCalha: value,
                  precoCalha: selectedCalha ? selectedCalha.preco : prev.precoCalha
                }));
              }}
            >
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {tiposCalha.map(calha => (
                  <SelectItem key={calha.id} value={calha.id}>{calha.nome}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Tipo de Rufo</Label>
            <Select 
              value={configuracaoCobertura.tipoRufo} 
              onValueChange={(value) => {
                const selectedRufo = tiposRufo.find(r => r.id === value);
                setConfiguracaoCobertura(prev => ({
                  ...prev,
                  tipoRufo: value,
                  precoRufo: selectedRufo ? selectedRufo.preco : prev.precoRufo
                }));
              }}
            >
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {tiposRufo.map(rufo => (
                  <SelectItem key={rufo.id} value={rufo.id}>{rufo.nome}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Inclinação do Telhado</Label>
            <Select 
              value={configuracaoCobertura.inclinacaoTelhado} 
              onValueChange={(value) => atualizarConfiguracaoCobertura("inclinacaoTelhado", value)}
            >
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {inclinacoesTelhado.map(inclinacao => (
                  <SelectItem key={inclinacao.id} value={inclinacao.id}>{inclinacao.nome}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <CampoCompacto
              label="Preço Telha"
              placeholder="1.50"
              value={configuracaoCobertura.precoTelha}
              onChange={(e) => atualizarConfiguracaoCobertura("precoTelha", e.target.value)}
              unit="R$/un"
            />
            <CampoCompacto
              label="Preço Madeira"
              placeholder="15.00"
              value={configuracaoCobertura.precoMadeira}
              onChange={(e) => atualizarConfiguracaoCobertura("precoMadeira", e.target.value)}
              unit="R$/m"
            />
            <CampoCompacto
              label="Preço Calha"
              placeholder="20.00"
              value={configuracaoCobertura.precoCalha}
              onChange={(e) => atualizarConfiguracaoCobertura("precoCalha", e.target.value)}
              unit="R$/m"
            />
            <CampoCompacto
              label="Preço Rufo"
              placeholder="25.00"
              value={configuracaoCobertura.precoRufo}
              onChange={(e) => atualizarConfiguracaoCobertura("precoRufo", e.target.value)}
              unit="R$/m"
            />
            <CampoCompacto
              label="Diária Pedreiro Telhado"
              placeholder="200"
              value={configuracaoCobertura.precoPedreiroTelhado}
              onChange={(e) => atualizarConfiguracaoCobertura("precoPedreiroTelhado", e.target.value)}
              unit="R$/dia"
            />
            <CampoCompacto
              label="Diária Ajudante Telhado"
              placeholder="120"
              value={configuracaoCobertura.precoAjudanteTelhado}
              onChange={(e) => atualizarConfiguracaoCobertura("precoAjudanteTelhado", e.target.value)}
              unit="R$/dia"
            />
            <CampoCompacto
              label="Produtividade Telhado"
              placeholder="15"
              value={configuracaoCobertura.produtividadeTelhado}
              onChange={(e) => atualizarConfiguracaoCobertura("produtividadeTelhado", e.target.value)}
              unit="m²/dia"
            />
          </div>
        </div>
      </SecaoColapsavel>

      <Button 
        onClick={calcularCoberturaCompleta} 
        className="w-full h-10"
        disabled={coberturas.length === 0}
      >
        <Calculator className="h-4 w-4 mr-2" />
        Calcular Cobertura Completa
      </Button>

      {resultados.areaTotalCobertura && (
        <div className="space-y-3">
          <h4 className="text-sm font-semibold">Resumo da Cobertura:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Área Total" valor={resultados.areaTotalCobertura} unidade="m²" destaque />
            <ResultadoCompacto titulo="Área Real Telhado" valor={resultados.areaRealTelhado} unidade="m²" />
            <ResultadoCompacto titulo={resultados.tipoTelhaNome} valor={resultados.quantidadeTelhas} unidade="un" />
          </div>

          <h4 className="text-sm font-semibold">Madeiramento:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Ripas" valor={resultados.quantidadeRipas} unidade="m" />
            <ResultadoCompacto titulo="Caibros" valor={resultados.quantidadeCaibros} unidade="m" />
            <ResultadoCompacto titulo="Tesouras" valor={resultados.quantidadeTesouras} unidade="un" />
          </div>

          <h4 className="text-sm font-semibold">Calhas e Rufos:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo={resultados.tipoCalhaNome} valor={resultados.quantidadeCalhas} unidade="m" />
            <ResultadoCompacto titulo={resultados.tipoRufoNome} valor={resultados.quantidadeRufos} unidade="m" />
            <ResultadoCompacto titulo="Cumeeiras" valor={resultados.quantidadeCumeeiras} unidade="m" />
            <ResultadoCompacto titulo="Rincões" valor={resultados.quantidadeRincoes} unidade="m" />
            <ResultadoCompacto titulo="Beirais" valor={resultados.quantidadeBeirais} unidade="m" />
          </div>

          <h4 className="text-sm font-semibold">Custos Detalhados:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Telhas" valor={`R$ ${resultados.custoTelhas}`} unidade="" />
            <ResultadoCompacto titulo="Madeiramento" valor={`R$ ${resultados.custoMadeiramento}`} unidade="" />
            <ResultadoCompacto titulo="Calhas" valor={`R$ ${resultados.custoCalhas}`} unidade="" />
            <ResultadoCompacto titulo="Rufos" valor={`R$ ${resultados.custoRufos}`} unidade="" />
            <ResultadoCompacto titulo="Cumeeiras" valor={`R$ ${resultados.custoCumeeiras}`} unidade="" />
            <ResultadoCompacto titulo="Rincões" valor={`R$ ${resultados.custoRincoes}`} unidade="" />
            <ResultadoCompacto titulo="Beirais" valor={`R$ ${resultados.custoBeirais}`} unidade="" />
            <ResultadoCompacto titulo="Materiais" valor={`R$ ${resultados.custoMateriais}`} unidade="" destaque />
          </div>

          <h4 className="text-sm font-semibold">Mão de Obra:</h4>
          <div className="grid grid-cols-1 gap-2">
            <ResultadoCompacto 
              titulo={`Mão de Obra: R$ ${resultados.custoMaoObra}`} 
              valor="" 
              unidade="" 
              destaque 
            />
          </div>

          <h4 className="text-sm font-semibold">Resumo Final:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Custo Total" valor={`R$ ${resultados.custoTotal}`} unidade="" destaque />
            <ResultadoCompacto titulo="Prazo Estimado" valor={resultados.prazoEstimado} unidade="dias" destaque />
          </div>
        </div>
      )}
    </div>
  )

  const renderFormularioFundacao = () => (
    <div className="space-y-3">
      {renderFormularioEdicao()}

      <SecaoColapsavel
        titulo="Sapatas"
        icone={Building2}
        isOpen={secaoAberta.sapatas}
        onToggle={() => toggleSecao('sapatas')}
        badge={sapatas.length > 0 ? `${sapatas.length}` : null}
      >
        <div className="space-y-2">
          {sapatas.map(sapata => (
            <ItemLista
              key={sapata.id}
              item={sapata}
              tipo="sapata"
              onEdit={(item) => {
                setEditandoItem(item)
                setTipoEditando('sapata')
              }}
              onDelete={excluirSapata}
            />
          ))}
          <Button 
            variant="outline" 
            onClick={adicionarSapata}
            className="w-full h-8"
            size="sm"
          >
            <Plus className="h-3 w-3 mr-1" />
            Adicionar Sapata
          </Button>
        </div>
      </SecaoColapsavel>

      <SecaoColapsavel
        titulo="Vigas Baldrame"
        icone={Package}
        isOpen={secaoAberta.vigas}
        onToggle={() => toggleSecao('vigas')}
        badge={vigas.length > 0 ? `${vigas.length}` : null}
      >
        <div className="space-y-2">
          {vigas.map(viga => (
            <ItemLista
              key={viga.id}
              item={viga}
              tipo="viga"
              onEdit={(item) => {
                setEditandoItem(item)
                setTipoEditando('viga')
              }}
              onDelete={excluirViga}
            />
          ))}
          <Button 
            variant="outline" 
            onClick={adicionarViga}
            className="w-full h-8"
            size="sm"
          >
            <Plus className="h-3 w-3 mr-1" />
            Adicionar Viga
          </Button>
        </div>
      </SecaoColapsavel>

      <SecaoColapsavel
        titulo="Pilares"
        icone={Hammer}
        isOpen={secaoAberta.pilares}
        onToggle={() => toggleSecao('pilares')}
        badge={pilares.length > 0 ? `${pilares.length}` : null}
      >
        <div className="space-y-2">
          {pilares.map(pilar => (
            <ItemLista
              key={pilar.id}
              item={pilar}
              tipo="pilar"
              onEdit={(item) => {
                setEditandoItem(item)
                setTipoEditando('pilar')
              }}
              onDelete={excluirPilar}
            />
          ))}
          <Button 
            variant="outline" 
            onClick={adicionarPilar}
            className="w-full h-8"
            size="sm"
          >
            <Plus className="h-3 w-3 mr-1" />
            Adicionar Pilar
          </Button>
        </div>
      </SecaoColapsavel>

      <SecaoColapsavel
        titulo="Configurações"
        icone={Wrench}
        isOpen={secaoAberta.configuracoes}
        onToggle={() => toggleSecao('configuracoes')}
      >
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Resistência do Concreto</Label>
            <Select 
              value={configuracoes.resistenciaConcreto} 
              onValueChange={(value) => atualizarConfiguracao("resistenciaConcreto", value)}
            >
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {resistenciasConcreto.map(res => (
                  <SelectItem key={res.id} value={res.id}>{res.nome} (fck {res.fck} MPa)</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {configuracoes.resistenciaConcreto && (
              <p className="text-xs text-gray-500 mt-1">
                Traço para 1m³: Cimento: {resistenciasConcreto.find(r => r.id === configuracoes.resistenciaConcreto)?.traco.cimento}kg | Areia: {resistenciasConcreto.find(r => r.id === configuracoes.resistenciaConcreto)?.traco.areia}m³ | Brita: {resistenciasConcreto.find(r => r.id === configuracoes.resistenciaConcreto)?.traco.brita}m³ ({resistenciasConcreto.find(r => r.id === configuracoes.resistenciaConcreto)?.tracoVolume})
              </p>
            )}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <CampoCompacto
              label="Taxa de Aço"
              placeholder="80"
              value={configuracoes.taxaAco}
              onChange={(e) => atualizarConfiguracao('taxaAco', e.target.value)}
              unit="kg/m³"
            />
            <CampoCompacto
              label="Preço Concreto"
              placeholder="400"
              value={configuracoes.precoConcreto}
              onChange={(e) => atualizarConfiguracao("precoConcreto", e.target.value)}
              unit="R$/m³"
            />
            <CampoCompacto
              label="Preço Cimento"
              placeholder="0.5"
              value={configuracoes.precoCimento}
              onChange={(e) => atualizarConfiguracao("precoCimento", e.target.value)}
              unit="R$/kg"
            />
            <CampoCompacto
              label="Preço Areia"
              placeholder="30"
              value={configuracoes.precoAreia}
              onChange={(e) => atualizarConfiguracao("precoAreia", e.target.value)}
              unit="R$/m³"
            />
            <CampoCompacto
              label="Preço Brita"
              placeholder="40"
              value={configuracoes.precoBrita}
              onChange={(e) => atualizarConfiguracao("precoBrita", e.target.value)}
              unit="R$/m³"
            />
            <CampoCompacto
              label="Preço Aço"
              placeholder="7"
              value={configuracoes.precoAco}
              onChange={(e) => atualizarConfiguracao('precoAco', e.target.value)}
              unit="R$/kg"
            />
            <CampoCompacto
              label="Diária Pedreiro"
              placeholder="180"
              value={configuracoes.precoPedreiro}
              onChange={(e) => atualizarConfiguracao("precoPedreiro", e.target.value)}
              unit="R$/dia"
            />
            <CampoCompacto
              label="Diária Ajudante"
              placeholder="100"
              value={configuracoes.precoAjudante}
              onChange={(e) => atualizarConfiguracao("precoAjudante", e.target.value)}
              unit="R$/dia"
            />
            <CampoCompacto
              label="Diária Armador"
              placeholder="200"
              value={configuracoes.precoArmador}
              onChange={(e) => atualizarConfiguracao("precoArmador", e.target.value)}
              unit="R$/dia"
            />
            <CampoCompacto
              label="Diária Carpinteiro"
              placeholder="220"
              value={configuracoes.precoCarpinteiro}
              onChange={(e) => atualizarConfiguracao("precoCarpinteiro", e.target.value)}
              unit="R$/dia"
            />
          </div>
        </div>
      </SecaoColapsavel>

      <Button 
        onClick={calcularFundacaoCompleta} 
        className="w-full h-10"
        disabled={sapatas.length === 0 && vigas.length === 0 && pilares.length === 0}
      >
        <Calculator className="h-4 w-4 mr-2" />
        Calcular Fundação Completa
      </Button>

      {resultados.volumeTotal && (
        <div className="space-y-3">
          <h4 className="text-sm font-semibold">Resumo dos Volumes:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Volume Total" valor={resultados.volumeTotal} unidade="m³" destaque />
            <ResultadoCompacto titulo="Sapatas" valor={resultados.volumeSapatas} unidade="m³" />
            <ResultadoCompacto titulo="Vigas" valor={resultados.volumeVigas} unidade="m³" />
            <ResultadoCompacto titulo="Pilares" valor={resultados.volumePilares} unidade="m³" />
          </div>

          <h4 className="text-sm font-semibold">Materiais:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Concreto" valor={resultados.concreto} unidade="m³" destaque />
            <ResultadoCompacto titulo="Cimento" valor={resultados.cimento} unidade="sacos" />
            <ResultadoCompacto titulo="Areia" valor={resultados.areia} unidade="m³" />
            <ResultadoCompacto titulo="Brita" valor={resultados.brita} unidade="m³" />
            <ResultadoCompacto titulo="Aço" valor={resultados.aco} unidade="kg" />
            <ResultadoCompacto titulo="Arame" valor={resultados.arame} unidade="kg" />
            <ResultadoCompacto titulo="Forma" valor={resultados.areaForma} unidade="m²" />
          </div>

          <h4 className="text-sm font-semibold">Custos Detalhados:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Concreto" valor={`R$ ${resultados.custoConcreto}`} unidade="" />
            <ResultadoCompacto titulo="Aço" valor={`R$ ${resultados.custoAco}`} unidade="" />
            <ResultadoCompacto titulo="Formas" valor={`R$ ${resultados.custoForma}`} unidade="" />
            <ResultadoCompacto titulo="Materiais" valor={`R$ ${resultados.custoMateriais}`} unidade="" destaque />
          </div>

          <h4 className="text-sm font-semibold">Mão de Obra:</h4>
          <div className="grid grid-cols-1 gap-2">
            <ResultadoCompacto 
              titulo={`Mão de Obra: R$ ${resultados.custoMaoObra} (Esc: R$${resultados.custoEscavacao}, Conc: R$${resultados.custoConcretagem}, Arm: R$${resultados.custoArmacao}, Carp: R$${resultados.custoFormas})`} 
              valor="" 
              unidade="" 
              destaque 
            />
          </div>

          <h4 className="text-sm font-semibold">Tempo de Execução:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Escavação" valor={`${resultados.diasEscavacao} dias`} unidade="" />
            <ResultadoCompacto titulo="Concretagem" valor={`${resultados.diasConcretagem} dias`} unidade="" />
            <ResultadoCompacto titulo="Armação" valor={`${resultados.diasArmacao} dias`} unidade="" />
            <ResultadoCompacto titulo="Carpintaria" valor={`${resultados.diasFormas} dias`} unidade="" />
          </div>

          <h4 className="text-sm font-semibold">Resumo Final:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Custo Total" valor={`R$ ${resultados.custoTotal}`} unidade="" destaque />
            <ResultadoCompacto titulo="Prazo Estimado" valor={resultados.prazoEstimado} unidade="dias" destaque />
          </div>
        </div>
      )}
    </div>
  )

  const renderFormularioAlvenaria = () => (
    <div className="space-y-3">
      {renderFormularioEdicao()}

      <SecaoColapsavel
        titulo="Paredes"
        icone={Building2}
        isOpen={secaoAberta.paredes}
        onToggle={() => toggleSecao('paredes')}
        badge={paredes.length > 0 ? `${paredes.length}` : null}
      >
        <div className="space-y-2">
          {paredes.map(parede => (
            <div key={parede.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
              <div className="flex-1">
                <div className="text-sm font-medium">
                  {parede.nome || 'Parede'} - {parede.comprimento}x{parede.altura}m
                </div>
                <div className="text-xs text-gray-500">
                  Área: {parede.areaLiquida?.toFixed(2)}m² (bruta: {parede.area?.toFixed(2)}m²)
                </div>
              </div>
              <div className="flex gap-1">
                <Button variant="ghost" size="sm" onClick={() => {
                  setEditandoItem(parede)
                  setTipoEditando('parede')
                }}>
                  <Edit className="h-3 w-3" />
                </Button>
                <Button variant="ghost" size="sm" onClick={() => excluirParede(parede.id)}>
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            </div>
          ))}
          <Button 
            variant="outline" 
            onClick={adicionarParede}
            className="w-full h-8"
            size="sm"
          >
            <Plus className="h-3 w-3 mr-1" />
            Adicionar Parede
          </Button>
        </div>
      </SecaoColapsavel>

      <SecaoColapsavel
        titulo="Configurações"
        icone={Wrench}
        isOpen={secaoAberta.configuracaoAlvenaria}
        onToggle={() => toggleSecao('configuracaoAlvenaria')}
      >
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Tipo de Bloco/Tijolo</Label>
            <Select 
              value={configuracaoAlvenaria.tipoBloco} 
              onValueChange={(value) => atualizarConfiguracaoAlvenaria("tipoBloco", value)}
            >
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {tiposBlocos.map(bloco => (
                  <SelectItem key={bloco.id} value={bloco.id}>
                    {bloco.nome} ({bloco.dimensoes})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {configuracaoAlvenaria.tipoBloco && (
              <p className="text-xs text-gray-500 mt-1">
                Consumo: {tiposBlocos.find(b => b.id === configuracaoAlvenaria.tipoBloco)?.consumo} un/m² | 
                Argamassa: {tiposBlocos.find(b => b.id === configuracaoAlvenaria.tipoBloco)?.argamassa} m³/m²
              </p>
            )}
          </div>
          
          <div>
            <Label className="text-xs">Tipo de Revestimento</Label>
            <Select 
              value={configuracaoAlvenaria.tipoRevestimento} 
              onValueChange={(value) => atualizarConfiguracaoAlvenaria("tipoRevestimento", value)}
            >
              <SelectTrigger className="h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="nenhum">Nenhum</SelectItem>
                <SelectItem value="reboco">Reboco (1:3)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {configuracaoAlvenaria.tipoRevestimento === 'reboco' && (
            <div>
              <Label className="text-xs">Lados com Reboco</Label>
              <Select 
                value={configuracaoAlvenaria.ladosReboco.toString()} 
                onValueChange={(value) => atualizarConfiguracaoAlvenaria("ladosReboco", parseInt(value))}
              >
                <SelectTrigger className="h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Um Lado</SelectItem>
                  <SelectItem value="2">Dois Lados</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2">
            <CampoCompacto
              label="Preço Bloco"
              placeholder="0.50"
              value={configuracaoAlvenaria.precoBloco}
              onChange={(e) => atualizarConfiguracaoAlvenaria("precoBloco", e.target.value)}
              unit="R$/un"
            />
            <CampoCompacto
              label="Diária Pedreiro"
              placeholder="180"
              value={configuracaoAlvenaria.precoPedreiro}
              onChange={(e) => atualizarConfiguracaoAlvenaria("precoPedreiro", e.target.value)}
              unit="R$/dia"
            />
            <CampoCompacto
              label="Diária Ajudante"
              placeholder="100"
              value={configuracaoAlvenaria.precoAjudante}
              onChange={(e) => atualizarConfiguracaoAlvenaria("precoAjudante", e.target.value)}
              unit="R$/dia"
            />
            <CampoCompacto
              label="Preço Água"
              placeholder="10"
              value={configuracaoAlvenaria.precoAgua}
              onChange={(e) => atualizarConfiguracaoAlvenaria("precoAgua", e.target.value)}
              unit="R$/m³"
            />
            <CampoCompacto
              label="Produtividade"
              placeholder="10"
              value={configuracaoAlvenaria.produtividade}
              onChange={(e) => atualizarConfiguracaoAlvenaria("produtividade", e.target.value)}
              unit="m²/dia"
            />
          </div>
        </div>
      </SecaoColapsavel>

      <Button 
        onClick={calcularAlvenariaCompleta} 
        className="w-full h-10"
        disabled={paredes.length === 0}
      >
        <Calculator className="h-4 w-4 mr-2" />
        Calcular Alvenaria Completa
      </Button>

      {resultados.areaTotal && (
        <div className="space-y-3">
          <h4 className="text-sm font-semibold">Resumo da Alvenaria:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Área Total" valor={resultados.areaTotal} unidade="m²" destaque />
            <ResultadoCompacto titulo={resultados.tipoBlocoNome} valor={resultados.quantidadeBlocos} unidade="un" />
          </div>

          <h4 className="text-sm font-semibold">Argamassa ({resultados.tipoTracoNome}):</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Volume" valor={resultados.volumeArgamassa} unidade="m³" destaque />
            <ResultadoCompacto titulo="Cimento" valor={resultados.cimentoArgamassa} unidade="sacos" />
            <ResultadoCompacto titulo="Areia" valor={resultados.areiaArgamassa} unidade="m³" />
            <ResultadoCompacto titulo="Água" valor={resultados.aguaArgamassa} unidade="m³" />
          </div>

          <h4 className="text-sm font-semibold">Custos Detalhados:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Blocos" valor={`R$ ${resultados.custoBlocos}`} unidade="" />
            <ResultadoCompacto titulo="Cimento" valor={`R$ ${resultados.custoCimento}`} unidade="" />
            <ResultadoCompacto titulo="Areia" valor={`R$ ${resultados.custoAreia}`} unidade="" />
            <ResultadoCompacto titulo="Água" valor={`R$ ${resultados.custoAgua}`} unidade="" />
            <ResultadoCompacto titulo="Materiais" valor={`R$ ${resultados.custoMateriais}`} unidade="" destaque />
          </div>

          <h4 className="text-sm font-semibold">Mão de Obra:</h4>
          <div className="grid grid-cols-1 gap-2">
            <ResultadoCompacto 
              titulo={`Mão de Obra: R$ ${resultados.custoMaoObra} (Pedr: R$${resultados.custoPedreiro}, Ajud: R$${resultados.custoAjudante})`} 
              valor="" 
              unidade="" 
              destaque 
            />
          </div>

          <h4 className="text-sm font-semibold">Tempo de Execução:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Pedreiro" valor={`${resultados.diasPedreiro} dias`} unidade="" />
            <ResultadoCompacto titulo="Ajudante" valor={`${resultados.diasAjudante} dias`} unidade="" />
          </div>

          <h4 className="text-sm font-semibold">Resumo Final:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Custo Total" valor={`R$ ${resultados.custoTotal}`} unidade="" destaque />
            <ResultadoCompacto titulo="Prazo Estimado" valor={resultados.prazoEstimado} unidade="dias" destaque />
          </div>
        </div>
      )}
    </div>
  )

  const renderFormulario = () => {
    switch (secaoSelecionada) {
      case 'alvenaria':
        return renderFormularioAlvenaria()
      case 'fundacao':
        return renderFormularioFundacao()
      case 'cobertura':
        return renderFormularioCobertura()
      default:
        return (
          <div className="text-center py-8">
            <Calculator className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-500">Selecione uma etapa para calcular os materiais necessários.</p>
          </div>
        )
    }
  }

  if (secaoSelecionada) {
    const secao = secoes.find(s => s.id === secaoSelecionada)
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => setSecaoSelecionada(null)}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-2">
            <secao.icone className="h-5 w-5 text-orange-600" />
            <h2 className="text-lg font-semibold">{secao.nome}</h2>
          </div>
        </div>
        
        {renderFormulario()}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex items-center gap-2">
          <Calculator className="h-5 w-5 text-orange-600" />
          <h2 className="text-lg font-semibold">Cálculo de Materiais</h2>
        </div>
      </div>

      <p className="text-sm text-gray-600">
        Escolha uma etapa da obra para calcular os materiais necessários.
      </p>

      <div className="grid gap-3">
        {secoes.map((secao) => {
          const Icone = secao.icone
          return (
            <Card 
              key={secao.id} 
              className="cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => setSecaoSelecionada(secao.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-orange-100 rounded-lg">
                    <Icone className="h-5 w-5 text-orange-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-sm">{secao.nome}</h3>
                    <p className="text-xs text-gray-500">{secao.descricao}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}





// Tipos de telhas
const tiposTelha = [
  { id: 'ceramica', nome: 'Telha Cerâmica', consumo: 16, perdas: 0.10, preco: 1.50, consumoMadeira: { ripa: 3, caibro: 1.5, tesoura: 0.05 } }, // un/m²
  { id: 'fibrocimento', nome: 'Telha Fibrocimento', consumo: 0.1, perdas: 0.05, preco: 30.00, comprimentoTelha: 2.44, larguraTelha: 1.10, consumoMadeira: { ripa: 0, caibro: 0, tesoura: 0.03 } }, // un/m² (chapa) - menor consumo de madeira
  { id: 'metalica', nome: 'Telha Metálica', consumo: 0.1, perdas: 0.03, preco: 45.00, consumoMadeira: { ripa: 0, caibro: 0, tesoura: 0.04 } }, // un/m² (chapa) - menor consumo de madeira
  { id: 'concreto', nome: 'Telha de Concreto', consumo: 10, perdas: 0.08, preco: 2.50, consumoMadeira: { ripa: 2.5, caibro: 1.2, tesoura: 0.04 } }
]

// Tipos de madeiramento
const tiposMadeiramento = [
  { id: 'ripa', nome: 'Ripa', consumo: 3, perdas: 0.10, preco: 5.00 }, // m/m²
  { id: 'caibro', nome: 'Caibro', consumo: 1.5, perdas: 0.10, preco: 15.00 }, // m/m²
  { id: 'tesoura', nome: 'Tesoura', consumo: 0.05, perdas: 0.15, preco: 200.00 } // un/m²
]

// Tipos de calhas
const tiposCalha = [
  { id: 'pvc', nome: 'Calha PVC', preco: 20.00 }, // R$/m
  { id: 'galvanizada', nome: 'Calha Galvanizada', preco: 35.00 }
]

// Tipos de rufos
const tiposRufo = [
  { id: 'chapa', nome: 'Rufo de Chapa', preco: 25.00 }, // R$/m
  { id: 'alvenaria', nome: 'Rufo de Alvenaria', preco: 40.00 }
]

// Inclinação do telhado
const inclinacoesTelhado = [
  { id: '10', nome: '10%', fator: 1.005 },
  { id: '20', nome: '20%', fator: 1.020 },
  { id: '30', nome: '30%', fator: 1.044 },
  { id: '35', nome: '35%', fator: 1.064 }
]



import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { ArrowLeft, Calculator, Building2, Package, Droplets, Hammer, Zap, MapPin, Paintbrush, Home, CheckCircle, FileText, ChevronDown, ChevronUp } from 'lucide-react'

// Dados das etapas baseados na pesquisa e na planilha fornecida
const etapasBase = [
  {
    id: 'movimentacao_terra_limpeza_terreno',
    nome: 'Movimentação de Terra e Limpeza do Terreno',
    categoria: 'Preparação',
    icone: Building2,
    descricao: 'Cálculo de volume de terra, bota-fora, etc.'
  },
  {
    id: 'fundacao',
    nome: 'Fundações',
    categoria: 'Estrutura',
    icone: Hammer,
    descricao: 'Cálculo de concreto, aço, formas, etc.'
  },
  {
    id: 'impermeabilizacao',
    nome: 'Impermeabilização',
    categoria: 'Estrutura',
    icone: Droplets,
    descricao: 'Cálculo de manta asfáltica, argamassa polimérica, etc.'
  },
  {
    id: 'aterro',
    nome: 'Aterro',
    categoria: 'Preparação',
    icone: Building2,
    descricao: 'Cálculo de volume de material para aterro'
  },
  {
    id: 'alvenaria',
    nome: 'Alvenaria',
    categoria: 'Vedação',
    icone: Building2,
    descricao: 'Cálculo de tijolos/blocos, argamassa, cimento, areia, etc.'
  },
  {
    id: 'lajes',
    nome: 'Lajes',
    categoria: 'Estrutura',
    icone: Home,
    descricao: 'Cálculo de concreto, aço, escoramento, etc.'
  },
  {
    id: 'telhado',
    nome: 'Telhado',
    categoria: 'Cobertura',
    icone: Home,
    descricao: 'Cálculo de telhas, madeiramento, calhas, etc.'
  },
  {
    id: 'reboco_interno',
    nome: 'Reboco Interno',
    categoria: 'Acabamento',
    icone: Paintbrush,
    descricao: 'Cálculo de argamassa, cimento, areia, cal, etc.'
  },
  {
    id: 'reboco_externo',
    nome: 'Reboco Externo',
    categoria: 'Acabamento',
    icone: Paintbrush,
    descricao: 'Cálculo de argamassa, cimento, areia, cal, etc.'
  },
  {
    id: 'revestimento_interno',
    nome: 'Revestimento Interno',
    categoria: 'Acabamento',
    icone: Paintbrush,
    descricao: 'Cálculo de pisos, argamassa colante, rejunte, etc.'
  },
  {
    id: 'revestimento_externo',
    nome: 'Revestimento Externo',
    categoria: 'Acabamento',
    icone: Paintbrush,
    descricao: 'Cálculo de revestimentos, argamassa colante, rejunte, etc.'
  },
  {
    id: 'forro_gesso',
    nome: 'Forro de Gesso',
    categoria: 'Acabamento',
    icone: Home,
    descricao: 'Cálculo de placas de gesso, estrutura, massa, etc.'
  },
  {
    id: 'pintura_interna_externa',
    nome: 'Pintura',
    categoria: 'Acabamento',
    icone: Paintbrush,
    descricao: 'Cálculo de tinta, massa corrida, selador, etc.'
  },
  {
    id: 'esquadrias',
    nome: 'Esquadrias',
    categoria: 'Acabamento',
    icone: Home,
    descricao: 'Cálculo de portas, janelas, batentes, guarnições, etc.'
  },
  {
    id: 'pisos',
    nome: 'Pisos',
    categoria: 'Acabamento',
    icone: Home,
    descricao: 'Cálculo de pisos, argamassa colante, rejunte, etc.'
  },
  {
    id: 'hidraulica',
    nome: 'Instalações Hidráulicas',
    categoria: 'Instalações',
    icone: Droplets,
    descricao: 'Cálculo de tubos, conexões, caixas d'água, etc.'
  },
  {
    id: 'eletrica',
    nome: 'Instalações Elétricas',
    categoria: 'Instalações',
    icone: Zap,
    descricao: 'Cálculo de fios, cabos, disjuntores, tomadas, interruptores, etc.'
  },
  {
    id: 'loucas_metais',
    nome: 'Louças e Metais',
    categoria: 'Acabamento',
    icone: Home,
    descricao: 'Cálculo de vasos sanitários, pias, torneiras, chuveiros, etc.'
  },
  {
    id: 'cobertura',
    nome: 'Cobertura',
    categoria: 'Cobertura',
    icone: Home,
    descricao: 'Cálculo de telhas, madeiramento, calhas, rufos, etc.'
  },
  {
    id: 'contrapiso',
    nome: 'Contrapiso',
    categoria: 'Estrutura',
    icone: Hammer,
    descricao: 'Cálculo de cimento, areia, brita, etc.'
  },
  {
    id: 'chapisco',
    nome: 'Chapisco',
    categoria: 'Acabamento',
    icone: Paintbrush,
    descricao: 'Cálculo de cimento, areia, aditivos, etc.'
  }
];

const CalculoAlvenariaInterno = ({ onBack }) => {
  const [dimensoes, setDimensoes] = useState({
    comprimento: '',
    altura: '',
    espessuraArgamassa: '1'
  })
  
  const [vaos, setVaos] = useState([])
  const [novoVao, setNovoVao] = useState({
    tipo: 'porta',
    largura: '',
    altura: '',
    quantidade: '1'
  })
  
  const [tipoTijolo, setTipoTijolo] = useState('')
  const [tracoArgamassa, setTracoArgamassa] = useState('1:4')
  const [resultados, setResultados] = useState(null)
  
  // Estados para controlar seções colapsáveis
  const [secaoAberta, setSecaoAberta] = useState({
    dimensoes: true,
    tijolo: false,
    vaos: false,
    config: false,
    maoObra: false
  })
  
  // Valores para cálculo de mão de obra
  const [maoDeObra, setMaoDeObra] = useState({
    valorDiariaPedreiro: '150',
    valorDiariaAjudante: '100',
    produtividadePedreiro: '8' // m² por dia
  })

  // Tipos de tijolos/blocos com suas dimensões padrão (em metros)
  const tiposTijolo = [
    {
      id: 'ceramico_6_furos',
      nome: 'Tijolo Cerâmico 6 Furos',
      dimensoes: { comprimento: 0.19, altura: 0.14, largura: 0.09 },
      descricao: '9x14x19 cm',
      consumo: 39.68 // tijolos por m²
    },
    {
      id: 'ceramico_8_furos',
      nome: 'Tijolo Cerâmico 8 Furos',
      dimensoes: { comprimento: 0.19, altura: 0.19, largura: 0.09 },
      descricao: '9x19x19 cm',
      consumo: 29.76 // tijolos por m²
    },
    {
      id: 'bloco_concreto_14',
      nome: 'Bloco de Concreto 14cm',
      dimensoes: { comprimento: 0.39, altura: 0.19, largura: 0.14 },
      descricao: '14x19x39 cm',
      consumo: 12.5 // blocos por m²
    },
    {
      id: 'bloco_concreto_19',
      nome: 'Bloco de Concreto 19cm',
      dimensoes: { comprimento: 0.39, altura: 0.19, largura: 0.19 },
      descricao: '19x19x39 cm',
      consumo: 12.5 // blocos por m²
    },
    {
      id: 'tijolo_comum',
      nome: 'Tijolo Comum',
      dimensoes: { comprimento: 0.20, altura: 0.10, largura: 0.05 },
      descricao: '5x10x20 cm',
      consumo: 50 // tijolos por m²
    }
  ]

  // Traços de argamassa disponíveis
  const tracosArgamassa = [
    {
      id: '1:4',
      nome: '1:4 (Cimento:Areia)',
      descricao: 'Traço comum para assentamento',
      consumoCimento: 7, // sacos de 50kg por m³
      consumoAreia: 1.2, // m³ por m³ de argamassa
      consumoAgua: 220 // litros por m³ de argamassa
    },
    {
      id: '1:2:8',
      nome: '1:2:8 (Cimento:Cal:Areia)',
      descricao: 'Traço com cal hidratada',
      consumoCimento: 5, // sacos de 50kg por m³
      consumoCal: 2, // sacos de 20kg por m³
      consumoAreia: 1.0, // m³ por m³ de argamassa
      consumoAgua: 200 // litros por m³ de argamassa
    },
    {
      id: '1:3',
      nome: '1:3 (Cimento:Areia)',
      descricao: 'Traço mais resistente',
      consumoCimento: 9, // sacos de 50kg por m³
      consumoAreia: 1.1, // m³ por m³ de argamassa
      consumoAgua: 240 // litros por m³ de argamassa
    }
  ]

  const toggleSecao = (secao) => {
    setSecaoAberta(prev => ({
      ...prev,
      [secao]: !prev[secao]
    }))
  }

  const adicionarVao = () => {
    if (novoVao.largura && novoVao.altura && novoVao.quantidade) {
      const vao = {
        ...novoVao,
        id: Date.now(),
        largura: parseFloat(novoVao.largura),
        altura: parseFloat(novoVao.altura),
        quantidade: parseInt(novoVao.quantidade)
      }
      setVaos([...vaos, vao])
      setNovoVao({
        tipo: 'porta',
        largura: '',
        altura: '',
        quantidade: '1'
      })
    }
  }

  const removerVao = (id) => {
    setVaos(vaos.filter(vao => vao.id !== id))
  }

  const calcularMateriais = () => {
    const comp = parseFloat(dimensoes.comprimento) || 0
    const alt = parseFloat(dimensoes.altura) || 0
    const espArg = parseFloat(dimensoes.espessuraArgamassa) / 100 || 0.01 // converter cm para m
    const perdas = 0.1 // 10% fixo

    if (comp <= 0 || alt <= 0 || !tipoTijolo) {
      alert('Por favor, preencha todas as informações necessárias.')
      return
    }

    const areaTotal = comp * alt
    
    // Calcular área dos vãos
    const areaVaos = vaos.reduce((total, vao) => {
      return total + (vao.largura * vao.altura * vao.quantidade)
    }, 0)
    
    const areaLiquida = areaTotal - areaVaos
    
    if (areaLiquida <= 0) {
      alert('A área dos vãos não pode ser maior que a área total da parede.')
      return
    }

    const tijoloSelecionado = tiposTijolo.find(t => t.id === tipoTijolo)
    const tracoSelecionado = tracosArgamassa.find(t => t.id === tracoArgamassa)

    // Cálculo de tijolos/blocos
    const quantidadeTijolosPorM2 = tijoloSelecionado.consumo
    const quantidadeTijolosTotal = Math.ceil(areaLiquida * quantidadeTijolosPorM2 * (1 + perdas))

    // Cálculo de argamassa
    // Volume de argamassa por m² (aproximação baseada na espessura da junta)
    const volumeArgamassaPorM2 = 0.012 // m³/m² (valor médio para blocos de 14cm)
    const volumeArgamassaTotal = areaLiquida * volumeArgamassaPorM2 * (1 + perdas)

    // Componentes da argamassa
    const sacosCimento = Math.ceil(volumeArgamassaTotal * tracoSelecionado.consumoCimento)
    const volumeAreia = (volumeArgamassaTotal * tracoSelecionado.consumoAreia).toFixed(2)
    const volumeAgua = Math.ceil(volumeArgamassaTotal * tracoSelecionado.consumoAgua)
    
    // Cal (se aplicável)
    const sacosCal = tracoSelecionado.consumoCal ? 
      Math.ceil(volumeArgamassaTotal * tracoSelecionado.consumoCal) : 0
      
    // Cálculo de mão de obra
    const produtividadePedreiro = parseFloat(maoDeObra.produtividadePedreiro) || 8 // m²/dia
    const valorDiariaPedreiro = parseFloat(maoDeObra.valorDiariaPedreiro) || 150 // R$
    const valorDiariaAjudante = parseFloat(maoDeObra.valorDiariaAjudante) || 100 // R$
    
    // Tempo necessário (em dias)
    const tempoPedreiro = Math.ceil(areaLiquida / produtividadePedreiro)
    const tempoAjudante = tempoPedreiro // 1 ajudante por pedreiro
    
    // Custo da mão de obra
    const custoPedreiro = tempoPedreiro * valorDiariaPedreiro
    const custoAjudante = tempoAjudante * valorDiariaAjudante
    const custoTotalMaoDeObra = custoPedreiro + custoAjudante
    
    // Custo dos materiais (estimativa simplificada)
    const precoCimento = 30 // R$ por saco de 50kg (estimativa)
    const precoAreia = 120 // R$ por m³ (estimativa)
    const precoCal = sacosCal > 0 ? 15 : 0 // R$ por saco de 20kg (estimativa)
    const precoTijolo = tijoloSelecionado.nome.includes('Bloco') ? 2.5 : 1.2 // R$ por unidade (estimativa)
    
    const custoMateriais = (sacosCimento * precoCimento) + 
                          (parseFloat(volumeAreia) * precoAreia) + 
                          (sacosCal * precoCal) + 
                          (quantidadeTijolosTotal * precoTijolo)
    
    // Custo total (materiais + mão de obra)
    const custoTotal = custoMateriais + custoTotalMaoDeObra

    setResultados({
      areaTotal: areaTotal.toFixed(2),
      areaVaos: areaVaos.toFixed(2),
      areaLiquida: areaLiquida.toFixed(2),
      tijolos: {
        quantidade: quantidadeTijolosTotal,
        tipo: tijoloSelecionado.nome,
        unidade: tijoloSelecionado.nome.includes('Bloco') ? 'blocos' : 'tijolos'
      },
      argamassa: {
        volume: volumeArgamassaTotal.toFixed(3),
        cimento: sacosCimento,
        areia: volumeAreia,
        agua: volumeAgua,
        cal: sacosCal,
        traco: tracoSelecionado.nome
      },
      maoDeObra: {
        tempoPedreiro,
        tempoAjudante,
        custoPedreiro,
        custoAjudante,
        custoTotal: custoTotalMaoDeObra,
        produtividadePedreiro
      },
      custos: {
        materiais: custoMateriais.toFixed(2),
        maoDeObra: custoTotalMaoDeObra.toFixed(2),
        total: custoTotal.toFixed(2)
      },
      vaosDetalhes: vaos
    })
  }

  const tijoloSelecionado = tiposTijolo.find(t => t.id === tipoTijolo)

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-2 sm:p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-4">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onBack}
            className="mr-2"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="bg-orange-500 w-8 h-8 rounded-full flex items-center justify-center mr-2">
            <Building2 className="w-4 h-4 text-white" />
          </div>
          <h1 className="text-lg sm:text-xl font-bold text-gray-800">Alvenaria</h1>
        </div>

        <div className="space-y-3">
          {/* Dimensões da Parede - Sempre visível */}
          <Card>
            <CardHeader 
              className="cursor-pointer py-3"
              onClick={() => toggleSecao('dimensoes')}
            >
              <CardTitle className="flex items-center justify-between text-base">
                <div className="flex items-center gap-2">
                  <Calculator className="w-4 h-4" />
                  Dimensões da Parede
                </div>
                {secaoAberta.dimensoes ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </CardTitle>
            </CardHeader>
            {secaoAberta.dimensoes && (
              <CardContent className="space-y-3 pt-0">
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="comprimento" className="text-sm">Comprimento (m)</Label>
                    <Input
                      id="comprimento"
                      type="number"
                      step="0.01"
                      value={dimensoes.comprimento}
                      onChange={(e) => setDimensoes({...dimensoes, comprimento: e.target.value})}
                      placeholder="Ex: 5.00"
                      className="text-base h-10"
                    />
                  </div>
                  <div>
                    <Label htmlFor="altura" className="text-sm">Altura (m)</Label>
                    <Input
                      id="altura"
                      type="number"
                      step="0.01"
                      value={dimensoes.altura}
                      onChange={(e) => setDimensoes({...dimensoes, altura: e.target.value})}
                      placeholder="Ex: 2.80"
                      className="text-base h-10"
                    />
                  </div>
                </div>
                
                {dimensoes.comprimento && dimensoes.altura && (
                  <div className="p-2 bg-blue-50 rounded-lg">
                    <p className="text-xs text-blue-700">
                      <strong>Área total:</strong> {(parseFloat(dimensoes.comprimento) * parseFloat(dimensoes.altura)).toFixed(2)} m²
                    </p>
                    {vaos.length > 0 && (
                      <>
                        <p className="text-xs text-blue-700 mt-1">
                          <strong>Área dos vãos:</strong> {vaos.reduce((total, vao) => total + (vao.largura * vao.altura * vao.quantidade), 0).toFixed(2)} m²
                        </p>
                        <p className="text-xs text-green-700 mt-1 font-semibold">
                          <strong>Área líquida:</strong> {((parseFloat(dimensoes.comprimento) * parseFloat(dimensoes.altura)) - vaos.reduce((total, vao) => total + (vao.largura * vao.altura * vao.quantidade), 0)).toFixed(2)} m²
                        </p>
                      </>
                    )}
                  </div>
                )}
              </CardContent>
            )}
          </Card>

          {/* Tipo de Tijolo/Bloco */}
          <Card>
            <CardHeader 
              className="cursor-pointer py-3"
              onClick={() => toggleSecao('tijolo')}
            >
              <CardTitle className="flex items-center justify-between text-base">
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4" />
                  Tipo de Material
                </div>
                {secaoAberta.tijolo ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </CardTitle>
            </CardHeader>
            {secaoAberta.tijolo && (
              <CardContent className="space-y-3 pt-0">
                <Select value={tipoTijolo} onValueChange={setTipoTijolo}>
                  <SelectTrigger className="text-sm h-10">
                    <SelectValue placeholder="Selecione o tipo de tijolo/bloco" />
                  </SelectTrigger>
                  <SelectContent>
                    {tiposTijolo.map((tipo) => (
                      <SelectItem key={tipo.id} value={tipo.id}>
                        <div className="flex flex-col">
                          <span className="font-medium text-sm">{tipo.nome}</span>
                          <span className="text-xs text-gray-500">{tipo.descricao}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                {tijoloSelecionado && (
                  <div className="p-2 bg-green-50 rounded-lg">
                    <p className="text-xs text-green-700">
                      <strong>Consumo:</strong> ~{tijoloSelecionado.consumo} {tijoloSelecionado.nome.includes('Bloco') ? 'blocos' : 'tijolos'} por m²
                    </p>
                  </div>
                )}
              </CardContent>
            )}
          </Card>

          {/* Vãos (Portas e Janelas) */}
          <Card>
            <CardHeader 
              className="cursor-pointer py-3"
              onClick={() => toggleSecao('vaos')}
            >
              <CardTitle className="flex items-center justify-between text-base">
                <div className="flex items-center gap-2">
                  <Package className="w-4 h-4" />
                  Vãos {vaos.length > 0 && <Badge variant="secondary" className="ml-2 text-xs">{vaos.length}</Badge>}
                </div>
                {secaoAberta.vaos ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </CardTitle>
            </CardHeader>
            {secaoAberta.vaos && (
              <CardContent className="space-y-3 pt-0">
                {/* Lista de vãos existentes */}
                {vaos.length > 0 && (
                  <div className="space-y-2">
                    {vaos.map((vao) => (
                      <div key={vao.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                        <div>
                          <span className="font-medium text-sm capitalize">{vao.tipo}</span>
                          <span className="text-xs text-gray-600 ml-2">
                            {vao.largura}×{vao.altura}m 
                            {vao.quantidade > 1 && ` (${vao.quantidade}x)`}
                          </span>
                        </div>
                        <Button 
                          variant="destructive" 
                          size="sm" 
                          onClick={() => removerVao(vao.id)}
                          className="h-6 px-2 text-xs"
                        >
                          ×
                        </Button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Formulário para adicionar novo vão */}
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label htmlFor="tipoVao" className="text-sm">Tipo</Label>
                    <Select value={novoVao.tipo} onValueChange={(value) => setNovoVao({...novoVao, tipo: value})}>
                      <SelectTrigger className="h-8 text-sm">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="porta">Porta</SelectItem>
                        <SelectItem value="janela">Janela</SelectItem>
                        <SelectItem value="portao">Portão</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="quantidadeVao" className="text-sm">Qtd</Label>
                    <Input
                      id="quantidadeVao"
                      type="number"
                      min="1"
                      value={novoVao.quantidade}
                      onChange={(e) => setNovoVao({...novoVao, quantidade: e.target.value})}
                      placeholder="1"
                      className="h-8 text-sm"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label htmlFor="larguraVao" className="text-sm">Largura (m)</Label>
                    <Input
                      id="larguraVao"
                      type="number"
                      step="0.01"
                      value={novoVao.largura}
                      onChange={(e) => setNovoVao({...novoVao, largura: e.target.value})}
                      placeholder="0.80"
                      className="h-8 text-sm"
                    />
                  </div>
                  <div>
                    <Label htmlFor="alturaVao" className="text-sm">Altura (m)</Label>
                    <Input
                      id="alturaVao"
                      type="number"
                      step="0.01"
                      value={novoVao.altura}
                      onChange={(e) => setNovoVao({...novoVao, altura: e.target.value})}
                      placeholder="2.10"
                      className="h-8 text-sm"
                    />
                  </div>
                </div>

                <Button onClick={adicionarVao} variant="outline" className="w-full h-8 text-sm">
                  + Adicionar
                </Button>
              </CardContent>
            )}
          </Card>

          {/* Configurações */}
          <Card>
            <CardHeader 
              className="cursor-pointer py-3"
              onClick={() => toggleSecao('config')}
            >
              <CardTitle className="flex items-center justify-between text-base">
                <div className="flex items-center gap-2">
                  <Hammer className="w-4 h-4" />
                  Configurações
                </div>
                {secaoAberta.config ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </CardTitle>
            </CardHeader>
            {secaoAberta.config && (
              <CardContent className="space-y-3 pt-0">
                <div>
                  <Label htmlFor="espessura" className="text-sm">Espessura da Junta</Label>
                  <Select value={dimensoes.espessuraArgamassa} onValueChange={(value) => setDimensoes({...dimensoes, espessuraArgamassa: value})}>
                    <SelectTrigger className="h-8 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1,0 cm</SelectItem>
                      <SelectItem value="1.5">1,5 cm</SelectItem>
                      <SelectItem value="2">2,0 cm</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="traco" className="text-sm">Traço da Argamassa</Label>
                  <Select value={tracoArgamassa} onValueChange={setTracoArgamassa}>
                    <SelectTrigger className="h-8 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {tracosArgamassa.map((traco) => (
                        <SelectItem key={traco.id} value={traco.id}>
                          <div className="flex flex-col">
                            <span className="font-medium text-sm">{traco.nome}</span>
                            <span className="text-xs text-gray-500">{traco.descricao}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            )}
          </Card>

          {/* Mão de Obra */}
          <Card>
            <CardHeader 
              className="cursor-pointer py-3"
              onClick={() => toggleSecao('maoObra')}
            >
              <CardTitle className="flex items-center justify-between text-base">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Mão de Obra
                </div>
                {secaoAberta.maoObra ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </CardTitle>
            </CardHeader>
            {secaoAberta.maoObra && (
              <CardContent className="space-y-3 pt-0">
                <div>
                  <Label htmlFor="produtividadePedreiro" className="text-sm">Produtividade (m²/dia)</Label>
                  <Select 
                    value={maoDeObra.produtividadePedreiro} 
                    onValueChange={(value) => setMaoDeObra({...maoDeObra, produtividadePedreiro: value})}
                  >
                    <SelectTrigger className="h-8 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 m²/dia (Baixa)</SelectItem>
                      <SelectItem value="8">8 m²/dia (Média)</SelectItem>
                      <SelectItem value="12">12 m²/dia (Alta)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label htmlFor="valorDiariaPedreiro" className="text-sm">Pedreiro (R$)</Label>
                    <Input
                      id="valorDiariaPedreiro"
                      type="number"
                      value={maoDeObra.valorDiariaPedreiro}
                      onChange={(e) => setMaoDeObra({...maoDeObra, valorDiariaPedreiro: e.target.value})}
                      placeholder="150"
                      className="h-8 text-sm"
                    />
                  </div>
                  <div>
                    <Label htmlFor="valorDiariaAjudante" className="text-sm">Ajudante (R$)</Label>
                    <Input
                      id="valorDiariaAjudante"
                      type="number"
                      value={maoDeObra.valorDiariaAjudante}
                      onChange={(e) => setMaoDeObra({...maoDeObra, valorDiariaAjudante: e.target.value})}
                      placeholder="100"
                      className="h-8 text-sm"
                    />
                  </div>
                </div>
              </CardContent>
            )}
          </Card>

          {/* Botão Calcular */}
          <Button onClick={calcularMateriais} className="w-full h-12 text-base" size="lg">
            <Calculator className="w-4 h-4 mr-2" />
            Calcular Materiais
          </Button>

          {/* Resultados */}
          {resultados && (
            <div className="space-y-3">
              {/* Resumo Compacto */}
              <Card>
                <CardHeader className="py-3">
                  <CardTitle className="text-base text-green-700">Resumo</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="grid grid-cols-2 gap-2 text-center">
                    <div className="p-2 bg-green-50 rounded">
                      <p className="text-xs text-gray-600">Área Líquida</p>
                      <p className="text-lg font-bold text-green-600">{resultados.areaLiquida} m²</p>
                    </div>
                    <div className="p-2 bg-orange-50 rounded">
                      <p className="text-xs text-gray-600">{resultados.tijolos.unidade}</p>
                      <p className="text-lg font-bold text-orange-600">{resultados.tijolos.quantidade}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Materiais Compacto */}
              <Card>
                <CardHeader className="py-3">
                  <CardTitle className="text-base">Materiais</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span>Cimento (50kg)</span>
                      <Badge variant="default" className="bg-blue-600 text-xs">
                        {resultados.argamassa.cimento} sacos
                      </Badge>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span>Areia Média</span>
                      <Badge variant="default" className="bg-yellow-600 text-xs">
                        {resultados.argamassa.areia} m³
                      </Badge>
                    </div>
                    {resultados.argamassa.cal > 0 && (
                      <div className="flex justify-between items-center text-sm">
                        <span>Cal (20kg)</span>
                        <Badge variant="default" className="bg-green-600 text-xs">
                          {resultados.argamassa.cal} sacos
                        </Badge>
                      </div>
                    )}
                    <div className="flex justify-between items-center text-sm">
                      <span>Água</span>
                      <Badge variant="default" className="bg-cyan-600 text-xs">
                        {resultados.argamassa.agua}L
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Custos Compacto */}
              <Card>
                <CardHeader className="py-3">
                  <CardTitle className="text-base text-green-700">Custos</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-sm">
                      <span>Materiais</span>
                      <span className="font-semibold">R$ {resultados.custos.materiais}</span>
                    </div>
                    <div className="flex justify-between items-center text-sm">
                      <span>Mão de Obra ({resultados.maoDeObra.tempoPedreiro} dias)</span>
                      <span className="font-semibold">R$ {resultados.custos.maoDeObra}</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-green-100 rounded text-sm">
                      <span className="font-semibold">Total</span>
                      <span className="font-bold text-green-700">R$ {resultados.custos.total}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

const CalculoMateriais = ({ onBack }) => {
  const [etapaSelecionada, setEtapaSelecionada] = useState(null);

  const handleEtapaChange = (etapaId) => {
    setEtapaSelecionada(etapaId);
  };

  const renderEtapaComponent = () => {
    switch (etapaSelecionada) {
      case 'alvenaria':
        return <CalculoAlvenariaInterno onBack={() => setEtapaSelecionada(null)} />;
      default:
        return (
          <Card>
            <CardContent className="p-8">
              <div className="text-center">
                <Calculator className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2">Selecione uma Etapa</h3>
                <p className="text-gray-600">
                  Escolha uma etapa da obra para calcular os materiais necessários.
                </p>
              </div>
            </CardContent>
          </Card>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-2 sm:p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center mb-4">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onBack}
            className="mr-2"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="bg-orange-500 w-8 h-8 rounded-full flex items-center justify-center mr-2">
            <Calculator className="w-4 h-4 text-white" />
          </div>
          <h1 className="text-lg sm:text-xl font-bold text-gray-800">Cálculo de Materiais</h1>
        </div>

        {!etapaSelecionada ? (
          <>
            <div className="mb-4">
              <h2 className="text-base font-semibold text-gray-800 mb-2">Selecione a etapa da obra:</h2>
              <p className="text-sm text-gray-600">Escolha uma das etapas abaixo para calcular os materiais necessários.</p>
            </div>
            
            {/* Agrupando por categoria */}
            {['Preparação', 'Estrutura', 'Vedação', 'Cobertura', 'Instalações', 'Acabamento'].map(categoria => {
              const etapasDaCategoria = etapasBase.filter(etapa => etapa.categoria === categoria);
              
              if (etapasDaCategoria.length === 0) return null;
              
              return (
                <div key={categoria} className="mb-6">
                  <h3 className="text-sm font-semibold text-gray-700 mb-2 border-b pb-1">{categoria}</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {etapasDaCategoria.map((etapa) => (
                      <Card 
                        key={etapa.id} 
                        className="cursor-pointer hover:shadow-lg transition-shadow duration-200"
                        onClick={() => handleEtapaChange(etapa.id)}
                      >
                        <CardHeader className="py-3">
                          <CardTitle className="flex items-center gap-2 text-sm">
                            <etapa.icone className="w-4 h-4" />
                            {etapa.nome}
                          </CardTitle>
                          <CardDescription className="text-xs">{etapa.descricao}</CardDescription>
                        </CardHeader>
                      </Card>
                    ))}
                  </div>
                </div>
              );
            })}
          </>
        ) : (
          renderEtapaComponent()
        )}
      </div>
    </div>
  );
};

export default CalculoMateriais;


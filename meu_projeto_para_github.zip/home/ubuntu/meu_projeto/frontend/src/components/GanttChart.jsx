import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { RotateCcw, Calendar, CalendarDays, Edit, Save, Palette } from 'lucide-react';
import EditTaskModal from './EditTaskModal.jsx';

const GanttChart = ({ tasks = [] }) => {
  const [scale, setScale] = useState(1);
  const [viewType, setViewType] = useState('weeks'); // 'weeks' ou 'days'
  const [draggedTask, setDraggedTask] = useState(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [isPanning, setIsPanning] = useState(false);
  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 });
  const [lastPanPoint, setLastPanPoint] = useState({ x: 0, y: 0 });
  const [isEditMode, setIsEditMode] = useState(false);
  const [editingTask, setEditingTask] = useState(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [selectedTaskIndex, setSelectedTaskIndex] = useState(null);
  const [draggedTaskPosition, setDraggedTaskPosition] = useState(null);
  const [localTasks, setLocalTasks] = useState([]);
  const [initialClickPosition, setInitialClickPosition] = useState({ x: 0, y: 0 });
  const [hasMovedThreshold, setHasMovedThreshold] = useState(false);
  const [initialMousePosition, setInitialMousePosition] = useState({ x: 0, y: 0 });
  const [dragStartPosition, setDragStartPosition] = useState({ x: 0, y: 0 });
  const containerRef = useRef(null);
  const chartContainerRef = useRef(null);

  // Validação e tratamento dos dados de entrada
  const validTasks = Array.isArray(tasks) ? tasks.filter(task => {
    try {
      return task && 
        task.start && 
        task.end && 
        task.name &&
        !isNaN(new Date(task.start).getTime()) &&
        !isNaN(new Date(task.end).getTime());
    } catch (error) {
      console.warn('Tarefa inválida filtrada:', task, error);
      return false;
    }
  }) : [];

  // Inicializar tarefas locais quando as tarefas originais mudarem
  useEffect(() => {
    setLocalTasks([...validTasks]);
  }, [tasks]);

  // Usar tarefas locais para renderização
  const tasksToRender = localTasks.length > 0 ? localTasks : validTasks;

  // Se não há tarefas válidas, retorna uma mensagem
  if (validTasks.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 bg-gray-50 rounded-lg border">
        <div className="text-center">
          <p className="text-gray-500 text-lg">Nenhuma tarefa válida encontrada</p>
          <p className="text-gray-400 text-sm mt-2">Verifique se as tarefas possuem datas de início e fim válidas</p>
        </div>
      </div>
    );
  }

  // Função para obter feriados brasileiros (simplificada)
  const getFeriadosBrasileiros = (year) => {
    try {
      const feriados = [
        `${year}-01-01`, // Confraternização Universal
        `${year}-04-21`, // Tiradentes
        `${year}-05-01`, // Dia do Trabalho
        `${year}-09-07`, // Independência do Brasil
        `${year}-10-12`, // Nossa Senhora Aparecida
        `${year}-11-02`, // Finados
        `${year}-11-15`, // Proclamação da República
        `${year}-12-25`  // Natal
      ];
      return feriados.map(f => new Date(f)).filter(date => !isNaN(date.getTime()));
    } catch (error) {
      console.warn('Erro ao gerar feriados:', error);
      return [];
    }
  };

  // Função para verificar se é dia não útil
  const isDiaUtil = (date) => {
    try {
      const dayOfWeek = date.getDay();
      const year = date.getFullYear();
      const feriados = getFeriadosBrasileiros(year);
      
      // Sábado (6) ou Domingo (0)
      if (dayOfWeek === 0 || dayOfWeek === 6) return false;
      
      // Feriados
      const dateString = date.toISOString().split('T')[0];
      return !feriados.some(feriado => {
        try {
          return feriado.toISOString().split('T')[0] === dateString;
        } catch (error) {
          return false;
        }
      });
    } catch (error) {
      console.warn('Erro ao verificar dia útil:', error);
      return true; // Assume que é dia útil em caso de erro
    }
  };

  // Função para obter cor do dia
  const getCorDia = (date) => {
    try {
      const dayOfWeek = date.getDay();
      const year = date.getFullYear();
      const feriados = getFeriadosBrasileiros(year);
      const dateString = date.toISOString().split('T')[0];
      
      // Domingo ou feriado - vermelho claro
      if (dayOfWeek === 0 || feriados.some(feriado => {
        try {
          return feriado.toISOString().split('T')[0] === dateString;
        } catch (error) {
          return false;
        }
      })) {
        return '#ffebee'; // Vermelho claro
      }
      
      // Sábado - amarelo claro
      if (dayOfWeek === 6) {
        return '#fffde7'; // Amarelo claro
      }
      
      return 'transparent'; // Dia útil
    } catch (error) {
      console.warn('Erro ao obter cor do dia:', error);
      return 'transparent';
    }
  };

  // Calcular intervalo de datas com tratamento de erro
  let minDate, maxDate;
  try {
    const allDates = validTasks.flatMap(task => [new Date(task.start), new Date(task.end)]);
    minDate = new Date(Math.min(...allDates));
    maxDate = new Date(Math.max(...allDates));
    
    // Verificar se as datas são válidas
    if (isNaN(minDate.getTime()) || isNaN(maxDate.getTime())) {
      throw new Error('Datas inválidas encontradas');
    }
    
    // Adicionar margem de alguns dias
    minDate.setDate(minDate.getDate() - 3);
    maxDate.setDate(maxDate.getDate() + 3);
  } catch (error) {
    console.error('Erro ao calcular intervalo de datas:', error);
    // Fallback para datas padrão
    minDate = new Date();
    maxDate = new Date();
    maxDate.setDate(maxDate.getDate() + 30);
  }

  // Gerar array de semanas ou dias baseado no viewType
  const timeUnits = [];
  let unitWidth, chartWidth;
  
  if (viewType === 'weeks') {
    // Gerar array de semanas
    try {
      // Encontrar o início da primeira semana (segunda-feira)
      const firstWeekStart = new Date(minDate);
      const dayOfWeek = firstWeekStart.getDay();
      const daysToMonday = dayOfWeek === 0 ? 6 : dayOfWeek - 1; // Domingo = 0, então 6 dias para segunda
      firstWeekStart.setDate(firstWeekStart.getDate() - daysToMonday);
      
      const currentWeekStart = new Date(firstWeekStart);
      let weekNumber = 1;
      
      while (currentWeekStart <= maxDate && timeUnits.length < 52) { // Limite de segurança
        const weekEnd = new Date(currentWeekStart);
        weekEnd.setDate(weekEnd.getDate() + 6); // Domingo da semana
        
        timeUnits.push({
          start: new Date(currentWeekStart),
          end: weekEnd,
          number: weekNumber,
          label: `S${weekNumber}`,
          type: 'week'
        });
        
        currentWeekStart.setDate(currentWeekStart.getDate() + 7);
        weekNumber++;
      }
    } catch (error) {
      console.error('Erro ao gerar array de semanas:', error);
    }
    unitWidth = 80; // Largura para semanas
  } else {
    // Gerar array de dias
    try {
      const currentDate = new Date(minDate);
      while (currentDate <= maxDate && timeUnits.length < 365) { // Limite de segurança
        timeUnits.push({
          start: new Date(currentDate),
          end: new Date(currentDate),
          label: currentDate.getDate().toString(),
          month: currentDate.toLocaleDateString('pt-BR', { month: 'short' }),
          isFirstOfMonth: currentDate.getDate() === 1,
          backgroundColor: getCorDia(currentDate),
          type: 'day'
        });
        currentDate.setDate(currentDate.getDate() + 1);
      }
    } catch (error) {
      console.error('Erro ao gerar array de dias:', error);
    }
    unitWidth = 25; // Largura menor para dias
  }

  // Configurações do gráfico
  const taskHeight = 30;
  const taskSpacing = 10;
  const headerHeight = 60;
  const leftPanelWidth = 200;

  chartWidth = timeUnits.length * unitWidth;
  const chartHeight = validTasks.length * (taskHeight + taskSpacing) + headerHeight;

  // Função para converter data em posição X
  const dateToX = (date) => {
    try {
      const taskDate = new Date(date);
      
      if (viewType === 'weeks') {
        // Encontrar em qual semana a data está
        for (let i = 0; i < timeUnits.length; i++) {
          const unit = timeUnits[i];
          if (taskDate >= unit.start && taskDate <= unit.end) {
            // Posição dentro da semana (0-6 dias)
            const dayInWeek = Math.floor((taskDate - unit.start) / (1000 * 60 * 60 * 24));
            const dayWidth = unitWidth / 7;
            return i * unitWidth + dayInWeek * dayWidth;
          }
        }
        
        // Se não encontrou a semana, calcular baseado na primeira semana
        const firstUnit = timeUnits[0];
        if (firstUnit) {
          const weeksDiff = Math.floor((taskDate - firstUnit.start) / (1000 * 60 * 60 * 24 * 7));
          return weeksDiff * unitWidth;
        }
      } else {
        // Para dias, calcular a diferença em dias
        const daysDiff = Math.floor((taskDate - minDate) / (1000 * 60 * 60 * 24));
        return daysDiff * unitWidth;
      }
      
      return 0;
    } catch (error) {
      console.warn('Erro ao converter data para X:', error);
      return 0;
    }
  };

  // Função para converter posição X de volta para data
  const xToDate = (x) => {
    try {
      if (viewType === 'weeks') {
        const weekIndex = Math.floor(x / unitWidth);
        const dayInWeek = Math.floor((x % unitWidth) / (unitWidth / 7));
        
        if (timeUnits[weekIndex]) {
          const weekStart = new Date(timeUnits[weekIndex].start);
          weekStart.setDate(weekStart.getDate() + dayInWeek);
          return weekStart;
        }
      } else {
        const dayIndex = Math.floor(x / unitWidth);
        const targetDate = new Date(minDate);
        targetDate.setDate(targetDate.getDate() + dayIndex);
        return targetDate;
      }
      
      return new Date();
    } catch (error) {
      console.warn('Erro ao converter X para data:', error);
      return new Date();
    }
  };

  // Funções para pan do gráfico
  const handleChartMouseDown = (e) => {
    // Se não estiver clicando em uma tarefa, iniciar pan
    if (e.target.tagName === 'svg' || e.target.tagName === 'g') {
      setIsPanning(true);
      setLastPanPoint({ x: e.clientX, y: e.clientY });
    }
  };

  // Funções para drag and drop
  const handleMouseDown = (e, taskIndex) => {
    // Drag-and-drop só funciona no modo de edição
    if (!isEditMode) return;
    
    e.preventDefault();
    e.stopPropagation(); // Evitar que o pan seja ativado
    
    const task = tasksToRender[taskIndex];
    const startX = dateToX(new Date(task.start));
    
    // Armazenar posições iniciais em coordenadas de tela
    setInitialMousePosition({ x: e.clientX, y: e.clientY });
    setDragStartPosition({ x: startX, y: 0 });
    setHasMovedThreshold(false);
    
    setDraggedTask(taskIndex);
    // NÃO definir draggedTaskPosition aqui - deixar null até o threshold ser atingido
    setDraggedTaskPosition(null);
    setIsDragging(true);
    
    console.log('Iniciando drag da tarefa:', task.name);
    console.log('Posição inicial SVG:', startX);
    console.log('Posição inicial mouse:', e.clientX, e.clientY);
  };

  // Função para eventos de toque - Touch Start
  const handleTouchStart = (e, taskIndex) => {
    // Drag-and-drop só funciona no modo de edição
    if (!isEditMode) return;
    
    e.preventDefault();
    e.stopPropagation();
    
    const touch = e.touches[0];
    const task = tasksToRender[taskIndex];
    const startX = dateToX(new Date(task.start));
    
    // Armazenar posições iniciais em coordenadas de tela
    setInitialMousePosition({ x: touch.clientX, y: touch.clientY });
    setDragStartPosition({ x: startX, y: 0 });
    setHasMovedThreshold(false);
    
    setDraggedTask(taskIndex);
    setDraggedTaskPosition(null);
    setIsDragging(true);
    
    console.log('Iniciando touch drag da tarefa:', task.name);
    console.log('Posição inicial SVG:', startX);
    console.log('Posição inicial touch:', touch.clientX, touch.clientY);
  };

  const handleMouseMove = (e) => {
    if (isPanning) {
      e.preventDefault();
      const deltaX = e.clientX - lastPanPoint.x;
      const deltaY = e.clientY - lastPanPoint.y;
      
      setPanOffset(prev => ({
        x: prev.x + deltaX,
        y: prev.y + deltaY
      }));
      
      setLastPanPoint({ x: e.clientX, y: e.clientY });
      return;
    }
    
    // Drag-and-drop funciona apenas no modo de edição
    if (!isDragging || draggedTask === null || !isEditMode) return;
    
    // Calcular distância do movimento desde o clique inicial (em coordenadas de tela)
    const deltaX = Math.abs(e.clientX - initialMousePosition.x);
    const deltaY = Math.abs(e.clientY - initialMousePosition.y);
    const totalMovement = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    
    // Threshold mínimo de 5 pixels para considerar movimento
    const MOVEMENT_THRESHOLD = 5;
    
    if (!hasMovedThreshold && totalMovement < MOVEMENT_THRESHOLD) {
      // Não mover a barra até que o threshold seja atingido
      return;
    }
    
    // Marcar que o threshold foi atingido
    if (!hasMovedThreshold) {
      setHasMovedThreshold(true);
    }
    
    e.preventDefault();
    
    // Calcular diferença em coordenadas de tela
    const screenDeltaX = e.clientX - initialMousePosition.x;
    
    // Converter diferença para coordenadas SVG
    const svgDeltaX = screenDeltaX / scale;
    
    // Nova posição = posição inicial + diferença
    const newX = dragStartPosition.x + svgDeltaX;
    
    // Atualizar temporariamente a posição da tarefa para feedback visual
    setDraggedTaskPosition(newX);
    
    console.log('Arrastando - DeltaX tela:', screenDeltaX, 'DeltaX SVG:', svgDeltaX, 'Nova posição:', newX);
  };

  // Função para eventos de toque - Touch Move
  const handleTouchMove = (e) => {
    if (isPanning) {
      e.preventDefault();
      const touch = e.touches[0];
      const deltaX = touch.clientX - lastPanPoint.x;
      const deltaY = touch.clientY - lastPanPoint.y;
      
      setPanOffset(prev => ({
        x: prev.x + deltaX,
        y: prev.y + deltaY
      }));
      
      setLastPanPoint({ x: touch.clientX, y: touch.clientY });
      return;
    }
    
    // Drag-and-drop funciona apenas no modo de edição
    if (!isDragging || draggedTask === null || !isEditMode) return;
    
    const touch = e.touches[0];
    
    // Calcular distância do movimento desde o toque inicial
    const deltaX = Math.abs(touch.clientX - initialMousePosition.x);
    const deltaY = Math.abs(touch.clientY - initialMousePosition.y);
    const totalMovement = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    
    // Threshold mínimo de 5 pixels para considerar movimento
    const MOVEMENT_THRESHOLD = 5;
    
    if (!hasMovedThreshold && totalMovement < MOVEMENT_THRESHOLD) {
      return;
    }
    
    if (!hasMovedThreshold) {
      setHasMovedThreshold(true);
    }
    
    e.preventDefault();
    
    // Calcular diferença em coordenadas de tela
    const screenDeltaX = touch.clientX - initialMousePosition.x;
    
    // Converter diferença para coordenadas SVG
    const svgDeltaX = screenDeltaX / scale;
    
    // Nova posição = posição inicial + diferença
    const newX = dragStartPosition.x + svgDeltaX;
    
    // Atualizar temporariamente a posição da tarefa para feedback visual
    setDraggedTaskPosition(newX);
    
    console.log('Touch arrastando - DeltaX tela:', screenDeltaX, 'DeltaX SVG:', svgDeltaX, 'Nova posição:', newX);
  };

  const handleMouseUp = () => {
    if (isDragging && draggedTask !== null && isEditMode && draggedTaskPosition !== null && hasMovedThreshold) {
      // Só aplicar mudanças se o usuário realmente moveu a barra
      const newStartDate = xToDate(draggedTaskPosition);
      const task = tasksToRender[draggedTask];
      const duration = new Date(task.end) - new Date(task.start);
      const newEndDate = new Date(newStartDate.getTime() + duration);
      
      console.log('Tarefa movida:', task.name);
      console.log('Nova data de início:', newStartDate.toLocaleDateString());
      console.log('Nova data de fim:', newEndDate.toLocaleDateString());
      
      // Atualizar as tarefas locais com as novas datas
      setLocalTasks(prevTasks => {
        const newTasks = [...prevTasks];
        newTasks[draggedTask] = {
          ...task,
          start: newStartDate.toISOString().split('T')[0],
          end: newEndDate.toISOString().split('T')[0]
        };
        return newTasks;
      });
    } else if (isDragging && draggedTask !== null && isEditMode && !hasMovedThreshold) {
      // Se não moveu além do threshold, apenas resetar
      console.log('Clique simples - posição mantida');
    }
    
    // Resetar todos os estados de drag
    setIsDragging(false);
    setDraggedTask(null);
    setDraggedTaskPosition(null);
    setDragOffset({ x: 0, y: 0 });
    setHasMovedThreshold(false);
    setInitialClickPosition({ x: 0, y: 0 });
    setInitialMousePosition({ x: 0, y: 0 });
    setDragStartPosition({ x: 0, y: 0 });
    setIsPanning(false);
  };

  // Função para eventos de toque - Touch End
  const handleTouchEnd = () => {
    if (isDragging && draggedTask !== null && isEditMode && draggedTaskPosition !== null && hasMovedThreshold) {
      // Só aplicar mudanças se o usuário realmente moveu a barra
      const newStartDate = xToDate(draggedTaskPosition);
      const task = tasksToRender[draggedTask];
      const duration = new Date(task.end) - new Date(task.start);
      const newEndDate = new Date(newStartDate.getTime() + duration);
      
      console.log('Tarefa movida via touch:', task.name);
      console.log('Nova data de início:', newStartDate.toLocaleDateString());
      console.log('Nova data de fim:', newEndDate.toLocaleDateString());
      
      // Atualizar as tarefas locais com as novas datas
      setLocalTasks(prevTasks => {
        const newTasks = [...prevTasks];
        newTasks[draggedTask] = {
          ...task,
          start: newStartDate.toISOString().split('T')[0],
          end: newEndDate.toISOString().split('T')[0]
        };
        return newTasks;
      });
    } else if (isDragging && draggedTask !== null && isEditMode && !hasMovedThreshold) {
      console.log('Toque simples - posição mantida');
    }
    
    // Resetar todos os estados de drag
    setIsDragging(false);
    setDraggedTask(null);
    setDraggedTaskPosition(null);
    setDragOffset({ x: 0, y: 0 });
    setHasMovedThreshold(false);
    setInitialClickPosition({ x: 0, y: 0 });
    setInitialMousePosition({ x: 0, y: 0 });
    setDragStartPosition({ x: 0, y: 0 });
    setIsPanning(false);
  };

  // Funções para o modal de edição
  const handleTaskClick = (taskIndex) => {
    console.log('handleTaskClick chamado:', taskIndex, isEditMode);
    if (isEditMode) {
      const task = tasksToRender[taskIndex];
      console.log('Tarefa selecionada:', task);
      setSelectedTaskIndex(taskIndex);
      setEditingTask(task);
      setShowEditModal(true);
      console.log('Modal deveria abrir agora');
    }
  };

  const handleSaveTask = (updatedTask) => {
    if (selectedTaskIndex !== null) {
      // Como não podemos modificar o array original diretamente,
      // vamos apenas fechar o modal por enquanto
      // Em uma implementação real, isso seria passado para o componente pai
      console.log('Tarefa atualizada:', updatedTask);
      setShowEditModal(false);
      setEditingTask(null);
      setSelectedTaskIndex(null);
    }
  };

  const handleCloseModal = () => {
    setShowEditModal(false);
    setEditingTask(null);
    setSelectedTaskIndex(null);
  };

  // Função para calcular duração baseada no viewType
  const calcularDuracao = (startDate, endDate) => {
    try {
      const start = new Date(startDate);
      const end = new Date(endDate);
      const diffTime = Math.abs(end - start);
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (viewType === 'weeks') {
        const weeks = Math.ceil(diffDays / 7);
        return `${weeks} semana(s)`;
      } else {
        return `${diffDays} dia(s)`;
      }
    } catch (error) {
      console.warn('Erro ao calcular duração:', error);
      return viewType === 'weeks' ? '1 semana' : '1 dia';
    }
  };

  // Função para resetar zoom
  const resetZoom = () => {
    setScale(1);
  };

  // Implementação do zoom com scroll do mouse e pinça
  useEffect(() => {
    const chartContainer = chartContainerRef.current;
    if (!chartContainer) return;

    const handleWheel = (e) => {
      e.preventDefault();
      const delta = e.deltaY > 0 ? -0.1 : 0.1;
      setScale(prevScale => Math.max(0.5, Math.min(3, prevScale + delta)));
    };

    const handleTouchStart = (e) => {
      if (e.touches.length === 2) {
        const touch1 = e.touches[0];
        const touch2 = e.touches[1];
        const distance = Math.sqrt(
          Math.pow(touch2.clientX - touch1.clientX, 2) +
          Math.pow(touch2.clientY - touch1.clientY, 2)
        );
        chartContainer.dataset.initialPinchDistance = distance;
        chartContainer.dataset.initialScale = scale;
      }
    };

    const handleTouchMove = (e) => {
      if (e.touches.length === 2) {
        e.preventDefault();
        const touch1 = e.touches[0];
        const touch2 = e.touches[1];
        const distance = Math.sqrt(
          Math.pow(touch2.clientX - touch1.clientX, 2) +
          Math.pow(touch2.clientY - touch1.clientY, 2)
        );
        
        const initialDistance = parseFloat(chartContainer.dataset.initialPinchDistance);
        const initialScale = parseFloat(chartContainer.dataset.initialScale);
        
        if (initialDistance && initialScale) {
          const scaleChange = distance / initialDistance;
          const newScale = initialScale * scaleChange;
          setScale(Math.max(0.5, Math.min(3, newScale)));
        }
      }
    };

    chartContainer.addEventListener('wheel', handleWheel, { passive: false });
    chartContainer.addEventListener('touchstart', handleTouchStart, { passive: true });
    chartContainer.addEventListener('touchmove', handleTouchMove, { passive: false });

    return () => {
      chartContainer.removeEventListener('wheel', handleWheel);
      chartContainer.removeEventListener('touchstart', handleTouchStart);
      chartContainer.removeEventListener('touchmove', handleTouchMove);
    };
  }, [scale]);

  // Debug: log das tarefas válidas
  console.log('Tarefas válidas:', validTasks);
  console.log('Datas min/max:', minDate, maxDate);
  console.log('Tipo de visualização:', viewType);
  console.log('Unidades de tempo:', timeUnits.length);
  console.log('TimeUnits:', timeUnits);

  return (
    <div 
      ref={containerRef}
      className="relative bg-white border rounded-lg"
      style={{ height: '600px' }}
    >
      {/* Barra de ferramentas */}
      <div className="absolute top-2 right-2 z-10 flex gap-2">
        {/* Controles de visualização */}
        <div className="flex gap-1 bg-white border rounded-md p-1">
          <Button
            variant={viewType === 'weeks' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewType('weeks')}
            title="Visualizar por Semanas"
            className="px-2 py-1 text-xs"
          >
            <CalendarDays className="h-3 w-3 mr-1" />
            Semanas
          </Button>
          <Button
            variant={viewType === 'days' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewType('days')}
            title="Visualizar por Dias"
            className="px-2 py-1 text-xs"
          >
            <Calendar className="h-3 w-3 mr-1" />
            Dias
          </Button>
        </div>
        
        {/* Botão Editar */}
        <Button
          variant={isEditMode ? 'default' : 'outline'}
          size="sm"
          onClick={() => setIsEditMode(!isEditMode)}
          title={isEditMode ? "Sair do Modo de Edição" : "Modo de Edição"}
        >
          <Edit className="h-4 w-4" />
          {isEditMode ? 'Sair' : 'Editar'}
        </Button>
        
        <Button
          variant="outline"
          size="sm"
          onClick={resetZoom}
          title="Resetar Zoom"
        >
          <RotateCcw className="h-4 w-4" />
        </Button>
      </div>

      {/* Instruções de uso */}
      <div className="absolute top-2 left-2 z-10 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
        Use scroll do mouse ou pinça para zoom
      </div>

      {/* Gráfico de Gantt */}
      <div 
        ref={chartContainerRef}
        className="w-full h-full overflow-auto cursor-grab active:cursor-grabbing"
        style={{ touchAction: 'pan-x pan-y' }}
      >
        <div 
          className="flex h-full"
          style={{ 
            transform: `scale(${scale})`,
            transformOrigin: 'top left',
            minWidth: leftPanelWidth + chartWidth,
            minHeight: chartHeight
          }}
        >
          {/* Painel esquerdo com nomes das tarefas */}
          <div className="bg-gray-50 border-r" style={{ width: leftPanelWidth, minHeight: chartHeight }}>
            <div className="sticky top-0 bg-gray-100 border-b p-2 font-semibold" style={{ height: headerHeight }}>
              Tarefas
            </div>
            {tasksToRender.map((task, index) => (
              <div
                key={task.id || index}
                className="border-b p-2 text-sm"
                style={{ height: taskHeight + taskSpacing }}
              >
                <div className="truncate font-medium">{task.name}</div>
                <div className="text-xs text-gray-500">
                  {calcularDuracao(new Date(task.start), new Date(task.end))}
                </div>
              </div>
            ))}
          </div>

          {/* Área do gráfico */}
          <div className="flex-1 overflow-hidden">
            <svg 
              width={chartWidth} 
              height={chartHeight} 
              className="block"
              onMouseDown={handleChartMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
              style={{ cursor: isPanning ? 'grabbing' : 'grab', touchAction: 'none' }}
            >
              <g transform={`translate(${panOffset.x}, ${panOffset.y})`}>
              {/* Cabeçalho com semanas ou dias */}
              <g>
                {timeUnits.map((unit, index) => (
                  <g key={index}>
                    {/* Fundo colorido para fins de semana e feriados (apenas para dias) */}
                    {viewType === 'days' && unit.backgroundColor !== 'transparent' && (
                      <rect
                        x={index * unitWidth}
                        y={0}
                        width={unitWidth}
                        height={chartHeight}
                        fill={unit.backgroundColor}
                        opacity={0.5}
                      />
                    )}
                    
                    {/* Linha vertical */}
                    <line
                      x1={index * unitWidth}
                      y1={0}
                      x2={index * unitWidth}
                      y2={chartHeight}
                      stroke="#e5e7eb"
                      strokeWidth={1}
                    />
                    
                    {/* Label da unidade de tempo */}
                    <text
                      x={index * unitWidth + unitWidth / 2}
                      y={headerHeight / 2}
                      textAnchor="middle"
                      dominantBaseline="middle"
                      fontSize={viewType === 'weeks' ? "14" : "12"}
                      fontWeight="bold"
                      fill="#374151"
                    >
                      {unit.label}
                    </text>
                    
                    {/* Informação adicional */}
                    {viewType === 'weeks' ? (
                      <text
                        x={index * unitWidth + unitWidth / 2}
                        y={headerHeight - 10}
                        textAnchor="middle"
                        fontSize="10"
                        fill="#6b7280"
                      >
                        {unit.start.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}
                      </text>
                    ) : (
                      unit.isFirstOfMonth && (
                        <text
                          x={index * unitWidth + unitWidth / 2}
                          y={headerHeight - 10}
                          textAnchor="middle"
                          fontSize="10"
                          fill="#6b7280"
                        >
                          {unit.month}
                        </text>
                      )
                    )}
                  </g>
                ))}
              </g>

              {/* Barras das tarefas */}
              <g>
                {tasksToRender.map((task, index) => {
                  try {
                    const startX = dateToX(task.start);
                    const endX = dateToX(task.end);
                    const width = Math.max(endX - startX, unitWidth / (viewType === 'weeks' ? 7 : 2));
                    const y = headerHeight + index * (taskHeight + taskSpacing) + taskSpacing / 2;
                    
                    console.log(`Tarefa ${index}: ${task.name}`);
                    console.log(`  Start: ${task.start}, End: ${task.end}`);
                    console.log(`  StartX: ${startX}, EndX: ${endX}, Width: ${width}`);
                    console.log(`  Y: ${y}, TaskHeight: ${taskHeight}`);
                    
                    // Cor da barra baseada na cor da tarefa ou cor padrão
                    let barColor = '#3b82f6'; // Azul padrão
                    if (task.styles?.backgroundColor) {
                      barColor = task.styles.backgroundColor;
                    } else if (task.cor) {
                      // Converter classes CSS para cores hex
                      const colorMap = {
                        'bg-green-400': '#4ade80',
                        'bg-green-500': '#22c55e',
                        'bg-green-600': '#16a34a',
                        'bg-green-700': '#15803d',
                        'bg-green-800': '#166534',
                        'bg-gray-600': '#4b5563',
                        'bg-gray-700': '#374151',
                        'bg-orange-500': '#f97316',
                        'bg-blue-600': '#2563eb',
                        'bg-purple-500': '#a855f7'
                      };
                      barColor = colorMap[task.cor] || barColor;
                    }

                    console.log(`Renderizando tarefa ${index}: ${task.name}, startX: ${startX}, width: ${width}, y: ${y}`);

                    return (
                      <g key={task.id || index}>
                        {/* Linha horizontal de fundo */}
                        <line
                          x1={0}
                          y1={y + taskHeight / 2}
                          x2={chartWidth}
                          y2={y + taskHeight / 2}
                          stroke="#f3f4f6"
                          strokeWidth={1}
                        />
                        
                        {/* Barra da tarefa */}
                        <rect
                          x={draggedTask === index && draggedTaskPosition !== null && hasMovedThreshold ? draggedTaskPosition : startX}
                          y={y}
                          width={width}
                          height={taskHeight}
                          fill={task.customColor || barColor}
                          stroke="#ffffff"
                          strokeWidth={1}
                          rx={4}
                          className={isEditMode ? "cursor-move draggable-element" : "cursor-pointer"}
                          onMouseDown={isEditMode ? (e) => handleMouseDown(e, index) : undefined}
                          onTouchStart={isEditMode ? (e) => handleTouchStart(e, index) : undefined}
                          onClick={!isEditMode ? (e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            console.log('Clicou na tarefa:', index, task.name);
                            handleTaskClick(index);
                          } : undefined}
                          style={{
                            opacity: draggedTask === index && hasMovedThreshold ? 0.7 : 1,
                            cursor: isEditMode ? 'move' : 'pointer',
                            pointerEvents: 'all',
                            touchAction: isEditMode ? 'none' : 'auto'
                          }}
                        />
                        
                        {/* Texto da tarefa (se houver espaço) */}
                        {width > 60 && (
                          <text
                            x={(draggedTask === index && draggedTaskPosition !== null && hasMovedThreshold ? draggedTaskPosition : startX) + width / 2}
                            y={y + taskHeight / 2}
                            textAnchor="middle"
                            dominantBaseline="middle"
                            fontSize="10"
                            fill="white"
                            className="pointer-events-none"
                          >
                            {task.name.length > 15 ? task.name.substring(0, 15) + '...' : task.name}
                          </text>
                        )}
                      </g>
                    );
                  } catch (error) {
                    console.warn('Erro ao renderizar tarefa:', task, error);
                    return null;
                  }
                })}
              </g>
              </g>
            </svg>
          </div>
        </div>
      </div>

      {/* Modal de Edição */}
      <EditTaskModal
        isOpen={showEditModal}
        onClose={handleCloseModal}
        task={editingTask}
        onSave={handleSaveTask}
      />
    </div>
  );
};

export default GanttChart;

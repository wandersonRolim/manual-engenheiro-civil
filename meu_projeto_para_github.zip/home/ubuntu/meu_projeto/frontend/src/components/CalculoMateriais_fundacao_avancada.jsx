import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { ArrowLeft, Calculator, Building2, Package, Droplets, Hammer, Zap, MapPin, Paintbrush, Home, CheckCircle, FileText, ChevronDown, ChevronUp, Wrench, Palette, DoorOpen, Plus, Trash2, Edit } from 'lucide-react'

// Seções reorganizadas e otimizadas
const secoes = [
  {
    id: 'alvenaria',
    nome: 'Alvenaria',
    icone: Building2,
    descricao: 'Tijolos/blocos, argamassa, cimento, areia'
  },
  {
    id: 'fundacao',
    nome: 'Fundação',
    icone: Hammer,
    descricao: 'Sapatas, vigas baldrame, pilares'
  },
  {
    id: 'estrutura',
    nome: 'Estrutura',
    icone: Building2,
    descricao: 'Pilares, vigas, lajes, ferragem'
  },
  {
    id: 'cobertura',
    nome: 'Cobertura',
    icone: Home,
    descricao: 'Telhas, madeiramento, calhas, rufos'
  },
  {
    id: 'instalacoes_hidraulicas',
    nome: 'Instalações Hidráulicas',
    icone: Droplets,
    descricao: 'Tubos, conexões, caixas d\'água'
  },
  {
    id: 'instalacoes_eletricas',
    nome: 'Instalações Elétricas',
    icone: Zap,
    descricao: 'Fios, cabos, disjuntores, tomadas'
  },
  {
    id: 'reboco',
    nome: 'Reboco',
    icone: Wrench,
    descricao: 'Argamassa, cimento, areia, cal'
  },
  {
    id: 'revestimento',
    nome: 'Revestimento',
    icone: Package,
    descricao: 'Pisos, azulejos, argamassa colante'
  },
  {
    id: 'pintura',
    nome: 'Pintura',
    icone: Palette,
    descricao: 'Tinta, primer, massa corrida'
  },
  {
    id: 'esquadrias',
    nome: 'Esquadrias',
    icone: DoorOpen,
    descricao: 'Portas, janelas, ferragens'
  }
]

// Tipos de sapatas
const tiposSapata = [
  { id: 'isolada', nome: 'Sapata Isolada', descricao: 'Para pilares individuais' },
  { id: 'corrida', nome: 'Sapata Corrida', descricao: 'Para paredes' },
  { id: 'associada', nome: 'Sapata Associada', descricao: 'Para múltiplos pilares' }
]

// Resistências de concreto
const resistenciasConcreto = [
  { id: 'c20', nome: 'C20', fck: 20 },
  { id: 'c25', nome: 'C25', fck: 25 },
  { id: 'c30', nome: 'C30', fck: 30 }
]

// Componente de seção colapsável otimizada para mobile
const SecaoColapsavel = ({ titulo, icone: Icone, isOpen, onToggle, children, badge = null }) => (
  <Card className="mb-2">
    <CardHeader 
      className="p-3 cursor-pointer" 
      onClick={onToggle}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icone className="h-4 w-4" />
          <CardTitle className="text-sm font-medium">{titulo}</CardTitle>
          {badge && <Badge variant="secondary" className="text-xs">{badge}</Badge>}
        </div>
        {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
      </div>
    </CardHeader>
    {isOpen && (
      <CardContent className="p-3 pt-0">
        {children}
      </CardContent>
    )}
  </Card>
)

// Componente de campo de entrada compacto
const CampoCompacto = ({ label, placeholder, value, onChange, type = "text", unit = "" }) => (
  <div className="space-y-1">
    <Label className="text-xs font-medium">{label}</Label>
    <div className="relative">
      <Input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className="h-8 text-sm pr-8"
      />
      {unit && (
        <span className="absolute right-2 top-1/2 transform -translate-y-1/2 text-xs text-gray-500">
          {unit}
        </span>
      )}
    </div>
  </div>
)

// Componente de resultado compacto
const ResultadoCompacto = ({ titulo, valor, unidade, destaque = false }) => (
  <div className={`p-2 rounded-lg ${destaque ? 'bg-blue-50 border border-blue-200' : 'bg-gray-50'}`}>
    <div className="text-xs text-gray-600">{titulo}</div>
    <div className={`text-sm font-semibold ${destaque ? 'text-blue-700' : 'text-gray-900'}`}>
      {valor} {unidade}
    </div>
  </div>
)

// Componente para item de lista (sapata, viga, pilar)
const ItemLista = ({ item, onEdit, onDelete, tipo }) => (
  <div className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
    <div className="flex-1">
      <div className="text-sm font-medium">
        {tipo === 'sapata' && `${item.tipo} - ${item.comprimento}x${item.largura}x${item.altura}m`}
        {tipo === 'viga' && `Viga ${item.largura}x${item.altura}cm - ${item.comprimento}m`}
        {tipo === 'pilar' && `Pilar ${item.largura}x${item.altura}cm - ${item.alturaTotal}m`}
      </div>
      <div className="text-xs text-gray-500">
        Qtd: {item.quantidade} | Vol: {item.volume?.toFixed(2)}m³
      </div>
    </div>
    <div className="flex gap-1">
      <Button variant="ghost" size="sm" onClick={() => onEdit(item)}>
        <Edit className="h-3 w-3" />
      </Button>
      <Button variant="ghost" size="sm" onClick={() => onDelete(item.id)}>
        <Trash2 className="h-3 w-3" />
      </Button>
    </div>
  </div>
)

export default function CalculoMateriais({ onBack }) {
  const [secaoSelecionada, setSecaoSelecionada] = useState(null)
  const [secaoAberta, setSecaoAberta] = useState({})
  const [dados, setDados] = useState({})
  const [resultados, setResultados] = useState({})
  
  // Estados específicos para fundação avançada
  const [sapatas, setSapatas] = useState([])
  const [vigas, setVigas] = useState([])
  const [pilares, setPilares] = useState([])
  const [editandoItem, setEditandoItem] = useState(null)
  const [tipoEditando, setTipoEditando] = useState(null)
  const [configuracoes, setConfiguracoes] = useState({
    resistenciaConcreto: 'c25',
    taxaAco: 80, // kg/m³
    precoConcreto: 400, // R$/m³
    precoAco: 7, // R$/kg
    precoPedreiro: 180, // R$/dia
    precoServente: 100 // R$/dia
  })

  const toggleSecao = (secaoId) => {
    setSecaoAberta(prev => ({
      ...prev,
      [secaoId]: !prev[secaoId]
    }))
  }

  const atualizarDado = (campo, valor) => {
    setDados(prev => ({
      ...prev,
      [campo]: valor
    }))
  }

  const atualizarConfiguracao = (campo, valor) => {
    setConfiguracoes(prev => ({
      ...prev,
      [campo]: valor
    }))
  }

  // Funções para gerenciar sapatas
  const adicionarSapata = () => {
    const novaSapata = {
      id: Date.now(),
      tipo: 'Sapata Isolada',
      comprimento: '',
      largura: '',
      altura: '',
      quantidade: 1,
      volume: 0
    }
    setEditandoItem(novaViga)
    setTipoEditando("viga")
  }

  const salvarViga = (viga) => {
    const volume = (parseFloat(viga.largura) / 100) * (parseFloat(viga.altura) / 100) * parseFloat(viga.comprimento) * parseInt(viga.quantidade)
    const vigaComVolume = { ...viga, volume }
    
    setEditandoItem(null)
    setTipoEditando(null)
    setVigas(prevVigas => {
      const updatedVigas = prevVigas.find(v => v.id === viga.id)
        ? prevVigas.map(v => v.id === viga.id ? vigaComVolume : v)
        : [...prevVigas, vigaComVolume];
      calcularFundacaoCompleta(sapatas, updatedVigas, pilares);
      return updatedVigas;
    });
  }

  const excluirViga = (id) => {
    setVigas(prev => prev.filter(v => v.id !== id))
  }

  // Funções para gerenciar pilares
  c  const adicionarViga = () => {
    const novaViga = {
      id: Date.now(),
      largura: 0,
      altura: 0,
      comprimento: 0,
      quantidade: 1,
      volume: 0
    }
    setEditandoItem(novaViga)
    setTipoEditando("viga")
  }}
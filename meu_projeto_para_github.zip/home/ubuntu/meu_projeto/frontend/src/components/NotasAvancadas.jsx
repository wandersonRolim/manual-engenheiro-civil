import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Checkbox } from '@/components/ui/checkbox.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { 
  StickyNote, 
  Plus, 
  Search, 
  Bell, 
  BellOff, 
  Trash2, 
  Edit, 
  Save, 
  X, 
  Palette,
  Tag,
  Clock,
  Grid,
  List,
  Filter,
  ArrowLeft
} from 'lucide-react'

const NotasAvancadas = ({ onBack }) => {
  const [notes, setNotes] = useState([])
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('todas')
  const [viewMode, setViewMode] = useState('grid') // 'grid' ou 'list'
  const [showForm, setShowForm] = useState(false)
  const [editingNote, setEditingNote] = useState(null)
  const [customCategories, setCustomCategories] = useState([])
  const [showNewCategoryForm, setShowNewCategoryForm] = useState(false)
  const [newCategoryName, setNewCategoryName] = useState('')
  const [newNote, setNewNote] = useState({
    title: '',
    content: '',
    category: 'pessoal',
    color: 'yellow',
    alarm: false,
    alarmTime: '',
    priority: 'normal'
  })

  // Cores disponíveis para as notas (paleta expandida)
  const colors = [
    { name: 'yellow', bg: 'bg-yellow-100', border: 'border-yellow-300', text: 'text-yellow-800', color: '#fef3c7' },
    { name: 'blue', bg: 'bg-blue-100', border: 'border-blue-300', text: 'text-blue-800', color: '#dbeafe' },
    { name: 'green', bg: 'bg-green-100', border: 'border-green-300', text: 'text-green-800', color: '#dcfce7' },
    { name: 'pink', bg: 'bg-pink-100', border: 'border-pink-300', text: 'text-pink-800', color: '#fce7f3' },
    { name: 'purple', bg: 'bg-purple-100', border: 'border-purple-300', text: 'text-purple-800', color: '#f3e8ff' },
    { name: 'orange', bg: 'bg-orange-100', border: 'border-orange-300', text: 'text-orange-800', color: '#fed7aa' },
    { name: 'red', bg: 'bg-red-100', border: 'border-red-300', text: 'text-red-800', color: '#fecaca' },
    { name: 'indigo', bg: 'bg-indigo-100', border: 'border-indigo-300', text: 'text-indigo-800', color: '#e0e7ff' },
    { name: 'teal', bg: 'bg-teal-100', border: 'border-teal-300', text: 'text-teal-800', color: '#ccfbf1' },
    { name: 'lime', bg: 'bg-lime-100', border: 'border-lime-300', text: 'text-lime-800', color: '#ecfccb' },
    { name: 'cyan', bg: 'bg-cyan-100', border: 'border-cyan-300', text: 'text-cyan-800', color: '#cffafe' },
    { name: 'rose', bg: 'bg-rose-100', border: 'border-rose-300', text: 'text-rose-800', color: '#fecdd3' },
    { name: 'amber', bg: 'bg-amber-100', border: 'border-amber-300', text: 'text-amber-800', color: '#fde68a' },
    { name: 'emerald', bg: 'bg-emerald-100', border: 'border-emerald-300', text: 'text-emerald-800', color: '#d1fae5' },
    { name: 'violet', bg: 'bg-violet-100', border: 'border-violet-300', text: 'text-violet-800', color: '#ede9fe' },
    { name: 'gray', bg: 'bg-gray-100', border: 'border-gray-300', text: 'text-gray-800', color: '#f3f4f6' }
  ]

  // Categorias disponíveis
  const categories = [
    { value: 'todas', label: 'Todas as categorias' },
    { value: 'pessoal', label: 'Pessoal' },
    { value: 'trabalho', label: 'Trabalho' },
    { value: 'projeto', label: 'Projeto' },
    { value: 'reuniao', label: 'Reunião' },
    { value: 'lembrete', label: 'Lembrete' },
    { value: 'ideia', label: 'Ideia' },
    { value: 'urgente', label: 'Urgente' }
  ]

  // Carregar notas do localStorage
  useEffect(() => {
    const savedNotes = localStorage.getItem('notasAvancadas')
    if (savedNotes) {
      setNotes(JSON.parse(savedNotes))
    }
  }, [])

  // Carregar categorias customizadas do localStorage
  useEffect(() => {
    const savedCategories = localStorage.getItem('customCategories')
    if (savedCategories) {
      setCustomCategories(JSON.parse(savedCategories))
    }
  }, [])

  // Salvar notas no localStorage
  useEffect(() => {
    localStorage.setItem('notasAvancadas', JSON.stringify(notes))
  }, [notes])

  // Salvar categorias customizadas no localStorage
  useEffect(() => {
    localStorage.setItem('customCategories', JSON.stringify(customCategories))
  }, [customCategories])

  // Verificar alarmes
  useEffect(() => {
    const checkAlarms = () => {
      const now = new Date()
      notes.forEach(note => {
        if (note.alarm && note.alarmTime) {
          const alarmTime = new Date(note.alarmTime)
          if (alarmTime <= now && !note.alarmTriggered) {
            // Marcar alarme como disparado
            setNotes(prev => prev.map(n => 
              n.id === note.id ? { ...n, alarmTriggered: true } : n
            ))
            
            // Mostrar notificação
            if ('Notification' in window && Notification.permission === 'granted') {
              new Notification(`Lembrete: ${note.title}`, {
                body: note.content,
                icon: '/icon-192.png'
              })
            } else {
              alert(`Lembrete: ${note.title}\n${note.content}`)
            }
          }
        }
      })
    }

    const interval = setInterval(checkAlarms, 60000) // Verificar a cada minuto
    return () => clearInterval(interval)
  }, [notes])

  // Solicitar permissão para notificações
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission()
    }
  }, [])

  // Função para obter cor da nota
  const getNoteColor = (colorName) => {
    return colors.find(c => c.name === colorName) || colors[0]
  }

  // Função para adicionar/editar nota
  const saveNote = () => {
    if (!newNote.title.trim() || !newNote.content.trim()) return

    const noteData = {
      ...newNote,
      id: editingNote ? editingNote.id : Date.now(),
      createdAt: editingNote ? editingNote.createdAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      alarmTriggered: false
    }

    if (editingNote) {
      setNotes(prev => prev.map(note => note.id === editingNote.id ? noteData : note))
    } else {
      setNotes(prev => [...prev, noteData])
    }

    resetForm()
  }

  // Função para resetar formulário
  const resetForm = () => {
    setNewNote({
      title: '',
      content: '',
      category: 'pessoal',
      color: 'yellow',
      alarm: false,
      alarmTime: '',
      priority: 'normal'
    })
    setEditingNote(null)
    setShowForm(false)
  }

  // Função para criar nova categoria
  const createNewCategory = () => {
    if (!newCategoryName.trim()) return
    
    const categoryValue = newCategoryName.toLowerCase().replace(/\s+/g, '_')
    const newCategory = {
      value: categoryValue,
      label: newCategoryName.trim()
    }
    
    // Verificar se a categoria já existe
    const allCategories = [...categories, ...customCategories]
    if (allCategories.some(cat => cat.value === categoryValue)) {
      alert('Esta categoria já existe!')
      return
    }
    
    setCustomCategories(prev => [...prev, newCategory])
    setNewCategoryName('')
    setShowNewCategoryForm(false)
    
    // Definir a nova categoria como selecionada na nota
    setNewNote(prev => ({ ...prev, category: categoryValue }))
  }

  // Função para obter todas as categorias (padrão + customizadas)
  const getAllCategories = () => {
    return [...categories, ...customCategories]
  }

  // Função para editar nota
  const editNote = (note) => {
    setNewNote(note)
    setEditingNote(note)
    setShowForm(true)
  }

  // Função para remover nota
  const removeNote = (id) => {
    setNotes(prev => prev.filter(note => note.id !== id))
  }

  // Função para duplicar nota
  const duplicateNote = (note) => {
    const duplicated = {
      ...note,
      id: Date.now(),
      title: `${note.title} (Cópia)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      alarmTriggered: false
    }
    setNotes(prev => [...prev, duplicated])
  }

  // Filtrar notas
  const filteredNotes = notes.filter(note => {
    const matchesSearch = note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         note.content.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'todas' || note.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  // Ordenar notas por prioridade e data
  const sortedNotes = filteredNotes.sort((a, b) => {
    // Primeiro por prioridade
    const priorityOrder = { urgente: 3, alta: 2, normal: 1, baixa: 0 }
    const aPriority = priorityOrder[a.priority] || 1
    const bPriority = priorityOrder[b.priority] || 1
    
    if (aPriority !== bPriority) {
      return bPriority - aPriority
    }
    
    // Depois por data de atualização
    return new Date(b.updatedAt) - new Date(a.updatedAt)
  })

  // Agrupar notas por categoria
  const groupedNotes = sortedNotes.reduce((groups, note) => {
    const category = note.category
    if (!groups[category]) {
      groups[category] = []
    }
    groups[category].push(note)
    return groups
  }, {})

  // Obter nome da categoria
  const getCategoryLabel = (categoryValue) => {
    const allCategories = getAllCategories()
    const category = allCategories.find(cat => cat.value === categoryValue)
    return category ? category.label : categoryValue
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onBack}
              className="mr-4"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="bg-pink-500 w-10 h-10 rounded-full flex items-center justify-center mr-3">
              <StickyNote className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-800">Notas Inteligentes</h1>
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('grid')}
            >
              <Grid className="w-4 h-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setViewMode('list')}
            >
              <List className="w-4 h-4" />
            </Button>
            <Button
              onClick={() => setShowForm(true)}
              className="bg-pink-500 hover:bg-pink-600 w-10 h-10 p-0 md:w-auto md:h-auto md:px-4 md:py-2"
            >
              <Plus className="w-4 h-4 md:mr-2" />
              <span className="hidden md:inline">Nova Nota</span>
            </Button>
          </div>
        </div>

        {/* Barra de pesquisa e filtros */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              type="text"
              placeholder="Pesquisar notas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full md:w-48">
              <Filter className="w-4 h-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {getAllCategories().map(category => (
                <SelectItem key={category.value} value={category.value}>
                  {category.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Formulário de nova nota */}
        {showForm && (
          <Card className="mb-6 border-2 border-pink-200">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                {editingNote ? 'Editar Nota' : 'Nova Nota'}
                <Button variant="ghost" size="sm" onClick={resetForm}>
                  <X className="w-4 h-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="note-title">Título</Label>
                  <Input
                    id="note-title"
                    value={newNote.title}
                    onChange={(e) => setNewNote({...newNote, title: e.target.value})}
                    placeholder="Digite o título da nota"
                  />
                </div>
                <div>
                  <Label htmlFor="note-category">Categoria</Label>
                  <div className="space-y-2">
                    <Select value={newNote.category} onValueChange={(value) => setNewNote({...newNote, category: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {getAllCategories().slice(1).map(category => (
                          <SelectItem key={category.value} value={category.value}>
                            {category.label}
                          </SelectItem>
                        ))}
                        <div className="border-t pt-2 mt-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="w-full justify-start text-blue-600 hover:text-blue-700"
                            onClick={() => setShowNewCategoryForm(true)}
                          >
                            <Plus className="w-4 h-4 mr-2" />
                            Criar Nova Categoria
                          </Button>
                        </div>
                      </SelectContent>
                    </Select>
                    
                    {/* Formulário para criar nova categoria */}
                    {showNewCategoryForm && (
                      <div className="flex gap-2 p-3 bg-blue-50 rounded-lg border">
                        <Input
                          placeholder="Nome da categoria"
                          value={newCategoryName}
                          onChange={(e) => setNewCategoryName(e.target.value)}
                          onKeyPress={(e) => e.key === 'Enter' && createNewCategory()}
                          className="flex-1"
                        />
                        <Button size="sm" onClick={createNewCategory}>
                          <Plus className="w-4 h-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={() => {
                            setShowNewCategoryForm(false)
                            setNewCategoryName('')
                          }}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div>
                <Label htmlFor="note-content">Conteúdo</Label>
                <Textarea
                  id="note-content"
                  value={newNote.content}
                  onChange={(e) => setNewNote({...newNote, content: e.target.value})}
                  placeholder="Digite o conteúdo da nota"
                  rows={4}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Cor da Nota</Label>
                  <div className="mt-3">
                    {/* Paleta de cores circular */}
                    <div className="relative w-48 h-48 mx-auto">
                      {colors.map((color, index) => {
                        const angle = (index * 360) / colors.length
                        const radius = 70
                        const x = Math.cos((angle * Math.PI) / 180) * radius
                        const y = Math.sin((angle * Math.PI) / 180) * radius
                        
                        return (
                          <button
                            key={color.name}
                            className={`absolute w-8 h-8 rounded-full border-3 transition-all duration-200 hover:scale-110 ${
                              newNote.color === color.name 
                                ? 'border-gray-800 scale-110 shadow-lg' 
                                : 'border-white shadow-md hover:shadow-lg'
                            }`}
                            style={{
                              backgroundColor: color.color,
                              left: `calc(50% + ${x}px - 16px)`,
                              top: `calc(50% + ${y}px - 16px)`,
                              transform: newNote.color === color.name ? 'scale(1.2)' : 'scale(1)'
                            }}
                            onClick={() => setNewNote({...newNote, color: color.name})}
                            title={color.name}
                          />
                        )
                      })}
                      
                      {/* Centro da paleta - cor selecionada */}
                      <div 
                        className="absolute w-12 h-12 rounded-full border-4 border-white shadow-lg"
                        style={{
                          backgroundColor: getNoteColor(newNote.color).color,
                          left: 'calc(50% - 24px)',
                          top: 'calc(50% - 24px)'
                        }}
                      >
                        <div className="w-full h-full rounded-full flex items-center justify-center">
                          <Palette className="w-5 h-5 text-gray-600" />
                        </div>
                      </div>
                    </div>
                    
                    {/* Nome da cor selecionada */}
                    <p className="text-center text-sm text-gray-600 mt-2 capitalize">
                      {newNote.color}
                    </p>
                  </div>
                </div>
                <div>
                  <Label htmlFor="note-priority">Prioridade</Label>
                  <Select value={newNote.priority} onValueChange={(value) => setNewNote({...newNote, priority: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="baixa">Baixa</SelectItem>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="alta">Alta</SelectItem>
                      <SelectItem value="urgente">Urgente</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Checkbox
                  id="alarm"
                  checked={newNote.alarm}
                  onCheckedChange={(checked) => setNewNote({...newNote, alarm: checked})}
                />
                <Label htmlFor="alarm" className="flex items-center">
                  <Bell className="w-4 h-4 mr-1" />
                  Adicionar lembrete
                </Label>
              </div>

              {newNote.alarm && (
                <div>
                  <Label htmlFor="alarm-time">Data e hora do lembrete</Label>
                  <Input
                    id="alarm-time"
                    type="datetime-local"
                    value={newNote.alarmTime}
                    onChange={(e) => setNewNote({...newNote, alarmTime: e.target.value})}
                  />
                </div>
              )}

              <div className="flex gap-2">
                <Button onClick={saveNote} className="flex-1">
                  <Save className="w-4 h-4 mr-2" />
                  {editingNote ? 'Salvar Alterações' : 'Criar Nota'}
                </Button>
                <Button variant="outline" onClick={resetForm}>
                  Cancelar
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Lista de notas */}
        {sortedNotes.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <StickyNote className="w-16 h-16 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold mb-2">
                {searchTerm || selectedCategory !== 'todas' ? 'Nenhuma nota encontrada' : 'Nenhuma nota criada ainda'}
              </h3>
              <p className="text-gray-600 mb-4">
                {searchTerm || selectedCategory !== 'todas' 
                  ? 'Tente ajustar os filtros de pesquisa'
                  : 'Comece criando sua primeira nota!'
                }
              </p>
              {!searchTerm && selectedCategory === 'todas' && (
                <Button onClick={() => setShowForm(true)} className="bg-pink-500 hover:bg-pink-600">
                  <Plus className="w-4 h-4 mr-2" />
                  Criar Primeira Nota
                </Button>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-8">
            {Object.entries(groupedNotes).map(([categoryValue, categoryNotes]) => (
              <div key={categoryValue} className="space-y-4">
                {/* Cabeçalho da categoria */}
                <div className="flex items-center gap-3 pb-2 border-b border-gray-200">
                  <div className="bg-gradient-to-r from-pink-500 to-purple-500 w-8 h-8 rounded-full flex items-center justify-center">
                    <Tag className="w-4 h-4 text-white" />
                  </div>
                  <h2 className="text-xl font-bold text-gray-800">
                    {getCategoryLabel(categoryValue)}
                  </h2>
                  <Badge variant="secondary" className="ml-auto">
                    {categoryNotes.length} {categoryNotes.length === 1 ? 'nota' : 'notas'}
                  </Badge>
                </div>
                
                {/* Notas da categoria */}
                <div className={viewMode === 'grid' 
                  ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4' 
                  : 'space-y-4'
                }>
                  {categoryNotes.map((note) => {
              const noteColor = getNoteColor(note.color)
              const categoryLabel = categories.find(c => c.value === note.category)?.label || note.category
              
              return (
                <Card 
                  key={note.id} 
                  className={`${noteColor.bg} ${noteColor.border} border-2 hover:shadow-lg transition-all duration-200 cursor-pointer group`}
                  onClick={() => editNote(note)}
                >
                  <CardContent className="p-4">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className={`font-semibold text-lg ${noteColor.text} line-clamp-2`}>
                        {note.title}
                      </h3>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        {note.alarm && !note.alarmTriggered && (
                          <Bell className="w-4 h-4 text-orange-500" />
                        )}
                        {note.priority === 'urgente' && (
                          <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                        )}
                      </div>
                    </div>
                    
                    <p className={`${noteColor.text} mb-3 line-clamp-3 text-sm`}>
                      {note.content}
                    </p>
                    
                    <div className="flex justify-between items-center text-xs">
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className="text-xs">
                          <Tag className="w-3 h-3 mr-1" />
                          {categoryLabel}
                        </Badge>
                        {note.alarm && note.alarmTime && !note.alarmTriggered && (
                          <Badge variant="outline" className="text-xs">
                            <Clock className="w-3 h-3 mr-1" />
                            {new Date(note.alarmTime).toLocaleDateString('pt-BR')}
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center mt-3 pt-2 border-t border-gray-200">
                      <span className={`text-xs ${noteColor.text} opacity-70`}>
                        {new Date(note.updatedAt).toLocaleDateString('pt-BR')}
                      </span>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation()
                            editNote(note)
                          }}
                          className="h-6 w-6 p-0"
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation()
                            duplicateNote(note)
                          }}
                          className="h-6 w-6 p-0"
                        >
                          <StickyNote className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation()
                            removeNote(note.id)
                          }}
                          className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Estatísticas */}
        {notes.length > 0 && (
          <Card className="mt-6">
            <CardContent className="p-4">
              <div className="flex justify-between items-center text-sm text-gray-600">
                <span>Total de notas: {notes.length}</span>
                <span>Filtradas: {sortedNotes.length}</span>
                <span>Com lembretes: {notes.filter(n => n.alarm && !n.alarmTriggered).length}</span>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

export default NotasAvancadas


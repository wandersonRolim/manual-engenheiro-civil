import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { ArrowLeft, Hammer, Calculator, Info, Search } from 'lucide-react'
const tracosData = [
  {
    id: 1,
    nome: 'Concreto 25 MPa',
    traco: '1:2:3',
    tipo: 'concreto',
    proporcao: {
      cimento: 1,
      areia: 2,
      brita: 3,
      agua: '~25 litros'
    },
    carrinhos: {
      cimento: '~0.7 carrinho (1 saco de 50kg)',
      areia: '~2 carrinhos',
      brita: '~3 carrinhos',
      agua: '~0.5 carrinho'
    },
    aplicacao: [
      'Lajes, vigas, pilares',
      'Pisos simples',
      'Obras residenciais'
    ],
    rendimento: '~1 m³ = 7 a 8 latas de cimento (50kg), 14 de areia, 21 de brita',
    fck: '~25 MPa',
    observacoes: [
      'Pode adicionar aditivo plastificante para melhorar trabalhabilidade',
      'Umidade dos agregados influencia na dosagem de água'
    ],
    cor: 'bg-blue-100'
  },
  {
    id: 9,
    nome: 'Concreto de 30 MPa',
    traco: '1:1.5:2.5',
    tipo: 'concreto',
    proporcao: {
      cimento: 1,
      areia: 1.5,
      brita: 2.5,
      agua: '~20 litros'
    },
    carrinhos: {
      cimento: '~0.7 carrinho (1 saco de 50kg)',
      areia: '~1.5 carrinhos',
      brita: '~2.5 carrinhos',
      agua: '~0.4 carrinho'
    },
    aplicacao: [
      'Estruturas de concreto armado',
      'Pisos de alta resistência',
      'Obras comerciais e industriais'
    ],
    rendimento: '~1 m³ = 9 a 10 latas de cimento (50kg), 13 de areia, 19 de brita',
    fck: '~30 MPa',
    observacoes: [
      'Requer controle rigoroso da dosagem de água',
      'Ideal para elementos que exigem maior resistência'
    ],
    cor: 'bg-blue-200'
  },
  {
    id: 10,
    nome: 'Concreto de 40 MPa',
    traco: '1:1:2',
    tipo: 'concreto',
    proporcao: {
      cimento: 1,
      areia: 1,
      brita: 2,
      agua: '~15 litros'
    },
    carrinhos: {
      cimento: '~0.7 carrinho (1 saco de 50kg)',
      areia: '~1 carrinho',
      brita: '~2 carrinhos',
      agua: '~0.3 carrinho'
    },
    aplicacao: [
      'Estruturas protendidas',
      'Pisos industriais de altíssimo tráfego',
      'Elementos pré-moldados'
    ],
    rendimento: '~1 m³ = 11 a 12 latas de cimento (50kg), 11 de areia, 16 de brita',
    fck: '~40 MPa',
    observacoes: [
      'Utilização de aditivos superplastificantes é comum',
      'Exige agregados de alta qualidade e controle tecnológico'
    ],
    cor: 'bg-blue-300'
  },
  {
    id: 2,
    nome: 'Concreto Magro',
    traco: '1:3:6',
    tipo: 'concreto',
    proporcao: {
      cimento: 1,
      areia: 3,
      brita: 6,
      agua: 'conforme necessário'
    },
    carrinhos: {
      cimento: '~0.7 carrinho (1 saco de 50kg)',
      areia: '~3 carrinhos',
      brita: '~6 carrinhos',
      agua: 'conforme necessário'
    },
    aplicacao: [
      'Lastros de fundação',
      'Calçadas',
      'Concreto de limpeza'
    ],
    rendimento: 'Custo reduzido',
    fck: '~7 a 10 MPa',
    observacoes: [
      'Custo reduzido',
      'Não indicado para elementos estruturais'
    ],
    cor: 'bg-gray-100'
  },
  {
    id: 3,
    nome: 'Argamassa de Assentamento',
    traco: '1:4',
    tipo: 'argamassa',
    proporcao: {
      cimento: 1,
      areia: 4,
      cal: '1/2 a 1 (opcional)',
      agua: 'conforme necessário'
    },
    carrinhos: {
      cimento: '~0.7 carrinho (1 saco de 50kg)',
      areia: '~4 carrinhos',
      cal: '1/2 a 1 carrinho (opcional)',
      agua: 'conforme necessário'
    },
    aplicacao: [
      'Assentamento de tijolos cerâmicos',
      'Assentamento de blocos de concreto'
    ],
    rendimento: '~18 a 20 litros de argamassa por m² de parede (com bloco 39x19x14)',
    fck: 'N/A',
    observacoes: [
      'Adição de cal melhora plasticidade e trabalhabilidade',
      'Aditivos prontos podem substituir a cal'
    ],
    cor: 'bg-orange-100'
  },
  {
    id: 4,
    nome: 'Argamassa de Reboco Interno',
    traco: '1:5 ou 1:6',
    tipo: 'argamassa',
    proporcao: {
      cimento: 1,
      areia: '5 a 6 (areia fina)',
      cal: '1 (opcional)',
      agua: 'conforme necessário'
    },
    carrinhos: {
      cimento: '~0.7 carrinho (1 saco de 50kg)',
      areia: '~5 a 6 carrinhos',
      cal: '~1 carrinho (opcional)',
      agua: 'conforme necessário'
    },
    aplicacao: [
      'Paredes internas',
      'Tetos'
    ],
    rendimento: '17 a 18 m² por saco de cimento (com 2 cm de espessura)',
    fck: 'N/A',
    observacoes: [
      'Espessura usual: 1,5 cm a 2 cm',
      'Cal evita fissuras',
      'Pode ser feita em duas camadas: emboço e reboco'
    ],
    cor: 'bg-green-100'
  },
  {
    id: 5,
    nome: 'Argamassa de Reboco Externo',
    traco: '1:3 ou 1:4',
    tipo: 'argamassa',
    proporcao: {
      cimento: 1,
      areia: '3 ou 4 (areia média)',
      cal: 'opcional',
      aditivo: 'impermeabilizante (opcional)'
    },
    carrinhos: {
      cimento: '~0.7 carrinho (1 saco de 50kg)',
      areia: '~3 a 4 carrinhos',
      cal: 'opcional',
      aditivo: 'impermeabilizante (opcional)'
    },
    aplicacao: [
      'Fachadas',
      'Muros'
    ],
    rendimento: 'Variável conforme espessura',
    fck: 'N/A',
    observacoes: [
      'Precisa maior resistência à chuva e sol',
      'Cal ou aditivos evitam retração e fissura'
    ],
    cor: 'bg-red-100'
  },
  {
    id: 6,
    nome: 'Traço de Contrapiso',
    traco: '1:4 a 1:6',
    tipo: 'argamassa',
    proporcao: {
      cimento: 1,
      areia: '4 a 6 (areia média)',
      agua: 'conforme necessário'
    },
    carrinhos: {
      cimento: '~0.7 carrinho (1 saco de 50kg)',
      areia: '~4 a 6 carrinhos',
      agua: 'conforme necessário'
    },
    aplicacao: [
      'Base para pisos cerâmicos',
      'Base para pisos vinílicos',
      'Base para laminados'
    ],
    rendimento: '~18 m² por saco de cimento com 3 cm de espessura',
    fck: 'N/A',
    observacoes: [
      'Espessura usual: 3 a 5 cm',
      'Adição de cal melhora aderência',
      'Pode ser sarrafeado com régua de alumínio'
    ],
    cor: 'bg-purple-100'
  },
  {
    id: 7,
    nome: 'Traço de Chapisco',
    traco: '1:3',
    tipo: 'argamassa',
    proporcao: {
      cimento: 1,
      areia: '3 (areia grossa)',
      agua: 'em abundância (mistura pastosa)'
    },
    carrinhos: {
      cimento: '~0.7 carrinho (1 saco de 50kg)',
      areia: '~3 carrinhos',
      agua: 'em abundância (mistura pastosa)'
    },
    aplicacao: [
      'Camada de aderência em alvenaria antes do reboco'
    ],
    rendimento: 'Cobertura de aderência',
    fck: 'N/A',
    observacoes: [
      'Pode usar aditivo colante (ex: Bianco)',
      'Aplicado com vassoura ou desempenadeira'
    ],
    cor: 'bg-yellow-100'
  },
  {
    id: 8,
    nome: 'Argamassa de Regularização',
    traco: '1:2',
    tipo: 'argamassa',
    proporcao: {
      cimento: 1,
      areia: '2 (areia fina)',
      agua: 'conforme necessário'
    },
    carrinhos: {
      cimento: '~0.7 carrinho (1 saco de 50kg)',
      areia: '~2 carrinhos',
      agua: 'conforme necessário'
    },
    aplicacao: [
      'Regularizar base antes de pisos vinílicos',
      'Base para porcelanato técnico',
      'Base para manta'
    ],
    rendimento: 'Espessura: 0,5 a 1 cm',
    fck: 'N/A',
    observacoes: [
      'Deve ser aplicada com desempenadeira metálica',
      'Pode receber adesivo ou primer para maior aderência'
    ],
    cor: 'bg-indigo-100'
  }
];

export default function Tracos({ setEtapa }) {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedType, setSelectedType] = useState('todos')
  const [selectedTraco, setSelectedTraco] = useState(null)

  const filteredTracos = tracosData.filter(traco => {
    const matchesSearch = traco.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         traco.traco.includes(searchTerm) ||
                         traco.aplicacao.some(app => app.toLowerCase().includes(searchTerm.toLowerCase()))
    
    const matchesType = selectedType === 'todos' || traco.tipo === selectedType
    
    return matchesSearch && matchesType
  })

  const TracoCard = ({ traco }) => (
    <Card 
      className={`cursor-pointer hover:shadow-lg transition-shadow ${traco.cor} border-l-4 ${
        traco.tipo === 'concreto' ? 'border-l-blue-500' : 'border-l-orange-500'
      }`}
      onClick={() => setSelectedTraco(traco)}
    >
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-bold text-gray-800">
            {traco.nome}
          </CardTitle>
          <Badge variant={traco.tipo === 'concreto' ? 'default' : 'secondary'}>
            {traco.tipo === 'concreto' ? 'Concreto' : 'Argamassa'}
          </Badge>
        </div>
        <CardDescription className="text-2xl font-bold text-gray-900">
          {traco.traco}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div>
            <h4 className="font-semibold text-sm text-gray-700">Aplicações:</h4>
            <ul className="text-sm text-gray-600">
              {traco.aplicacao.slice(0, 2).map((app, index) => (
                <li key={index}>• {app}</li>
              ))}
              {traco.aplicacao.length > 2 && (
                <li className="text-gray-500">• +{traco.aplicacao.length - 2} mais...</li>
              )}
            </ul>
          </div>
          {traco.fck !== 'N/A' && (
            <div>
              <span className="font-semibold text-sm text-gray-700">Fck: </span>
              <span className="text-sm text-gray-600">{traco.fck}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )

  const TracoDetail = ({ traco }) => (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button 
          variant="outline" 
          onClick={() => setSelectedTraco(null)}
          className="flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          Voltar
        </Button>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{traco.nome}</h2>
          <p className="text-lg text-gray-600">Traço: {traco.traco}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Proporção */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="w-5 h-5" />
              Proporção (em volume)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="font-medium">Cimento:</span>
                <span>{traco.proporcao.cimento} parte{traco.proporcao.cimento > 1 ? 's' : ''}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Areia:</span>
                <span>{traco.proporcao.areia} parte{typeof traco.proporcao.areia === 'number' && traco.proporcao.areia > 1 ? 's' : ''}</span>
              </div>
              {traco.proporcao.brita && (
                <div className="flex justify-between">
                  <span className="font-medium">Brita:</span>
                  <span>{traco.proporcao.brita} partes</span>
                </div>
              )}
              {traco.proporcao.cal && (
                <div className="flex justify-between">
                  <span className="font-medium">Cal:</span>
                  <span>{traco.proporcao.cal}</span>
                </div>
              )}
              {traco.proporcao.aditivo && (
                <div className="flex justify-between">
                  <span className="font-medium">Aditivo:</span>
                  <span>{traco.proporcao.aditivo}</span>
                </div>
              )}
              <div className="flex justify-between border-t pt-2">
                <span className="font-medium">Água:</span>
                <span>{traco.proporcao.agua}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Proporção em Carrinhos */}
        {traco.carrinhos && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="w-5 h-5" />
                Proporção (em carrinhos de mão)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {traco.carrinhos.cimento && (
                  <div className="flex justify-between">
                    <span className="font-medium">Cimento:</span>
                    <span>{traco.carrinhos.cimento}</span>
                  </div>
                )}
                {traco.carrinhos.areia && (
                  <div className="flex justify-between">
                    <span className="font-medium">Areia:</span>
                    <span>{traco.carrinhos.areia}</span>
                  </div>
                )}
                {traco.carrinhos.brita && (
                  <div className="flex justify-between">
                    <span className="font-medium">Brita:</span>
                    <span>{traco.carrinhos.brita}</span>
                  </div>
                )}
                {traco.carrinhos.cal && (
                  <div className="flex justify-between">
                    <span className="font-medium">Cal:</span>
                    <span>{traco.carrinhos.cal}</span>
                  </div>
                )}
                {traco.carrinhos.aditivo && (
                  <div className="flex justify-between">
                    <span className="font-medium">Aditivo:</span>
                    <span>{traco.carrinhos.aditivo}</span>
                  </div>
                )}
                {traco.carrinhos.agua && (
                  <div className="flex justify-between border-t pt-2">
                    <span className="font-medium">Água:</span>
                    <span>{traco.carrinhos.agua}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Aplicações */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Hammer className="w-5 h-5" />
              Aplicações
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {traco.aplicacao.map((app, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></span>
                  <span>{app}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Rendimento e Fck */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="w-5 h-5" />
              Rendimento e Resistência
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div>
                <span className="font-medium text-gray-700">Rendimento:</span>
                <p className="text-gray-600 mt-1">{traco.rendimento}</p>
              </div>
              {traco.fck !== 'N/A' && (
                <div>
                  <span className="font-medium text-gray-700">Fck estimado:</span>
                  <p className="text-gray-600 mt-1">{traco.fck}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Observações */}
        <Card>
          <CardHeader>
            <CardTitle>Observações Importantes</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {traco.observacoes.map((obs, index) => (
                <li key={index} className="flex items-start gap-2">
                  <span className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0"></span>
                  <span className="text-gray-600">{obs}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )

  if (selectedTraco) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-6xl mx-auto">
          <TracoDetail traco={selectedTraco} />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <Button 
            variant="outline" 
            onClick={() => setEtapa('home')}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar
          </Button>
          <div className="flex items-center gap-3">
            <Hammer className="w-8 h-8 text-orange-600" />
            <h1 className="text-3xl font-bold text-gray-900">Traços de Concreto e Argamassa</h1>
          </div>
        </div>

        {/* Filtros */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Label htmlFor="search">Buscar traços</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="search"
                    placeholder="Digite o nome, traço ou aplicação..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="type">Filtrar por tipo</Label>
                <select
                  id="type"
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-md"
                >
                  <option value="todos">Todos os tipos</option>
                  <option value="concreto">Concreto</option>
                  <option value="argamassa">Argamassa</option>
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lista de Traços */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTracos.map((traco) => (
            <TracoCard key={traco.id} traco={traco} />
          ))}
        </div>

        {filteredTracos.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">Nenhum traço encontrado com os filtros aplicados.</p>
          </div>
        )}
      </div>
    </div>
  )
}


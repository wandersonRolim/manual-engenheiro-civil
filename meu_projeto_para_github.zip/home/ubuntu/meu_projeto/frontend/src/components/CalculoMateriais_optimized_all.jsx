import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { ArrowLeft, Calculator, Building2, Package, Droplets, Hammer, Zap, MapPin, Paintbrush, Home, CheckCircle, FileText, ChevronDown, ChevronUp, Wrench, Palette, DoorOpen } from 'lucide-react'

// Seções reorganizadas e otimizadas
const secoes = [
  {
    id: 'alvenaria',
    nome: 'Alvenaria',
    icone: Building2,
    descricao: 'Tijolos/blocos, argamassa, cimento, areia'
  },
  {
    id: 'fundacao',
    nome: 'Fundação',
    icone: Hammer,
    descricao: 'Concreto, ferragem, escavação'
  },
  {
    id: 'estrutura',
    nome: 'Estrutura',
    icone: Building2,
    descricao: 'Pilares, vigas, lajes, ferragem'
  },
  {
    id: 'cobertura',
    nome: 'Cobertura',
    icone: Home,
    descricao: 'Telhas, madeiramento, calhas, rufos'
  },
  {
    id: 'instalacoes_hidraulicas',
    nome: 'Instalações Hidráulicas',
    icone: Droplets,
    descricao: 'Tubos, conexões, caixas d\'água'
  },
  {
    id: 'instalacoes_eletricas',
    nome: 'Instalações Elétricas',
    icone: Zap,
    descricao: 'Fios, cabos, disjuntores, tomadas'
  },
  {
    id: 'reboco',
    nome: 'Reboco',
    icone: Wrench,
    descricao: 'Argamassa, cimento, areia, cal'
  },
  {
    id: 'revestimento',
    nome: 'Revestimento',
    icone: Package,
    descricao: 'Pisos, azulejos, argamassa colante'
  },
  {
    id: 'pintura',
    nome: 'Pintura',
    icone: Palette,
    descricao: 'Tinta, primer, massa corrida'
  },
  {
    id: 'esquadrias',
    nome: 'Esquadrias',
    icone: DoorOpen,
    descricao: 'Portas, janelas, ferragens'
  }
]

// Componente de seção colapsável otimizada para mobile
const SecaoColapsavel = ({ titulo, icone: Icone, isOpen, onToggle, children }) => (
  <Card className="mb-2">
    <CardHeader 
      className="p-3 cursor-pointer" 
      onClick={onToggle}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icone className="h-4 w-4" />
          <CardTitle className="text-sm font-medium">{titulo}</CardTitle>
        </div>
        {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
      </div>
    </CardHeader>
    {isOpen && (
      <CardContent className="p-3 pt-0">
        {children}
      </CardContent>
    )}
  </Card>
)

// Componente de campo de entrada compacto
const CampoCompacto = ({ label, placeholder, value, onChange, type = "text", unit = "" }) => (
  <div className="space-y-1">
    <Label className="text-xs font-medium">{label}</Label>
    <div className="relative">
      <Input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className="h-8 text-sm pr-8"
      />
      {unit && (
        <span className="absolute right-2 top-1/2 transform -translate-y-1/2 text-xs text-gray-500">
          {unit}
        </span>
      )}
    </div>
  </div>
)

// Componente de resultado compacto
const ResultadoCompacto = ({ titulo, valor, unidade, destaque = false }) => (
  <div className={`p-2 rounded-lg ${destaque ? 'bg-blue-50 border border-blue-200' : 'bg-gray-50'}`}>
    <div className="text-xs text-gray-600">{titulo}</div>
    <div className={`text-sm font-semibold ${destaque ? 'text-blue-700' : 'text-gray-900'}`}>
      {valor} {unidade}
    </div>
  </div>
)

export default function CalculoMateriais({ onBack }) {
  const [secaoSelecionada, setSecaoSelecionada] = useState(null)
  const [secaoAberta, setSecaoAberta] = useState({})
  const [dados, setDados] = useState({})
  const [resultados, setResultados] = useState({})

  const toggleSecao = (secaoId) => {
    setSecaoAberta(prev => ({
      ...prev,
      [secaoId]: !prev[secaoId]
    }))
  }

  const atualizarDado = (campo, valor) => {
    setDados(prev => ({
      ...prev,
      [campo]: valor
    }))
  }

  const calcularAlvenaria = () => {
    const comprimento = parseFloat(dados.comprimento) || 0
    const altura = parseFloat(dados.altura) || 0
    const area = comprimento * altura
    
    // Cálculos básicos para alvenaria
    const tijolos = Math.ceil(area * 25) // 25 tijolos por m²
    const argamassa = area * 0.02 // 20L por m²
    const cimento = Math.ceil(argamassa * 7) // 7 sacos por m³
    const areia = argamassa * 4 // 4m³ de areia por m³ de argamassa
    
    setResultados({
      area: area.toFixed(2),
      tijolos,
      argamassa: argamassa.toFixed(2),
      cimento,
      areia: areia.toFixed(2)
    })
  }

  const calcularFundacao = () => {
    const comprimento = parseFloat(dados.comprimento_fund) || 0
    const largura = parseFloat(dados.largura_fund) || 0
    const profundidade = parseFloat(dados.profundidade_fund) || 0
    const volume = comprimento * largura * profundidade
    
    const concreto = volume * 1.05 // 5% de perda
    const cimento = Math.ceil(concreto * 7) // 7 sacos por m³
    const areia = concreto * 0.4 // 40% de areia
    const brita = concreto * 0.8 // 80% de brita
    const ferro = volume * 80 // 80kg por m³
    
    setResultados({
      volume: volume.toFixed(2),
      concreto: concreto.toFixed(2),
      cimento,
      areia: areia.toFixed(2),
      brita: brita.toFixed(2),
      ferro: ferro.toFixed(0)
    })
  }

  const calcularCobertura = () => {
    const area = parseFloat(dados.area_cobertura) || 0
    const inclinacao = parseFloat(dados.inclinacao) || 30
    const areaReal = area / Math.cos(inclinacao * Math.PI / 180)
    
    const telhas = Math.ceil(areaReal * 15) // 15 telhas por m²
    const ripas = Math.ceil(areaReal * 3) // 3m de ripa por m²
    const caibros = Math.ceil(areaReal * 1.5) // 1.5m de caibro por m²
    const pregos = Math.ceil(areaReal * 0.1) // 100g por m²
    
    setResultados({
      areaReal: areaReal.toFixed(2),
      telhas,
      ripas,
      caibros,
      pregos: pregos.toFixed(1)
    })
  }

  const calcularReboco = () => {
    const area = parseFloat(dados.area_reboco) || 0
    const espessura = parseFloat(dados.espessura_reboco) || 0.02
    const volume = area * espessura
    
    const argamassa = volume * 1.3 // 30% de perda
    const cimento = Math.ceil(argamassa * 6) // 6 sacos por m³
    const areia = argamassa * 3 // 3m³ de areia por m³
    const cal = Math.ceil(argamassa * 2) // 2 sacos por m³
    
    setResultados({
      area: area.toFixed(2),
      volume: volume.toFixed(3),
      argamassa: argamassa.toFixed(2),
      cimento,
      areia: areia.toFixed(2),
      cal
    })
  }

  const calcularPintura = () => {
    const area = parseFloat(dados.area_pintura) || 0
    const demaos = parseInt(dados.demaos) || 2
    
    const tinta = (area * demaos) / 12 // 12m² por litro
    const primer = area / 10 // 10m² por litro
    const massa = area * 0.5 // 0.5kg por m²
    
    setResultados({
      area: area.toFixed(2),
      tinta: tinta.toFixed(1),
      primer: primer.toFixed(1),
      massa: massa.toFixed(1)
    })
  }

  const renderFormularioAlvenaria = () => (
    <div className="space-y-3">
      <SecaoColapsavel
        titulo="Dimensões da Parede"
        icone={MapPin}
        isOpen={true}
        onToggle={() => {}}
      >
        <div className="grid grid-cols-2 gap-3">
          <CampoCompacto
            label="Comprimento"
            placeholder="5.00"
            value={dados.comprimento || ''}
            onChange={(e) => atualizarDado('comprimento', e.target.value)}
            unit="m"
          />
          <CampoCompacto
            label="Altura"
            placeholder="2.80"
            value={dados.altura || ''}
            onChange={(e) => atualizarDado('altura', e.target.value)}
            unit="m"
          />
        </div>
        {dados.comprimento && dados.altura && (
          <div className="mt-2 p-2 bg-blue-50 rounded text-sm">
            <strong>Área total: {((parseFloat(dados.comprimento) || 0) * (parseFloat(dados.altura) || 0)).toFixed(2)} m²</strong>
          </div>
        )}
      </SecaoColapsavel>

      <SecaoColapsavel
        titulo="Tipo de Material"
        icone={Package}
        isOpen={secaoAberta.material}
        onToggle={() => toggleSecao('material')}
      >
        <div className="space-y-2">
          <Label className="text-xs">Tipo de Tijolo</Label>
          <Select value={dados.tipoTijolo} onValueChange={(value) => atualizarDado('tipoTijolo', value)}>
            <SelectTrigger className="h-8">
              <SelectValue placeholder="Selecione o tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ceramico">Cerâmico 9x19x19</SelectItem>
              <SelectItem value="concreto">Concreto 14x19x39</SelectItem>
              <SelectItem value="solo_cimento">Solo-cimento</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </SecaoColapsavel>

      <Button 
        onClick={calcularAlvenaria} 
        className="w-full h-10"
        disabled={!dados.comprimento || !dados.altura}
      >
        <Calculator className="h-4 w-4 mr-2" />
        Calcular Materiais
      </Button>

      {resultados.area && (
        <div className="space-y-2">
          <h4 className="text-sm font-semibold">Resultados:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Área" valor={resultados.area} unidade="m²" destaque />
            <ResultadoCompacto titulo="Tijolos" valor={resultados.tijolos} unidade="un" />
            <ResultadoCompacto titulo="Argamassa" valor={resultados.argamassa} unidade="m³" />
            <ResultadoCompacto titulo="Cimento" valor={resultados.cimento} unidade="sacos" />
            <ResultadoCompacto titulo="Areia" valor={resultados.areia} unidade="m³" />
          </div>
        </div>
      )}
    </div>
  )

  const renderFormularioFundacao = () => (
    <div className="space-y-3">
      <SecaoColapsavel
        titulo="Dimensões da Fundação"
        icone={MapPin}
        isOpen={true}
        onToggle={() => {}}
      >
        <div className="grid grid-cols-2 gap-3">
          <CampoCompacto
            label="Comprimento"
            placeholder="10.00"
            value={dados.comprimento_fund || ''}
            onChange={(e) => atualizarDado('comprimento_fund', e.target.value)}
            unit="m"
          />
          <CampoCompacto
            label="Largura"
            placeholder="0.30"
            value={dados.largura_fund || ''}
            onChange={(e) => atualizarDado('largura_fund', e.target.value)}
            unit="m"
          />
          <CampoCompacto
            label="Profundidade"
            placeholder="0.80"
            value={dados.profundidade_fund || ''}
            onChange={(e) => atualizarDado('profundidade_fund', e.target.value)}
            unit="m"
          />
        </div>
      </SecaoColapsavel>

      <Button 
        onClick={calcularFundacao} 
        className="w-full h-10"
        disabled={!dados.comprimento_fund || !dados.largura_fund || !dados.profundidade_fund}
      >
        <Calculator className="h-4 w-4 mr-2" />
        Calcular Materiais
      </Button>

      {resultados.volume && (
        <div className="space-y-2">
          <h4 className="text-sm font-semibold">Resultados:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Volume" valor={resultados.volume} unidade="m³" destaque />
            <ResultadoCompacto titulo="Concreto" valor={resultados.concreto} unidade="m³" />
            <ResultadoCompacto titulo="Cimento" valor={resultados.cimento} unidade="sacos" />
            <ResultadoCompacto titulo="Areia" valor={resultados.areia} unidade="m³" />
            <ResultadoCompacto titulo="Brita" valor={resultados.brita} unidade="m³" />
            <ResultadoCompacto titulo="Ferro" valor={resultados.ferro} unidade="kg" />
          </div>
        </div>
      )}
    </div>
  )

  const renderFormularioCobertura = () => (
    <div className="space-y-3">
      <SecaoColapsavel
        titulo="Dimensões da Cobertura"
        icone={MapPin}
        isOpen={true}
        onToggle={() => {}}
      >
        <div className="grid grid-cols-2 gap-3">
          <CampoCompacto
            label="Área em Planta"
            placeholder="50.00"
            value={dados.area_cobertura || ''}
            onChange={(e) => atualizarDado('area_cobertura', e.target.value)}
            unit="m²"
          />
          <CampoCompacto
            label="Inclinação"
            placeholder="30"
            value={dados.inclinacao || ''}
            onChange={(e) => atualizarDado('inclinacao', e.target.value)}
            unit="°"
          />
        </div>
      </SecaoColapsavel>

      <Button 
        onClick={calcularCobertura} 
        className="w-full h-10"
        disabled={!dados.area_cobertura}
      >
        <Calculator className="h-4 w-4 mr-2" />
        Calcular Materiais
      </Button>

      {resultados.areaReal && (
        <div className="space-y-2">
          <h4 className="text-sm font-semibold">Resultados:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Área Real" valor={resultados.areaReal} unidade="m²" destaque />
            <ResultadoCompacto titulo="Telhas" valor={resultados.telhas} unidade="un" />
            <ResultadoCompacto titulo="Ripas" valor={resultados.ripas} unidade="m" />
            <ResultadoCompacto titulo="Caibros" valor={resultados.caibros} unidade="m" />
            <ResultadoCompacto titulo="Pregos" valor={resultados.pregos} unidade="kg" />
          </div>
        </div>
      )}
    </div>
  )

  const renderFormularioReboco = () => (
    <div className="space-y-3">
      <SecaoColapsavel
        titulo="Dimensões da Área"
        icone={MapPin}
        isOpen={true}
        onToggle={() => {}}
      >
        <div className="grid grid-cols-2 gap-3">
          <CampoCompacto
            label="Área Total"
            placeholder="100.00"
            value={dados.area_reboco || ''}
            onChange={(e) => atualizarDado('area_reboco', e.target.value)}
            unit="m²"
          />
          <CampoCompacto
            label="Espessura"
            placeholder="0.02"
            value={dados.espessura_reboco || ''}
            onChange={(e) => atualizarDado('espessura_reboco', e.target.value)}
            unit="m"
          />
        </div>
      </SecaoColapsavel>

      <SecaoColapsavel
        titulo="Tipo de Reboco"
        icone={Package}
        isOpen={secaoAberta.tipo_reboco}
        onToggle={() => toggleSecao('tipo_reboco')}
      >
        <div className="space-y-2">
          <Label className="text-xs">Localização</Label>
          <Select value={dados.localizacao_reboco} onValueChange={(value) => atualizarDado('localizacao_reboco', value)}>
            <SelectTrigger className="h-8">
              <SelectValue placeholder="Selecione" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="interno">Interno</SelectItem>
              <SelectItem value="externo">Externo</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </SecaoColapsavel>

      <Button 
        onClick={calcularReboco} 
        className="w-full h-10"
        disabled={!dados.area_reboco}
      >
        <Calculator className="h-4 w-4 mr-2" />
        Calcular Materiais
      </Button>

      {resultados.area && (
        <div className="space-y-2">
          <h4 className="text-sm font-semibold">Resultados:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Área" valor={resultados.area} unidade="m²" destaque />
            <ResultadoCompacto titulo="Volume" valor={resultados.volume} unidade="m³" />
            <ResultadoCompacto titulo="Argamassa" valor={resultados.argamassa} unidade="m³" />
            <ResultadoCompacto titulo="Cimento" valor={resultados.cimento} unidade="sacos" />
            <ResultadoCompacto titulo="Areia" valor={resultados.areia} unidade="m³" />
            <ResultadoCompacto titulo="Cal" valor={resultados.cal} unidade="sacos" />
          </div>
        </div>
      )}
    </div>
  )

  const renderFormularioPintura = () => (
    <div className="space-y-3">
      <SecaoColapsavel
        titulo="Dimensões da Área"
        icone={MapPin}
        isOpen={true}
        onToggle={() => {}}
      >
        <div className="grid grid-cols-2 gap-3">
          <CampoCompacto
            label="Área Total"
            placeholder="80.00"
            value={dados.area_pintura || ''}
            onChange={(e) => atualizarDado('area_pintura', e.target.value)}
            unit="m²"
          />
          <CampoCompacto
            label="Demãos"
            placeholder="2"
            value={dados.demaos || ''}
            onChange={(e) => atualizarDado('demaos', e.target.value)}
            unit="x"
          />
        </div>
      </SecaoColapsavel>

      <Button 
        onClick={calcularPintura} 
        className="w-full h-10"
        disabled={!dados.area_pintura}
      >
        <Calculator className="h-4 w-4 mr-2" />
        Calcular Materiais
      </Button>

      {resultados.area && (
        <div className="space-y-2">
          <h4 className="text-sm font-semibold">Resultados:</h4>
          <div className="grid grid-cols-2 gap-2">
            <ResultadoCompacto titulo="Área" valor={resultados.area} unidade="m²" destaque />
            <ResultadoCompacto titulo="Tinta" valor={resultados.tinta} unidade="L" />
            <ResultadoCompacto titulo="Primer" valor={resultados.primer} unidade="L" />
            <ResultadoCompacto titulo="Massa" valor={resultados.massa} unidade="kg" />
          </div>
        </div>
      )}
    </div>
  )

  const renderFormulario = () => {
    switch (secaoSelecionada) {
      case 'alvenaria':
        return renderFormularioAlvenaria()
      case 'fundacao':
        return renderFormularioFundacao()
      case 'cobertura':
        return renderFormularioCobertura()
      case 'reboco':
        return renderFormularioReboco()
      case 'pintura':
        return renderFormularioPintura()
      default:
        return (
          <div className="text-center py-8">
            <Calculator className="h-12 w-12 mx-auto text-gray-400 mb-4" />
            <p className="text-gray-500">Selecione uma etapa para calcular os materiais necessários.</p>
          </div>
        )
    }
  }

  if (secaoSelecionada) {
    const secao = secoes.find(s => s.id === secaoSelecionada)
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => setSecaoSelecionada(null)}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <div className="flex items-center gap-2">
            <secao.icone className="h-5 w-5 text-orange-600" />
            <h2 className="text-lg font-semibold">{secao.nome}</h2>
          </div>
        </div>
        
        {renderFormulario()}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex items-center gap-2">
          <Calculator className="h-5 w-5 text-orange-600" />
          <h2 className="text-lg font-semibold">Cálculo de Materiais</h2>
        </div>
      </div>

      <p className="text-sm text-gray-600">
        Escolha uma etapa da obra para calcular os materiais necessários.
      </p>

      <div className="grid gap-3">
        {secoes.map((secao) => {
          const Icone = secao.icone
          return (
            <Card 
              key={secao.id} 
              className="cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => setSecaoSelecionada(secao.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-orange-100 rounded-lg">
                    <Icone className="h-5 w-5 text-orange-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-medium text-sm">{secao.nome}</h3>
                    <p className="text-xs text-gray-500">{secao.descricao}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}


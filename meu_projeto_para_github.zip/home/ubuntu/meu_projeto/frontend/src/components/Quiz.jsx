import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { CheckCircle, XCircle, RotateCcw, Trophy, Brain, ArrowLeft, Home } from 'lucide-react';
import QuizSelection from './QuizSelection';
import { getQuizData, getQuizTitle } from '../data/quizData';

const Quiz = () => {
  const [selectedQuizType, setSelectedQuizType] = useState(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState('');
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [highestLevel, setHighestLevel] = useState(0);
  const [showCelebration, setShowCelebration] = useState(false);

  // Obter dados do quiz baseado no tipo selecionado
  const quizData = selectedQuizType ? getQuizData(selectedQuizType) : [];
  const quizTitle = selectedQuizType ? getQuizTitle(selectedQuizType) : '';
  const question = quizData[currentQuestion];
  const progress = quizData.length > 0 ? ((currentQuestion + 1) / quizData.length) * 100 : 0;

  useEffect(() => {
    // Recuperar o maior nível alcançado do localStorage para o tipo de quiz específico
    if (selectedQuizType) {
      const savedHighestLevel = localStorage.getItem(`quizHighestLevel_${selectedQuizType}`);
      if (savedHighestLevel) {
        setHighestLevel(parseInt(savedHighestLevel));
      } else {
        setHighestLevel(0);
      }
    }
  }, [selectedQuizType]);

  const handleAnswerSelect = (answer) => {
    setSelectedAnswer(answer);
  };

  const handleSubmit = () => {
    if (!selectedAnswer) return;

    const correct = selectedAnswer === question.answer;
    setIsCorrect(correct);
    setShowResult(true);

    if (correct) {
      setScore(score + 1);
      
      // Atualizar o maior nível alcançado
      if (currentQuestion + 1 > highestLevel) {
        setHighestLevel(currentQuestion + 1);
        localStorage.setItem(`quizHighestLevel_${selectedQuizType}`, (currentQuestion + 1).toString());
      }

      // Verificar se completou o quiz
      if (currentQuestion === quizData.length - 1) {
        setShowCelebration(true);
        setTimeout(() => {
          setGameOver(true);
        }, 2000);
      }
    } else {
      // Se errou, volta para o começo após 2 segundos
      setTimeout(() => {
        resetQuiz();
      }, 2000);
    }
  };

  const nextQuestion = () => {
    if (currentQuestion < quizData.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer('');
      setShowResult(false);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer('');
    setShowResult(false);
    setIsCorrect(false);
    setGameOver(false);
    setScore(0);
    setShowCelebration(false);
  };

  const handleSelectQuizType = (quizType) => {
    setSelectedQuizType(quizType);
    resetQuiz();
  };

  const handleBackToSelection = () => {
    setSelectedQuizType(null);
    resetQuiz();
  };

  const handleBackToHome = () => {
    // Recarregar a página para voltar à tela inicial
    window.location.href = '/';
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 1: return 'bg-green-500';
      case 2: return 'bg-yellow-500';
      case 3: return 'bg-orange-500';
      case 4: return 'bg-red-500';
      case 5: return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  const getDifficultyLabel = (difficulty) => {
    switch (difficulty) {
      case 1: return 'Básico';
      case 2: return 'Intermediário';
      case 3: return 'Avançado';
      case 4: return 'Especialista';
      case 5: return 'Mestre';
      default: return 'Desconhecido';
    }
  };

  // Mostrar tela de seleção se nenhum quiz foi selecionado
  if (!selectedQuizType) {
    return <QuizSelection onSelectQuizType={handleSelectQuizType} />;
  }

  // Verificar se há dados do quiz
  if (!question) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <Card className="w-full max-w-md mx-4 text-center">
          <CardContent className="p-8">
            <p className="text-xl text-gray-700 mb-4">
              Carregando quiz...
            </p>
            <Button onClick={handleBackToSelection}>
              Voltar à Seleção
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (showCelebration) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500 flex items-center justify-center">
        <Card className="w-full max-w-2xl mx-4 text-center">
          <CardContent className="p-8">
            <Trophy className="w-24 h-24 text-yellow-500 mx-auto mb-4 animate-bounce" />
            <h1 className="text-4xl font-bold text-yellow-600 mb-4">
              🎉 PARABÉNS! 🎉
            </h1>
            <p className="text-xl text-gray-700 mb-6">
              Você completou todas as 50 perguntas do {quizTitle}!
            </p>
            <p className="text-lg text-gray-600">
              Você é um verdadeiro mestre da engenharia!
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (gameOver) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-2xl">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-gray-800 mb-4">
              Quiz Finalizado!
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-center space-x-2">
                <Trophy className="w-8 h-8 text-yellow-500" />
                <span className="text-2xl font-bold text-gray-800">
                  Pontuação Final: {score}/50
                </span>
              </div>
              
              <div className="flex items-center justify-center space-x-2">
                <Brain className="w-6 h-6 text-purple-500" />
                <span className="text-lg text-gray-700">
                  Maior Nível Alcançado: {highestLevel}
                </span>
              </div>

              <div className="bg-gradient-to-r from-green-100 to-blue-100 p-4 rounded-lg">
                <p className="text-lg font-semibold text-gray-800 mb-2">
                  Resultado Impressionante!
                </p>
                <p className="text-gray-700">
                  Você demonstrou excelente conhecimento em Engenharia Civil.
                  Continue estudando para alcançar níveis ainda maiores!
                </p>
              </div>
            </div>

            <Button 
              onClick={resetQuiz}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg"
            >
              <RotateCcw className="w-5 h-5 mr-2" />
              Jogar Novamente
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header com informações do quiz */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-3xl font-bold text-gray-800 flex items-center">
              <Brain className="w-8 h-8 mr-3 text-blue-600" />
              {quizTitle}
            </h1>
            <div className="flex items-center space-x-2">
              <Button 
                onClick={handleBackToHome}
                variant="outline"
                className="flex items-center space-x-2"
              >
                <Home className="w-4 h-4" />
                <span>Início</span>
              </Button>
              <Button 
                onClick={handleBackToSelection}
                variant="outline"
                className="flex items-center space-x-2"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Voltar</span>
              </Button>
              <Button 
                onClick={resetQuiz}
                variant="outline"
                className="flex items-center space-x-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Reiniciar</span>
              </Button>
            </div>
          </div>
          
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="text-sm">
                Pergunta {currentQuestion + 1} de {quizData.length}
              </Badge>
              <Badge 
                className={`text-white ${getDifficultyColor(question.difficulty)}`}
              >
                {getDifficultyLabel(question.difficulty)}
              </Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">
                Maior Nível: {highestLevel}
              </span>
              <span className="text-sm text-gray-600">
                Pontuação: {score}
              </span>
            </div>
          </div>
          
          <Progress value={progress} className="h-2" />
        </div>

        {/* Card da pergunta */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-xl text-gray-800">
              {question.question}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {question.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(option)}
                  disabled={showResult}
                  className={`w-full p-4 text-left rounded-lg border-2 transition-all duration-200 ${
                    selectedAnswer === option
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                  } ${
                    showResult && option === question.answer
                      ? 'border-green-500 bg-green-50'
                      : showResult && selectedAnswer === option && option !== question.answer
                      ? 'border-red-500 bg-red-50'
                      : ''
                  } disabled:cursor-not-allowed`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-gray-800">{option}</span>
                    {showResult && option === question.answer && (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    )}
                    {showResult && selectedAnswer === option && option !== question.answer && (
                      <XCircle className="w-5 h-5 text-red-500" />
                    )}
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Resultado da resposta */}
        {showResult && (
          <Card className={`mb-6 ${isCorrect ? 'border-green-500' : 'border-red-500'}`}>
            <CardContent className="p-6">
              <div className="flex items-center space-x-3">
                {isCorrect ? (
                  <CheckCircle className="w-8 h-8 text-green-500" />
                ) : (
                  <XCircle className="w-8 h-8 text-red-500" />
                )}
                <div>
                  <h3 className={`text-xl font-bold ${isCorrect ? 'text-green-700' : 'text-red-700'}`}>
                    {isCorrect ? 'Correto!' : 'Incorreto!'}
                  </h3>
                  <p className="text-gray-700">
                    {isCorrect 
                      ? 'Parabéns! Você acertou e pode avançar para a próxima pergunta.'
                      : 'Que pena! Você errou e o quiz será reiniciado.'
                    }
                  </p>
                  {!isCorrect && (
                    <p className="text-sm text-gray-600 mt-2">
                      A resposta correta era: <strong>{question.answer}</strong>
                    </p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Botões de ação */}
        <div className="flex justify-center space-x-4">
          {!showResult ? (
            <Button 
              onClick={handleSubmit}
              disabled={!selectedAnswer}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg"
            >
              Confirmar Resposta
            </Button>
          ) : isCorrect && currentQuestion < quizData.length - 1 ? (
            <Button 
              onClick={nextQuestion}
              className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg"
            >
              Próxima Pergunta
            </Button>
          ) : null}
        </div>

        {/* Regras do quiz */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="text-lg text-gray-800">Regras do Quiz</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>• O quiz possui 50 perguntas de dificuldade crescente</li>
              <li>• Se você acertar, avança para a próxima pergunta</li>
              <li>• Se você errar, o quiz reinicia do começo</li>
              <li>• Seu maior nível alcançado é salvo automaticamente</li>
              <li>• Complete todas as 50 perguntas para se tornar um Mestre!</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Quiz;


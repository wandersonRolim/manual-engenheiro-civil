import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Checkbox } from '@/components/ui/checkbox.jsx'
import { ArrowLeft, Calculator, FileText, Clock, DollarSign, BookOpen, StickyNote, Ruler, Calendar, AlertCircle, Search, Zap, Building, Hammer, Shield, Droplets, Accessibility, Square, Triangle, Circle, Hexagon, Shapes, Sigma, Building2, LogOut, Settings } from 'lucide-react'
import CronogramaOrcamento from './components/CronogramaOrcamentoModificado.jsx'
import Tracos from './components/Tracos.jsx'
import Quiz from './components/Quiz.jsx'
import CalculoMateriais from './components/CalculoMateriais.jsx'
import NotasAvancadas from './components/NotasAvancadas.jsx'
import Login from './components/Login.jsx'
import Register from './components/Register.jsx'
import AdminPanel from './components/AdminPanel.jsx'
import './App.css'

// Importar imagens de fundo principais
import normasBg from './assets/normas-bg.webp'
import calculoBg from './assets/calculo-bg.jpg'
import cronogramaBg from './assets/cronograma-bg.png'
import orcamentoBg from './assets/orcamento-bg.jpg'
import glossarioBg from './assets/glossario-bg.jpg'
import notasBg from './assets/notas-bg.jpg'
import calculadoraBg from './assets/calculadora-bg.png'

// Importar imagens das categorias de normas
import normasEletricasBg from './assets/normas-eletricas.png'
import normasArquitetonicasBg from './assets/normas-arquitetonicas.png'
import normasEstruturaisBg from './assets/normas-estruturais.png'
import normasSegurancaBg from './assets/normas-seguranca.png'
import normasHidraulicasBg from './assets/normas-hidraulicas.jpg'
import normasAcessibilidadeBg from './assets/normas-acessibilidade.png'

// Importar imagens dos formatos de terreno
import terrenoRetangularBg from './assets/terreno-retangular.jpg'
import terrenoQuadradoBg from './assets/terreno-quadrado.jpg'
import terrenoTriangularBg from './assets/terreno-triangular.jpg'
import terrenoCircularBg from './assets/terreno-circular.jpg'
import terrenoIrregularBg from './assets/terreno-irregular.jpg'

function App() {
  const [currentView, setCurrentView] = useState('home')
  const [searchTerm, setSearchTerm] = useState('')
  const [terrainType, setTerrainType] = useState('')
  const [dimensions, setDimensions] = useState({ length: '', width: '', height: '', side1: '', side2: '', side3: '', radius: '' })
  const [includeHeight, setIncludeHeight] = useState(false)
  const [terrainResults, setTerrainResults] = useState(null)
  
  // Estados de autenticação
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [user, setUser] = useState(null)
  const [token, setToken] = useState(null)
  const [authView, setAuthView] = useState('login') // 'login' ou 'register'
  
  // Estados da calculadora científica
  const [display, setDisplay] = useState('0')
  const [previousValue, setPreviousValue] = useState(null)
  const [operation, setOperation] = useState(null)
  const [waitingForOperand, setWaitingForOperand] = useState(false)
  const [memory, setMemory] = useState(0)
  const [angleMode, setAngleMode] = useState('DEG') // DEG, RAD, GRAD

  // Função para calcular área, perímetro e volume do terreno
  const calculateTerrain = () => {
    const { length, width, height, side1, side2, side3, radius } = dimensions
    const l = parseFloat(length) || 0
    const w = parseFloat(width) || 0
    const h = parseFloat(height) || 0
    const s1 = parseFloat(side1) || 0
    const s2 = parseFloat(side2) || 0
    const s3 = parseFloat(side3) || 0
    const r = parseFloat(radius) || 0

    let area = 0
    let perimeter = 0
    let volume = 0

    switch (terrainType) {
      case 'retangular':
        area = l * w
        perimeter = 2 * (l + w)
        volume = includeHeight ? area * h : 0
        break
      case 'quadrado':
        area = l * l
        perimeter = 4 * l
        volume = includeHeight ? area * h : 0
        break
      case 'triangular': {
        // Usando fórmula de Heron para área
        const s = (s1 + s2 + s3) / 2
        area = Math.sqrt(s * (s - s1) * (s - s2) * (s - s3))
        perimeter = s1 + s2 + s3
        volume = includeHeight ? area * h : 0
        break
      }
      case 'circular':
        area = Math.PI * r * r
        perimeter = 2 * Math.PI * r
        volume = includeHeight ? area * h : 0
        break
      case 'irregular':
        // Para terrenos irregulares, usar comprimento e largura aproximados
        area = l * w
        perimeter = 2 * (l + w)
        volume = includeHeight ? area * h : 0
        break
    }

    setTerrainResults({
      area: area.toFixed(2),
      perimeter: perimeter.toFixed(2),
      volume: volume.toFixed(2)
    })
  }

  // Verificar autenticação ao carregar a página
  useEffect(() => {
    const savedToken = localStorage.getItem('token')
    const savedUser = localStorage.getItem('user')
    
    if (savedToken && savedUser) {
      setToken(savedToken)
      setUser(JSON.parse(savedUser))
      setIsAuthenticated(true)
    }
  }, [])

  // Funções de autenticação
  const handleLogin = (userData, userToken) => {
    setUser(userData)
    setToken(userToken)
    setIsAuthenticated(true)
  }

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    setUser(null)
    setToken(null)
    setIsAuthenticated(false)
    setCurrentView('home')
  }

  // Funções da calculadora científica
  const inputNumber = (num) => {
    if (waitingForOperand) {
      setDisplay(String(num))
      setWaitingForOperand(false)
    } else {
      setDisplay(display === '0' ? String(num) : display + num)
    }
  }

  const inputDecimal = () => {
    if (waitingForOperand) {
      setDisplay('0.')
      setWaitingForOperand(false)
    } else if (display.indexOf('.') === -1) {
      setDisplay(display + '.')
    }
  }

  const clear = () => {
    setDisplay('0')
    setPreviousValue(null)
    setOperation(null)
    setWaitingForOperand(false)
  }

  const performOperation = (nextOperation) => {
    const inputValue = parseFloat(display)

    if (previousValue === null) {
      setPreviousValue(inputValue)
    } else if (operation) {
      const currentValue = previousValue || 0
      const newValue = calculate(currentValue, inputValue, operation)

      setDisplay(String(newValue))
      setPreviousValue(newValue)
    }

    setWaitingForOperand(true)
    setOperation(nextOperation)
  }

  const calculate = (firstValue, secondValue, operation) => {
    switch (operation) {
      case '+':
        return firstValue + secondValue
      case '-':
        return firstValue - secondValue
      case '×':
        return firstValue * secondValue
      case '÷':
        return secondValue !== 0 ? firstValue / secondValue : 0
      case '^':
        return Math.pow(firstValue, secondValue)
      default:
        return secondValue
    }
  }

  const performScientificFunction = (func) => {
    const value = parseFloat(display)
    let result = 0

    // Converter para radianos se necessário
    const toRadians = (angle) => {
      if (angleMode === 'DEG') return angle * Math.PI / 180
      if (angleMode === 'GRAD') return angle * Math.PI / 200
      return angle // RAD
    }

    const fromRadians = (radians) => {
      if (angleMode === 'DEG') return radians * 180 / Math.PI
      if (angleMode === 'GRAD') return radians * 200 / Math.PI
      return radians // RAD
    }

    switch (func) {
      case 'sin':
        result = Math.sin(toRadians(value))
        break
      case 'cos':
        result = Math.cos(toRadians(value))
        break
      case 'tan':
        result = Math.tan(toRadians(value))
        break
      case 'asin':
        result = fromRadians(Math.asin(value))
        break
      case 'acos':
        result = fromRadians(Math.acos(value))
        break
      case 'atan':
        result = fromRadians(Math.atan(value))
        break
      case 'log':
        result = Math.log10(value)
        break
      case 'ln':
        result = Math.log(value)
        break
      case 'sqrt':
        result = Math.sqrt(value)
        break
      case 'x²':
        result = value * value
        break
      case 'x³':
        result = value * value * value
        break
      case '1/x':
        result = value !== 0 ? 1 / value : 0
        break
      case 'e^x':
        result = Math.exp(value)
        break
      case '10^x':
        result = Math.pow(10, value)
        break
      case 'π':
        result = Math.PI
        break
      case 'e':
        result = Math.E
        break
      case '!':
        result = factorial(value)
        break
      case '%':
        result = value / 100
        break
      case '±':
        result = -value
        break
      default:
        return
    }

    setDisplay(String(result))
    setWaitingForOperand(true)
  }

  const factorial = (n) => {
    if (n < 0) return 0
    if (n === 0 || n === 1) return 1
    let result = 1
    for (let i = 2; i <= n; i++) {
      result *= i
    }
    return result
  }

  const memoryOperation = (op) => {
    const value = parseFloat(display)
    switch (op) {
      case 'MC':
        setMemory(0)
        break
      case 'MR':
        setDisplay(String(memory))
        setWaitingForOperand(true)
        break
      case 'M+':
        setMemory(memory + value)
        break
      case 'M-':
        setMemory(memory - value)
        break
      case 'MS':
        setMemory(value)
        break
    }
  }

  // Categorias de normas técnicas
  const categoriasNormas = [
    {
      id: 'eletricas',
      titulo: 'Normas Elétricas',
      descricao: 'Instalações e segurança elétrica',
      icone: Zap,
      cor: 'bg-yellow-500',
      bgImage: normasEletricasBg,
      normas: [
        { codigo: 'NBR 5410', titulo: 'Instalações elétricas de baixa tensão', ano: '2004' },
        { codigo: 'NBR 5419', titulo: 'Proteção de estruturas contra descargas atmosféricas', ano: '2015' },
        { codigo: 'NBR 14039', titulo: 'Instalações elétricas de média tensão', ano: '2005' },
        { codigo: 'NR-10', titulo: 'Segurança em instalações e serviços em eletricidade', ano: '2019' }
      ]
    },
    {
      id: 'arquitetonicas',
      titulo: 'Normas Arquitetônicas',
      descricao: 'Projeto e construção',
      icone: Building,
      cor: 'bg-blue-500',
      bgImage: normasArquitetonicasBg,
      normas: [
        { codigo: 'NBR 15575', titulo: 'Edificações habitacionais — Desempenho', ano: '2013' },
        { codigo: 'NBR 13531', titulo: 'Elaboração de projetos de edificações', ano: '1995' },
        { codigo: 'NBR 6492', titulo: 'Representação de projetos de arquitetura', ano: '1994' },
        { codigo: 'NBR 15220', titulo: 'Desempenho térmico de edificações', ano: '2005' }
      ]
    },
    {
      id: 'estruturais',
      titulo: 'Normas Estruturais',
      descricao: 'Concreto, aço e fundações',
      icone: Hammer,
      cor: 'bg-gray-600',
      bgImage: normasEstruturaisBg,
      normas: [
        { codigo: 'NBR 6118', titulo: 'Projeto de estruturas de concreto', ano: '2014' },
        { codigo: 'NBR 8800', titulo: 'Projeto de estruturas de aço e de estruturas mistas', ano: '2008' },
        { codigo: 'NBR 6122', titulo: 'Projeto e execução de fundações', ano: '2019' },
        { codigo: 'NBR 6120', titulo: 'Cargas para o cálculo de estruturas de edificações', ano: '2019' }
      ]
    },
    {
      id: 'seguranca',
      titulo: 'Normas de Segurança',
      descricao: 'Segurança do trabalho',
      icone: Shield,
      cor: 'bg-red-500',
      bgImage: normasSegurancaBg,
      normas: [
        { codigo: 'NR-18', titulo: 'Condições e meio ambiente de trabalho na indústria da construção', ano: '2020' },
        { codigo: 'NR-35', titulo: 'Trabalho em altura', ano: '2012' },
        { codigo: 'NR-06', titulo: 'Equipamento de proteção individual - EPI', ano: '2018' },
        { codigo: 'NR-12', titulo: 'Segurança no trabalho em máquinas e equipamentos', ano: '2019' }
      ]
    },
    {
      id: 'hidraulicas',
      titulo: 'Normas Hidráulicas',
      descricao: 'Instalações hidrossanitárias',
      icone: Droplets,
      cor: 'bg-blue-400',
      bgImage: normasHidraulicasBg,
      normas: [
        { codigo: 'NBR 5626', titulo: 'Instalação predial de água fria', ano: '1998' },
        { codigo: 'NBR 7229', titulo: 'Projeto, construção e operação de sistemas de tanques sépticos', ano: '1993' },
        { codigo: 'NBR 8160', titulo: 'Sistemas prediais de esgoto sanitário', ano: '1999' },
        { codigo: 'NBR 10844', titulo: 'Instalações prediais de águas pluviais', ano: '1989' }
      ]
    },
    {
      id: 'acessibilidade',
      titulo: 'Normas de Acessibilidade',
      descricao: 'Inclusão e mobilidade',
      icone: Accessibility,
      cor: 'bg-green-500',
      bgImage: normasAcessibilidadeBg,
      normas: [
        { codigo: 'NBR 9050', titulo: 'Acessibilidade a edificações, mobiliário, espaços e equipamentos urbanos', ano: '2020' },
        { codigo: 'NBR 14020', titulo: 'Acessibilidade a pessoa portadora de deficiência — Trem de longo percurso', ano: '1997' },
        { codigo: 'NBR 14021', titulo: 'Transporte — Acessibilidade no sistema de trem urbano ou metropolitano', ano: '2005' },
        { codigo: 'NBR 15599', titulo: 'Acessibilidade — Comunicação na prestação de serviços', ano: '2008' }
      ]
    }
  ]

  // Formatos de terreno para cálculo
  const formatosTerreno = [
    {
      id: 'retangular',
      titulo: 'Retangular',
      descricao: 'Comprimento × Largura',
      icone: Square,
      cor: 'bg-blue-500',
      bgImage: terrenoRetangularBg,
      campos: ['length', 'width', 'height']
    },
    {
      id: 'quadrado',
      titulo: 'Quadrado',
      descricao: 'Lado × Lado',
      icone: Square,
      cor: 'bg-green-500',
      bgImage: terrenoQuadradoBg,
      campos: ['length', 'height']
    },
    {
      id: 'triangular',
      titulo: 'Triangular',
      descricao: 'Três lados',
      icone: Triangle,
      cor: 'bg-orange-500',
      bgImage: terrenoTriangularBg,
      campos: ['side1', 'side2', 'side3', 'height']
    },
    {
      id: 'circular',
      titulo: 'Circular',
      descricao: 'Raio',
      icone: Circle,
      cor: 'bg-purple-500',
      bgImage: terrenoCircularBg,
      campos: ['radius', 'height']
    },
    {
      id: 'irregular',
      titulo: 'Irregular',
      descricao: 'Aproximação retangular',
      icone: Shapes,
      cor: 'bg-gray-500',
      bgImage: terrenoIrregularBg,
      campos: ['length', 'width', 'height']
    }
  ]

  // Glossário de termos técnicos
  const glossario = [
    { termo: 'Concreto Armado', definicao: 'Material composto por concreto e armadura de aço, trabalhando em conjunto para resistir aos esforços.' },
    { termo: 'Fundação', definicao: 'Elemento estrutural que transmite as cargas da estrutura para o solo.' },
    { termo: 'Viga', definicao: 'Elemento estrutural horizontal que suporta cargas e as transmite para os pilares.' },
    { termo: 'Pilar', definicao: 'Elemento estrutural vertical que suporta cargas e as transmite para as fundações.' },
    { termo: 'Laje', definicao: 'Elemento estrutural plano, geralmente horizontal, que suporta cargas e as distribui.' },
    { termo: 'Armadura', definicao: 'Conjunto de barras de aço dispostas no interior do concreto para absorver esforços de tração.' }
  ]

  // Funcionalidades do aplicativo
  const funcionalidades = [
    {
      id: 'normas',
      titulo: 'Normas Técnicas',
      descricao: 'NBR e regulamentações',
      icone: FileText,
      cor: 'bg-blue-500',
      bgImage: normasBg
    },
    {
      id: 'calculo',
      titulo: 'Cálculo Rápido',
      descricao: 'Área, perímetro e volume',
      icone: Calculator,
      cor: 'bg-green-500',
      bgImage: calculoBg
    },
    {
      id: 'calculadora',
      titulo: 'Calculadora Científica',
      descricao: 'Funções matemáticas avançadas',
      icone: Sigma,
      cor: 'bg-indigo-500',
      bgImage: calculadoraBg
    },
    {
      id: 'quiz',
      titulo: 'Quiz de Engenharia',
      descricao: '50 perguntas de dificuldade crescente',
      icone: BookOpen,
      cor: 'bg-purple-600',
      bgImage: glossarioBg
    },
    {
      id: 'cronograma',
      titulo: 'Cronograma',
      descricao: 'Planejamento de obras',
      icone: Calendar,
      cor: 'bg-orange-500',
      bgImage: cronogramaBg
    },
    {
      id: 'tracos',
      titulo: 'Traços',
      descricao: 'Concreto e argamassa',
      icone: Hammer,
      cor: 'bg-amber-500',
      bgImage: calculoBg
    },
    {
      id: 'materiais',
      titulo: 'Cálculo de Materiais',
      descricao: 'Materiais para diversas etapas',
      icone: Building2,
      cor: 'bg-orange-500',
      bgImage: calculoBg
    },
    {
      id: 'valor',
      titulo: 'Cálculo de Valor',
      descricao: 'Orçamentos e custos',
      icone: DollarSign,
      cor: 'bg-purple-500',
      bgImage: orcamentoBg
    },
    {
      id: 'glossario',
      titulo: 'Glossário',
      descricao: 'Termos técnicos',
      icone: BookOpen,
      cor: 'bg-teal-500',
      bgImage: glossarioBg
    },
    {
      id: 'notas',
      titulo: 'Notas',
      descricao: 'Anotações e lembretes',
      icone: StickyNote,
      cor: 'bg-pink-500',
      bgImage: notasBg
    }
  ]

  // Filtrar funcionalidades baseado na pesquisa
  const funcionalidadesFiltradas = funcionalidades.filter(func =>
    func.titulo.toLowerCase().includes(searchTerm.toLowerCase()) ||
    func.descricao.toLowerCase().includes(searchTerm.toLowerCase())
  )

  // Componente para renderizar figura geométrica
  const FiguraGeometrica = ({ tipo, dimensoes }) => {
    const { length, width, side1, side2, side3, radius } = dimensoes
    
    const renderFigura = () => {
      switch (tipo) {
        case 'retangular':
        case 'irregular':
          return (
            <div className="relative">
              <svg width="300" height="200" viewBox="0 0 300 200" className="border-2 border-gray-400">
                <rect x="50" y="50" width="200" height="100" fill="none" stroke="#2563eb" strokeWidth="2" />
                {/* Dimensões */}
                <text x="150" y="40" textAnchor="middle" className="text-sm font-semibold fill-blue-600">
                  {length || 'L'} m
                </text>
                <text x="30" y="105" textAnchor="middle" className="text-sm font-semibold fill-blue-600" transform="rotate(-90 30 105)">
                  {width || 'W'} m
                </text>
              </svg>
            </div>
          )
        case 'quadrado':
          return (
            <div className="relative">
              <svg width="300" height="200" viewBox="0 0 300 200" className="border-2 border-gray-400">
                <rect x="75" y="50" width="150" height="150" fill="none" stroke="#16a34a" strokeWidth="2" />
                {/* Dimensões */}
                <text x="150" y="40" textAnchor="middle" className="text-sm font-semibold fill-green-600">
                  {length || 'L'} m
                </text>
              </svg>
            </div>
          )
        case 'triangular':
          return (
            <div className="relative">
              <svg width="300" height="200" viewBox="0 0 300 200" className="border-2 border-gray-400">
                <polygon points="150,30 50,170 250,170" fill="none" stroke="#ea580c" strokeWidth="2" />
                {/* Dimensões */}
                <text x="100" y="110" textAnchor="middle" className="text-sm font-semibold fill-orange-600" transform="rotate(-60 100 110)">
                  {side1 || 'A'} m
                </text>
                <text x="200" y="110" textAnchor="middle" className="text-sm font-semibold fill-orange-600" transform="rotate(60 200 110)">
                  {side2 || 'B'} m
                </text>
                <text x="150" y="185" textAnchor="middle" className="text-sm font-semibold fill-orange-600">
                  {side3 || 'C'} m
                </text>
              </svg>
            </div>
          )
        case 'circular':
          return (
            <div className="relative">
              <svg width="300" height="200" viewBox="0 0 300 200" className="border-2 border-gray-400">
                <circle cx="150" cy="100" r="75" fill="none" stroke="#9333ea" strokeWidth="2" />
                <line x1="150" y1="100" x2="225" y2="100" stroke="#9333ea" strokeWidth="1" strokeDasharray="5,5" />
                {/* Dimensões */}
                <text x="187" y="95" textAnchor="middle" className="text-sm font-semibold fill-purple-600">
                  r = {radius || 'R'} m
                </text>
              </svg>
            </div>
          )
        default:
          return null
      }
    }

    return (
      <div className="flex justify-center items-center p-4 bg-gray-50 rounded-lg">
        {renderFigura()}
      </div>
    )
  }

  // Componente da calculadora científica
  const CalculadoraCientifica = () => {
    return (
      <div className="max-w-md mx-auto">
        <Card className="bg-gradient-to-br from-slate-900 to-slate-800 border-slate-700 shadow-2xl">
          <CardHeader className="pb-4">
            <div className="flex justify-between items-center">
              <CardTitle className="text-white text-xl font-bold">Calculadora Científica</CardTitle>
              <div className="flex gap-2">
                <Button
                  variant={angleMode === 'DEG' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setAngleMode('DEG')}
                  className={angleMode === 'DEG' ? 'bg-blue-600 hover:bg-blue-700' : 'border-slate-600 text-slate-300 hover:bg-slate-700'}
                >
                  DEG
                </Button>
                <Button
                  variant={angleMode === 'RAD' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setAngleMode('RAD')}
                  className={angleMode === 'RAD' ? 'bg-blue-600 hover:bg-blue-700' : 'border-slate-600 text-slate-300 hover:bg-slate-700'}
                >
                  RAD
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Display */}
            <div className="bg-black text-green-400 p-6 rounded-lg text-right text-2xl font-mono min-h-[80px] flex items-center justify-end border-2 border-slate-600 shadow-inner">
              {display}
            </div>

            {/* Botões da calculadora */}
            <div className="grid grid-cols-5 gap-2">
              {/* Primeira linha - Funções de memória e limpeza */}
              <Button variant="outline" size="sm" onClick={() => memoryOperation('MC')} className="bg-slate-700 border-slate-600 text-slate-200 hover:bg-slate-600 font-semibold">MC</Button>
              <Button variant="outline" size="sm" onClick={() => memoryOperation('MR')} className="bg-slate-700 border-slate-600 text-slate-200 hover:bg-slate-600 font-semibold">MR</Button>
              <Button variant="outline" size="sm" onClick={() => memoryOperation('M+')} className="bg-slate-700 border-slate-600 text-slate-200 hover:bg-slate-600 font-semibold">M+</Button>
              <Button variant="outline" size="sm" onClick={() => memoryOperation('M-')} className="bg-slate-700 border-slate-600 text-slate-200 hover:bg-slate-600 font-semibold">M-</Button>
              <Button variant="destructive" size="sm" onClick={clear} className="bg-red-600 hover:bg-red-700 font-bold">C</Button>

              {/* Segunda linha - Funções científicas */}
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('sin')} className="bg-blue-600 border-blue-500 text-white hover:bg-blue-700 font-semibold">sin</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('cos')} className="bg-blue-600 border-blue-500 text-white hover:bg-blue-700 font-semibold">cos</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('tan')} className="bg-blue-600 border-blue-500 text-white hover:bg-blue-700 font-semibold">tan</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('log')} className="bg-purple-600 border-purple-500 text-white hover:bg-purple-700 font-semibold">log</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('ln')} className="bg-purple-600 border-purple-500 text-white hover:bg-purple-700 font-semibold">ln</Button>

              {/* Terceira linha - Mais funções científicas */}
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('asin')} className="bg-blue-500 border-blue-400 text-white hover:bg-blue-600 font-semibold">sin⁻¹</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('acos')} className="bg-blue-500 border-blue-400 text-white hover:bg-blue-600 font-semibold">cos⁻¹</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('atan')} className="bg-blue-500 border-blue-400 text-white hover:bg-blue-600 font-semibold">tan⁻¹</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('e^x')} className="bg-green-600 border-green-500 text-white hover:bg-green-700 font-semibold">eˣ</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('10^x')} className="bg-green-600 border-green-500 text-white hover:bg-green-700 font-semibold">10ˣ</Button>

              {/* Quarta linha - Potências e raízes */}
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('x²')} className="bg-orange-600 border-orange-500 text-white hover:bg-orange-700 font-semibold">x²</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('x³')} className="bg-orange-600 border-orange-500 text-white hover:bg-orange-700 font-semibold">x³</Button>
              <Button variant="outline" size="sm" onClick={() => performOperation('^')} className="bg-orange-600 border-orange-500 text-white hover:bg-orange-700 font-semibold">xʸ</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('sqrt')} className="bg-teal-600 border-teal-500 text-white hover:bg-teal-700 font-semibold">√</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('1/x')} className="bg-teal-600 border-teal-500 text-white hover:bg-teal-700 font-semibold">1/x</Button>

              {/* Quinta linha - Constantes e operações */}
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('π')} className="bg-indigo-600 border-indigo-500 text-white hover:bg-indigo-700 font-semibold">π</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('e')} className="bg-indigo-600 border-indigo-500 text-white hover:bg-indigo-700 font-semibold">e</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('!')} className="bg-yellow-600 border-yellow-500 text-white hover:bg-yellow-700 font-semibold">n!</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('%')} className="bg-yellow-600 border-yellow-500 text-white hover:bg-yellow-700 font-semibold">%</Button>
              <Button variant="outline" size="sm" onClick={() => performScientificFunction('±')} className="bg-gray-600 border-gray-500 text-white hover:bg-gray-700 font-semibold">±</Button>

              {/* Sexta linha - Números e operações básicas */}
              <Button variant="outline" onClick={() => inputNumber(7)} className="bg-slate-600 border-slate-500 text-white hover:bg-slate-500 font-bold text-lg">7</Button>
              <Button variant="outline" onClick={() => inputNumber(8)} className="bg-slate-600 border-slate-500 text-white hover:bg-slate-500 font-bold text-lg">8</Button>
              <Button variant="outline" onClick={() => inputNumber(9)} className="bg-slate-600 border-slate-500 text-white hover:bg-slate-500 font-bold text-lg">9</Button>
              <Button variant="outline" onClick={() => performOperation('÷')} className="bg-amber-600 border-amber-500 text-white hover:bg-amber-700 font-bold text-lg">÷</Button>
              <Button variant="outline" onClick={() => performOperation('×')} className="bg-amber-600 border-amber-500 text-white hover:bg-amber-700 font-bold text-lg">×</Button>

              {/* Sétima linha */}
              <Button variant="outline" onClick={() => inputNumber(4)} className="bg-slate-600 border-slate-500 text-white hover:bg-slate-500 font-bold text-lg">4</Button>
              <Button variant="outline" onClick={() => inputNumber(5)} className="bg-slate-600 border-slate-500 text-white hover:bg-slate-500 font-bold text-lg">5</Button>
              <Button variant="outline" onClick={() => inputNumber(6)} className="bg-slate-600 border-slate-500 text-white hover:bg-slate-500 font-bold text-lg">6</Button>
              <Button variant="outline" onClick={() => performOperation('-')} className="bg-amber-600 border-amber-500 text-white hover:bg-amber-700 font-bold text-lg">-</Button>
              <Button variant="outline" onClick={() => performOperation('+')} className="bg-amber-600 border-amber-500 text-white hover:bg-amber-700 font-bold text-lg">+</Button>

              {/* Oitava linha */}
              <Button variant="outline" onClick={() => inputNumber(1)} className="bg-slate-600 border-slate-500 text-white hover:bg-slate-500 font-bold text-lg">1</Button>
              <Button variant="outline" onClick={() => inputNumber(2)} className="bg-slate-600 border-slate-500 text-white hover:bg-slate-500 font-bold text-lg">2</Button>
              <Button variant="outline" onClick={() => inputNumber(3)} className="bg-slate-600 border-slate-500 text-white hover:bg-slate-500 font-bold text-lg">3</Button>
              <Button variant="default" className="row-span-2 bg-emerald-600 hover:bg-emerald-700 font-bold text-lg" onClick={() => performOperation('=')}>
                =
              </Button>
              <Button variant="outline" onClick={() => inputNumber(0)} className="bg-slate-600 border-slate-500 text-white hover:bg-slate-500 font-bold text-lg">0</Button>

              {/* Nona linha */}
              <Button variant="outline" onClick={inputDecimal} className="col-span-3 bg-slate-600 border-slate-500 text-white hover:bg-slate-500 font-bold text-lg">.</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Se não está autenticado, mostrar telas de login/registro
  if (!isAuthenticated) {
    if (authView === 'login') {
      return (
        <Login 
          onLogin={handleLogin}
          onSwitchToRegister={() => setAuthView('register')}
        />
      )
    } else {
      return (
        <Register 
          onRegister={handleLogin}
          onSwitchToLogin={() => setAuthView('login')}
        />
      )
    }
  }

  // Renderizar tela inicial com grid
  if (currentView === 'home') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-6">
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center">
                <div className="bg-blue-500 w-8 h-8 rounded-full flex items-center justify-center mr-2">
                  <span className="text-white text-sm font-bold">
                    {user?.email?.charAt(0).toUpperCase()}
                  </span>
                </div>
                <span className="text-sm text-gray-600">Olá, {user?.email}</span>
              </div>
              
              <div className="flex gap-2">
                {user?.is_admin && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentView('admin')}
                    className="text-purple-600 border-purple-600 hover:bg-purple-50"
                  >
                    <Settings className="w-4 h-4 mr-1" />
                    Admin
                  </Button>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleLogout}
                  className="text-red-600 border-red-600 hover:bg-red-50"
                >
                  <LogOut className="w-4 h-4 mr-1" />
                  Sair
                </Button>
              </div>
            </div>
            
            <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">Manual do Engenheiro Civil</h1>
            <p className="text-base md:text-lg text-gray-600">Sua ferramenta completa para o dia a dia da engenharia</p>
          </div>

          {/* Barra de Pesquisa */}
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Pesquisar funcionalidades..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 py-3 text-lg"
            />
          </div>

          {/* Grid de funcionalidades */}
          <div className="grid grid-cols-2 gap-4 md:gap-6">
            {funcionalidadesFiltradas.map((func) => {
              const IconeComponent = func.icone
              return (
                <Card 
                  key={func.id}
                  className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-105 relative overflow-hidden"
                  onClick={() => setCurrentView(func.id)}
                >
                  {/* Imagem de fundo */}
                  <div 
                    className="absolute inset-0 bg-cover bg-center opacity-20"
                    style={{ backgroundImage: `url(${func.bgImage})` }}
                  />
                  
                  {/* Overlay para melhor legibilidade */}
                  <div className="absolute inset-0 bg-white/80" />
                  
                  {/* Conteúdo */}
                  <CardContent className="p-6 text-center relative z-10">
                    <div className={`${func.cor} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg`}>
                      <IconeComponent className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="font-semibold text-lg mb-2 text-gray-800">{func.titulo}</h3>
                    <p className="text-sm text-gray-600">{func.descricao}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Mensagem quando não há resultados */}
          {funcionalidadesFiltradas.length === 0 && (
            <div className="text-center py-8">
              <Search className="w-16 h-16 mx-auto text-gray-400 mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhuma funcionalidade encontrada</h3>
              <p className="text-gray-600">Tente pesquisar com outros termos</p>
            </div>
          )}
        </div>
      </div>
    )
  }

  // Header comum para todas as telas internas
  const HeaderInterno = ({ titulo, icone: Icone, cor }) => (
    <div className="flex items-center mb-6">
      <Button 
        variant="ghost" 
        size="sm" 
        onClick={() => setCurrentView('home')}
        className="mr-4"
      >
        <ArrowLeft className="w-4 h-4" />
      </Button>
      <div className={`${cor} w-10 h-10 rounded-full flex items-center justify-center mr-3`}>
        <Icone className="w-5 h-5 text-white" />
      </div>
      <h1 className="text-2xl font-bold text-gray-800">{titulo}</h1>
    </div>
  )

  // Tela de Calculadora Científica
  if (currentView === 'calculadora') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto">
          <HeaderInterno titulo="Calculadora Científica" icone={Sigma} cor="bg-indigo-500" />
          
          <CalculadoraCientifica />
        </div>
      </div>
    )
  }

  // Tela de Normas - Lista de categorias
  if (currentView === 'normas') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto">
          <HeaderInterno titulo="Normas Técnicas" icone={FileText} cor="bg-blue-500" />
          
          <Card className="mb-6">
            <CardHeader>
              <CardDescription>Selecione uma categoria de normas técnicas</CardDescription>
            </CardHeader>
          </Card>

          {/* Grid de categorias de normas */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            {categoriasNormas.map((categoria) => {
              const IconeComponent = categoria.icone
              return (
                <Card 
                  key={categoria.id}
                  className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-105 relative overflow-hidden h-32"
                  onClick={() => setCurrentView(`normas-${categoria.id}`)}
                >
                  {/* Imagem de fundo mais proeminente */}
                  <div 
                    className="absolute inset-0 bg-cover bg-center opacity-60"
                    style={{ backgroundImage: `url(${categoria.bgImage})` }}
                  />
                  
                  {/* Overlay gradiente para melhor legibilidade */}
                  <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent" />
                  
                  {/* Conteúdo */}
                  <CardContent className="p-4 h-full flex items-center relative z-10">
                    <div className={`${categoria.cor} w-12 h-12 rounded-full flex items-center justify-center mr-4 shadow-lg`}>
                      <IconeComponent className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg text-white mb-1">{categoria.titulo}</h3>
                      <p className="text-sm text-gray-200">{categoria.descricao}</p>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </div>
    )
  }

  // Telas de categorias específicas de normas
  const categoriaAtual = categoriasNormas.find(cat => currentView === `normas-${cat.id}`)
  if (categoriaAtual) {
    const IconeComponent = categoriaAtual.icone
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center mb-6">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setCurrentView('normas')}
              className="mr-4"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className={`${categoriaAtual.cor} w-10 h-10 rounded-full flex items-center justify-center mr-3`}>
              <IconeComponent className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-800">{categoriaAtual.titulo}</h1>
          </div>
          
          <Card>
            <CardHeader>
              <CardDescription>{categoriaAtual.descricao}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {categoriaAtual.normas.map((norma, index) => (
                  <div key={index} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="font-semibold text-lg">{norma.codigo}</h3>
                        <p className="text-gray-600 mt-1">{norma.titulo}</p>
                      </div>
                      <Badge variant="secondary">{norma.ano}</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Tela de Cálculo Rápido - Lista de formatos
  if (currentView === 'calculo') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto">
          <HeaderInterno titulo="Cálculo Rápido" icone={Calculator} cor="bg-green-500" />
          
          <Card className="mb-6">
            <CardHeader>
              <CardDescription>Selecione o formato do terreno para calcular área, perímetro e volume</CardDescription>
            </CardHeader>
          </Card>

          {/* Grid de formatos de terreno */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            {formatosTerreno.map((formato) => {
              const IconeComponent = formato.icone
              return (
                <Card 
                  key={formato.id}
                  className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-105 relative overflow-hidden h-32"
                  onClick={() => {
                    setTerrainType(formato.id)
                    setCurrentView(`calculo-${formato.id}`)
                    setDimensions({ length: '', width: '', height: '', side1: '', side2: '', side3: '', radius: '' })
                    setIncludeHeight(false)
                    setTerrainResults(null)
                  }}
                >
                  {/* Imagem de fundo mais proeminente */}
                  <div 
                    className="absolute inset-0 bg-cover bg-center opacity-60"
                    style={{ backgroundImage: `url(${formato.bgImage})` }}
                  />
                  
                  {/* Overlay gradiente para melhor legibilidade */}
                  <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent" />
                  
                  {/* Conteúdo */}
                  <CardContent className="p-4 h-full flex items-center relative z-10">
                    <div className={`${formato.cor} w-12 h-12 rounded-full flex items-center justify-center mr-4 shadow-lg`}>
                      <IconeComponent className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg text-white mb-1">{formato.titulo}</h3>
                      <p className="text-sm text-gray-200">{formato.descricao}</p>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </div>
    )
  }

  // Telas de cálculo específicas por formato
  const formatoAtual = formatosTerreno.find(fmt => currentView === `calculo-${fmt.id}`)
  if (formatoAtual) {
    const IconeComponent = formatoAtual.icone
    
    const renderCamposDimensoes = () => {
      switch (formatoAtual.id) {
        case 'retangular':
        case 'irregular':
          return (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="length">Comprimento (m)</Label>
                <Input
                  id="length"
                  type="number"
                  value={dimensions.length}
                  onChange={(e) => setDimensions({...dimensions, length: e.target.value})}
                  placeholder="0"
                  className="text-lg"
                />
              </div>
              <div>
                <Label htmlFor="width">Largura (m)</Label>
                <Input
                  id="width"
                  type="number"
                  value={dimensions.width}
                  onChange={(e) => setDimensions({...dimensions, width: e.target.value})}
                  placeholder="0"
                  className="text-lg"
                />
              </div>
            </div>
          )
        case 'quadrado':
          return (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="length">Lado (m)</Label>
                <Input
                  id="length"
                  type="number"
                  value={dimensions.length}
                  onChange={(e) => setDimensions({...dimensions, length: e.target.value})}
                  placeholder="0"
                  className="text-lg"
                />
              </div>
            </div>
          )
        case 'triangular':
          return (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="side1">Lado A (m)</Label>
                <Input
                  id="side1"
                  type="number"
                  value={dimensions.side1}
                  onChange={(e) => setDimensions({...dimensions, side1: e.target.value})}
                  placeholder="0"
                  className="text-lg"
                />
              </div>
              <div>
                <Label htmlFor="side2">Lado B (m)</Label>
                <Input
                  id="side2"
                  type="number"
                  value={dimensions.side2}
                  onChange={(e) => setDimensions({...dimensions, side2: e.target.value})}
                  placeholder="0"
                  className="text-lg"
                />
              </div>
              <div>
                <Label htmlFor="side3">Lado C (m)</Label>
                <Input
                  id="side3"
                  type="number"
                  value={dimensions.side3}
                  onChange={(e) => setDimensions({...dimensions, side3: e.target.value})}
                  placeholder="0"
                  className="text-lg"
                />
              </div>
            </div>
          )
        case 'circular':
          return (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="radius">Raio (m)</Label>
                <Input
                  id="radius"
                  type="number"
                  value={dimensions.radius}
                  onChange={(e) => setDimensions({...dimensions, radius: e.target.value})}
                  placeholder="0"
                  className="text-lg"
                />
              </div>
            </div>
          )
        default:
          return null
      }
    }

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center mb-6">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => setCurrentView('calculo')}
              className="mr-4"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className={`${formatoAtual.cor} w-10 h-10 rounded-full flex items-center justify-center mr-3`}>
              <IconeComponent className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-800">Terreno {formatoAtual.titulo}</h1>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Figura Geométrica */}
            <Card>
              <CardHeader>
                <CardTitle>Visualização</CardTitle>
                <CardDescription>Figura geométrica com dimensões</CardDescription>
              </CardHeader>
              <CardContent>
                <FiguraGeometrica tipo={formatoAtual.id} dimensoes={dimensions} />
              </CardContent>
            </Card>

            {/* Campos de Entrada */}
            <Card>
              <CardHeader>
                <CardTitle>Dimensões</CardTitle>
                <CardDescription>Insira as medidas do terreno</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {renderCamposDimensoes()}

                {/* Checkbox para incluir altura */}
                <div className="flex items-center space-x-2 p-4 bg-gray-50 rounded-lg">
                  <Checkbox
                    id="include-height"
                    checked={includeHeight}
                    onCheckedChange={setIncludeHeight}
                  />
                  <Label htmlFor="include-height" className="text-sm font-medium">
                    Incluir altura/profundidade para cálculo de volume (m³)
                  </Label>
                </div>

                {/* Campo de altura (condicional) */}
                {includeHeight && (
                  <div>
                    <Label htmlFor="height">Altura/Profundidade (m)</Label>
                    <Input
                      id="height"
                      type="number"
                      value={dimensions.height}
                      onChange={(e) => setDimensions({...dimensions, height: e.target.value})}
                      placeholder="0"
                      className="text-lg"
                    />
                  </div>
                )}

                <Button onClick={calculateTerrain} className="w-full" size="lg">
                  <Calculator className="w-4 h-4 mr-2" />
                  Calcular
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Resultados */}
          {terrainResults && (
            <Card className="mt-8">
              <CardHeader>
                <CardTitle>Resultados</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-6 text-center">
                      <h3 className="font-semibold text-lg mb-2">Área</h3>
                      <p className="text-3xl font-bold text-blue-600">{terrainResults.area} m²</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-6 text-center">
                      <h3 className="font-semibold text-lg mb-2">Perímetro</h3>
                      <p className="text-3xl font-bold text-green-600">{terrainResults.perimeter} m</p>
                    </CardContent>
                  </Card>
                  {includeHeight && (
                    <Card>
                      <CardContent className="p-6 text-center">
                        <h3 className="font-semibold text-lg mb-2">Volume</h3>
                        <p className="text-3xl font-bold text-purple-600">{terrainResults.volume} m³</p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    )
  }

  // Tela de Cronograma
  if (currentView === 'cronograma') {
    return <CronogramaOrcamento onBack={() => setCurrentView('home')} />
  }

  // Tela de Traços
  if (currentView === 'tracos') {
    return <Tracos setEtapa={setCurrentView} />
  }

  // Tela de Cálculo de Materiais
  if (currentView === 'materiais') {
    return <CalculoMateriais onBack={() => setCurrentView('home')} />
  }

  // Tela de Cálculo de Valor
  if (currentView === 'valor') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto">
          <HeaderInterno titulo="Cálculo de Valor" icone={DollarSign} cor="bg-purple-500" />
          
          <Card>
            <CardContent className="p-8">
              <div className="text-center">
                <DollarSign className="w-16 h-16 mx-auto text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold mb-2">Funcionalidade em Desenvolvimento</h3>
                <p className="text-gray-600">
                  Esta ferramenta permitirá calcular custos e fazer orçamentos rápidos para projetos.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Tela de Glossário
  if (currentView === 'glossario') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-4xl mx-auto">
          <HeaderInterno titulo="Glossário" icone={BookOpen} cor="bg-teal-500" />
          
          <Card>
            <CardHeader>
              <CardDescription>Definições dos principais termos da engenharia civil</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {glossario.map((item, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <h3 className="font-semibold text-lg text-blue-700 mb-2">{item.termo}</h3>
                    <p className="text-gray-700">{item.definicao}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Tela de Quiz
  if (currentView === 'quiz') {
    return <Quiz />
  }

  // Tela de Notas
  if (currentView === 'notas') {
    return <NotasAvancadas onBack={() => setCurrentView('home')} />
  }

  // Tela de Admin
  if (currentView === 'admin') {
    return <AdminPanel onBack={() => setCurrentView('home')} token={token} />
  }

  return null
}

export default App


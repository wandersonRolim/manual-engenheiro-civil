const feriadosNacionais = [
  "01-01", // Confraternização Universal
  "02-13", // Carnaval (data aproximada, pode variar)
  "02-14", // Carnaval (data aproximada, pode variar)
  "03-29", // Sexta-feira Santa (data aproximada, pode variar)
  "03-31", // Páscoa (data aproximada, pode variar)
  "04-21", // Tiradentes
  "05-01", // Dia do Trabalho
  "05-30", // Corpus Christi (data aproximada, pode variar)
  "09-07", // Independência do Brasil
  "10-12", // Nossa Senhora Aparecida
  "11-02", // Finados
  "11-15", // Proclamação da República
  "12-25"  // Natal
];

// Função para verificar se uma data é feriado
const isFeriado = (date) => {
  const monthDay = `${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}`;
  // Simplificação: para feriados móveis como Carnaval, Páscoa e Corpus Christi, usaremos datas fixas aproximadas.
  // Em um ambiente de produção, seria necessário uma API de feriados mais robusta.
  return feriadosNacionais.includes(monthDay);
};

// Função para adicionar dias úteis a uma data
export const adicionarDiasUteis = (dataInicial, dias) => {
  let data = new Date(dataInicial);
  let diasAdicionados = 0;

  while (diasAdicionados < dias) {
    data.setDate(data.getDate() + 1);
    const diaDaSemana = data.getDay();

    // 0 = Domingo, 6 = Sábado
    if (diaDaSemana !== 0 && diaDaSemana !== 6 && !isFeriado(data)) {
      diasAdicionados++;
    }
  }
  return data;
};

// Função para converter dias corridos para dias úteis (não usada diretamente no Gantt, mas útil para outros cálculos)
export const converterDiasCorridosParaUteis = (dataInicio, dataFim) => {
  let diasUteis = 0;
  let dataAtual = new Date(dataInicio);

  while (dataAtual <= dataFim) {
    const diaDaSemana = dataAtual.getDay();
    if (diaDaSemana !== 0 && diaDaSemana !== 6 && !isFeriado(dataAtual)) {
      diasUteis++;
    }
    dataAtual.setDate(dataAtual.getDate() + 1);
  }
  return diasUteis;
};



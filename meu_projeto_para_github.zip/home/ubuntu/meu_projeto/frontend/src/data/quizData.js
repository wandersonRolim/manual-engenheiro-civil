// Dados do quiz para diferentes tipos de engenharia

// Perguntas de Engenharia Civil (existentes)
const civilQuizData = [
  // Nível 1: Perguntas básicas
  {
    id: 1,
    question: "Qual a principal função do concreto armado em uma estrutura?",
    options: [
      "Aumentar a flexibilidade da estrutura",
      "Resistir a esforços de tração e compressão",
      "Diminuir o peso da estrutura",
      "Acelerar o tempo de cura do concreto",
    ],
    answer: "Resistir a esforços de tração e compressão",
    difficulty: 1,
  },
  {
    id: 2,
    question: "O que é a NBR 6118?",
    options: [
      "Norma de instalações elétricas",
      "Norma de projetos de estruturas de concreto",
      "Norma de segurança contra incêndio",
      "Norma de desempenho de edificações",
    ],
    answer: "Norma de projetos de estruturas de concreto",
    difficulty: 1,
  },
  {
    id: 3,
    question: "Qual o instrumento utilizado para medir ângulos em levantamentos topográficos?",
    options: [
      "Nível",
      "Teodolito",
      "Estação total",
      "Mira",
    ],
    answer: "Teodolito",
    difficulty: 1,
  },
  {
    id: 4,
    question: "O que significa a sigla CAD em projetos de engenharia?",
    options: [
      "Cálculo Auxiliado por Dados",
      "Construção Assistida por Desenho",
      "Desenho Auxiliado por Computador",
      "Controle de Ações e Desenhos",
    ],
    answer: "Desenho Auxiliado por Computador",
    difficulty: 1,
  },
  {
    id: 5,
    question: "Qual o tipo de fundação mais indicado para solos de boa capacidade de carga e cargas concentradas?",
    options: [
      "Radier",
      "Estacas",
      "Sapatas",
      "Tubulões",
    ],
    answer: "Sapatas",
    difficulty: 1,
  },

  // Nível 2: Perguntas de dificuldade média
  {
    id: 6,
    question: "Em um projeto de instalações hidráulicas, qual a função do sifão?",
    options: [
      "Aumentar a pressão da água",
      "Impedir o retorno de gases da rede de esgoto",
      "Filtrar impurezas da água",
      "Controlar o fluxo de água",
    ],
    answer: "Impedir o retorno de gases da rede de esgoto",
    difficulty: 2,
  },
  {
    id: 7,
    question: "O que é o Fator Água/Cimento no concreto?",
    options: [
      "A relação entre a quantidade de água e cimento na mistura",
      "A resistência do concreto à compressão",
      "O tempo de secagem do concreto",
      "A quantidade de aditivos químicos no concreto",
    ],
    answer: "A relação entre a quantidade de água e cimento na mistura",
    difficulty: 2,
  },
  {
    id: 8,
    question: "Qual a finalidade da cura do concreto?",
    options: [
      "Acelerar o endurecimento do concreto",
      "Evitar a retração excessiva e fissuras",
      "Aumentar a trabalhabilidade da mistura",
      "Reduzir o custo da obra",
    ],
    answer: "Evitar a retração excessiva e fissuras",
    difficulty: 2,
  },
  {
    id: 9,
    question: "O que é um diagrama de corpo livre em análise estrutural?",
    options: [
      "Um gráfico de tensões e deformações",
      "Uma representação simplificada de uma estrutura com todas as forças atuantes",
      "Um esquema de montagem de componentes",
      "Um plano de corte de uma viga",
    ],
    answer: "Uma representação simplificada de uma estrutura com todas as forças atuantes",
    difficulty: 2,
  },
  {
    id: 10,
    question: "Qual a importância da sondagem de solo em um projeto de fundações?",
    options: [
      "Determinar a profundidade da água subterrânea",
      "Avaliar a capacidade de carga e características do solo",
      "Identificar a presença de rochas",
      "Calcular o volume de terraplenagem",
    ],
    answer: "Avaliar a capacidade de carga e características do solo",
    difficulty: 2,
  },

  // Nível 3: Perguntas avançadas
  {
    id: 11,
    question: "Explique o conceito de fluência no concreto.",
    options: [
      "É a capacidade do concreto de resistir a altas temperaturas.",
      "É a deformação lenta e progressiva do concreto sob ação de cargas constantes ao longo do tempo.",
      "É a capacidade do concreto de absorver água.",
      "É a perda de resistência do concreto devido à carbonatação.",
    ],
    answer: "É a deformação lenta e progressiva do concreto sob ação de cargas constantes ao longo do tempo.",
    difficulty: 3,
  },
  {
    id: 12,
    question: "Qual a diferença entre viga e laje em termos de comportamento estrutural?",
    options: [
      "Vigas resistem a flexão e lajes a compressão.",
      "Vigas são elementos lineares que suportam cargas em uma direção, enquanto lajes são elementos de superfície que distribuem cargas em duas direções.",
      "Vigas são sempre de concreto e lajes de aço.",
      "Não há diferença significativa, são termos sinônimos.",
    ],
    answer: "Vigas são elementos lineares que suportam cargas em uma direção, enquanto lajes são elementos de superfície que distribuem cargas em duas direções.",
    difficulty: 3,
  },
  {
    id: 13,
    question: "Descreva o processo de adensamento do concreto e sua importância.",
    options: [
      "É a adição de água ao concreto para aumentar sua fluidez.",
      "É a remoção de ar incorporado e vazios do concreto fresco para aumentar sua compacidade e resistência.",
      "É a mistura dos agregados com o cimento.",
      "É o processo de secagem do concreto.",
    ],
    answer: "É a remoção de ar incorporado e vazios do concreto fresco para aumentar sua compacidade e resistência.",
    difficulty: 3,
  },
  {
    id: 14,
    question: "O que é o Método dos Elementos Finitos (MEF) e onde é aplicado na engenharia civil?",
    options: [
      "É um método de cálculo manual para estruturas simples.",
      "É uma técnica numérica para resolver problemas complexos de engenharia, dividindo a estrutura em pequenos elementos, aplicada em análise estrutural, geotécnica e fluxo de fluidos.",
      "É um método de dimensionamento de fundações.",
      "É uma metodologia para gerenciamento de projetos.",
    ],
    answer: "É uma técnica numérica para resolver problemas complexos de engenharia, dividindo a estrutura em pequenos elementos, aplicada em análise estrutural, geotécnica e fluxo de fluidos.",
    difficulty: 3,
  },
  {
    id: 15,
    question: "Qual a função da armadura de pele em vigas de concreto armado?",
    options: [
      "Aumentar a resistência à compressão da viga.",
      "Evitar fissuras superficiais devido à retração e variações térmicas, e auxiliar na ancoragem da armadura principal.",
      "Substituir a armadura principal em casos de pequenas cargas.",
      "Proteger a viga contra corrosão.",
    ],
    answer: "Evitar fissuras superficiais devido à retração e variações térmicas, e auxiliar na ancoragem da armadura principal.",
    difficulty: 3,
  },

  // Nível 4: Perguntas mais avançadas
  {
    id: 16,
    question: "Explique o fenômeno da liquefação do solo e suas consequências em estruturas.",
    options: [
      "É o aumento da resistência do solo devido à compactação.",
      "É a perda de resistência e rigidez de solos saturados e não coesivos devido a carregamentos cíclicos (como terremotos), transformando o solo em um estado líquido e causando colapso de estruturas.",
      "É a solidificação do solo após a adição de cimento.",
      "É a erosão do solo pela água da chuva.",
    ],
    answer: "É a perda de resistência e rigidez de solos saturados e não coesivos devido a carregamentos cíclicos (como terremotos), transformando o solo em um estado líquido e causando colapso de estruturas.",
    difficulty: 4,
  },
  {
    id: 17,
    question: "O que é o módulo de elasticidade do concreto e como ele se relaciona com a resistência?",
    options: [
      "É a capacidade do concreto de se deformar plasticamente.",
      "É uma medida da rigidez do concreto, indicando sua capacidade de deformar elasticamente sob carga. Geralmente, concretos com maior resistência tendem a ter um módulo de elasticidade maior.",
      "É a capacidade do concreto de absorver energia.",
      "É a resistência do concreto à tração.",
    ],
    answer: "É uma medida da rigidez do concreto, indicando sua capacidade de deformar elasticamente sob carga. Geralmente, concretos com maior resistência tendem a ter um módulo de elasticidade maior.",
    difficulty: 4,
  },
  {
    id: 18,
    question: "Descreva o conceito de recalque diferencial em fundações e seus impactos.",
    options: [
      "É o assentamento uniforme de toda a estrutura.",
      "É o assentamento desigual de diferentes partes de uma fundação, causando tensões adicionais na estrutura e podendo levar a fissuras e colapsos.",
      "É o levantamento do solo devido à expansão.",
      "É a compactação do solo sob a fundação.",
    ],
    answer: "É o assentamento desigual de diferentes partes de uma fundação, causando tensões adicionais na estrutura e podendo levar a fissuras e colapsos.",
    difficulty: 4,
  },
  {
    id: 19,
    question: "Qual a importância da análise de ciclo de vida (ACV) em projetos de construção sustentável?",
    options: [
      "Reduzir o tempo de construção.",
      "Avaliar os impactos ambientais de um produto ou processo desde a extração da matéria-prima até o descarte final, permitindo a identificação de oportunidades para reduzir o impacto ambiental da edificação.",
      "Aumentar a durabilidade dos materiais.",
      "Diminuir o custo da mão de obra.",
    ],
    answer: "Avaliar os impactos ambientais de um produto ou processo desde a extração da matéria-prima até o descarte final, permitindo a identificação de oportunidades para reduzir o impacto ambiental da edificação.",
    difficulty: 4,
  },
  {
    id: 20,
    question: "Diferencie concreto protendido de concreto armado convencional.",
    options: [
      "Concreto protendido usa apenas barras de aço, enquanto concreto armado usa cabos.",
      "Concreto protendido tem armaduras ativas (cabos ou fios de aço de alta resistência) que são pré-tracionadas antes ou depois da concretagem, introduzindo tensões de compressão que aumentam a capacidade de carga e reduzem fissuras, ao contrário do concreto armado que usa armaduras passivas.",
      "Concreto protendido é mais barato que o concreto armado.",
      "Concreto protendido é usado apenas em pontes.",
    ],
    answer: "Concreto protendido tem armaduras ativas (cabos ou fios de aço de alta resistência) que são pré-tracionadas antes ou depois da concretagem, introduzindo tensões de compressão que aumentam a capacidade de carga e reduzem fissuras, ao contrário do concreto armado que usa armaduras passivas.",
    difficulty: 4,
  },

  // Nível 5: Perguntas de alta dificuldade
  {
    id: 21,
    question: "Discorra sobre o dimensionamento de pilares esbeltos e os efeitos de segunda ordem.",
    options: [
      "Pilares esbeltos são aqueles com baixa relação entre altura e menor dimensão da seção transversal, e os efeitos de segunda ordem (efeito P-Delta) são deformações adicionais que surgem devido à interação entre as cargas axiais e as deformações da estrutura, exigindo considerações especiais no dimensionamento para evitar instabilidade.",
      "Pilares esbeltos são mais resistentes que pilares curtos.",
      "Efeitos de segunda ordem são causados por ventos fortes.",
      "O dimensionamento de pilares esbeltos é igual ao de pilares curtos.",
    ],
    answer: "Pilares esbeltos são aqueles com baixa relação entre altura e menor dimensão da seção transversal, e os efeitos de segunda ordem (efeito P-Delta) são deformações adicionais que surgem devido à interação entre as cargas axiais e as deformações da estrutura, exigindo considerações especiais no dimensionamento para evitar instabilidade.",
    difficulty: 5,
  },
  {
    id: 22,
    question: "Explique a teoria da plasticidade aplicada ao dimensionamento de estruturas de concreto armado.",
    options: [
      "A teoria da plasticidade considera que os materiais se comportam de forma elástica até a ruptura.",
      "A teoria da plasticidade permite o dimensionamento de estruturas considerando o comportamento inelástico dos materiais após o escoamento, redistribuindo tensões e aproveitando a capacidade de deformação plástica para otimizar o uso dos materiais e garantir a segurança.",
      "É uma teoria que se aplica apenas a estruturas metálicas.",
      "A teoria da plasticidade ignora a capacidade de carga da estrutura.",
    ],
    answer: "A teoria da plasticidade permite o dimensionamento de estruturas considerando o comportamento inelástico dos materiais após o escoamento, redistribuindo tensões e aproveitando a capacidade de deformação plástica para otimizar o uso dos materiais e garantir a segurança.",
    difficulty: 5,
  },
  {
    id: 23,
    question: "Qual a importância da análise de confiabilidade estrutural e quais os principais métodos utilizados?",
    options: [
      "A análise de confiabilidade estrutural garante que a estrutura nunca falhará.",
      "A análise de confiabilidade estrutural avalia a probabilidade de uma estrutura atender aos requisitos de desempenho e segurança ao longo de sua vida útil, considerando incertezas nas cargas e resistências. Métodos incluem FORM (First-Order Reliability Method) e SORM (Second-Order Reliability Method), além de simulações de Monte Carlo.",
      "É um método para calcular a vida útil de uma estrutura.",
      "É uma análise que considera apenas cargas estáticas.",
    ],
    answer: "A análise de confiabilidade estrutural avalia a probabilidade de uma estrutura atender aos requisitos de desempenho e segurança ao longo de sua vida útil, considerando incertezas nas cargas e resistências. Métodos incluem FORM (First-Order Reliability Method) e SORM (Second-Order Reliability Method), além de simulações de Monte Carlo.",
    difficulty: 5,
  },
  {
    id: 24,
    question: "Descreva os princípios do BIM (Building Information Modeling) e seus benefícios para a engenharia civil.",
    options: [
      "BIM é um software de desenho 2D.",
      "BIM é uma metodologia de trabalho colaborativa baseada na criação e uso de um modelo digital inteligente da edificação, que integra informações de todas as disciplinas do projeto. Benefícios incluem melhor coordenação, detecção de conflitos, otimização de custos e prazos, e melhor gestão do ciclo de vida da edificação.",
      "BIM é um método de cálculo estrutural.",
      "BIM é apenas para projetos arquitetônicos.",
    ],
    answer: "BIM é uma metodologia de trabalho colaborativa baseada na criação e uso de um modelo digital inteligente da edificação, que integra informações de todas as disciplinas do projeto. Benefícios incluem melhor coordenação, detecção de conflitos, otimização de custos e prazos, e melhor gestão do ciclo de vida da edificação.",
    difficulty: 5,
  },
  {
    id: 25,
    question: "Aborde o conceito de resiliência urbana e sua aplicação na engenharia civil moderna.",
    options: [
      "Resiliência urbana refere-se à capacidade de uma cidade de resistir a desastres naturais.",
      "Resiliência urbana é a capacidade de sistemas urbanos (infraestrutura, sociedade, economia) de resistir, absorver, adaptar-se e recuperar-se de choques e estresses (naturais ou antrópicos) de forma eficiente e sustentável. Na engenharia civil, envolve o projeto de infraestruturas robustas, flexíveis e adaptáveis, como sistemas de drenagem resilientes a inundações e edifícios resistentes a terremotos.",
      "Resiliência urbana é a capacidade de uma cidade de crescer rapidamente.",
      "Resiliência urbana é a beleza estética das construções.",
    ],
    answer: "Resiliência urbana é a capacidade de sistemas urbanos (infraestrutura, sociedade, economia) de resistir, absorver, adaptar-se e recuperar-se de choques e estresses (naturais ou antrópicos) de forma eficiente e sustentável. Na engenharia civil, envolve o projeto de infraestruturas robustas, flexíveis e adaptáveis, como sistemas de drenagem resilientes a inundações e edifícios resistentes a terremotos.",
    difficulty: 5,
  },

  // Adicionar mais 25 perguntas para completar 50, com dificuldades variadas
  // Nível 1
  {
    id: 26,
    question: "Qual o principal material utilizado na fabricação de cimento?",
    options: [
      "Areia",
      "Brita",
      "Calcário",
      "Água",
    ],
    answer: "Calcário",
    difficulty: 1,
  },
  {
    id: 27,
    question: "O que é um croqui em desenho técnico?",
    options: [
      "Um desenho final detalhado",
      "Um esboço rápido e à mão livre",
      "Um modelo 3D",
      "Uma planta baixa",
    ],
    answer: "Um esboço rápido e à mão livre",
    difficulty: 1,
  },
  {
    id: 28,
    question: "Qual a unidade de medida de resistência à compressão do concreto?",
    options: [
      "Kg",
      "MPa",
      "Litros",
      "Metros",
    ],
    answer: "MPa",
    difficulty: 1,
  },
  {
    id: 29,
    question: "O que é um aterro sanitário?",
    options: [
      "Local de descarte de resíduos sem tratamento",
      "Local para tratamento de água",
      "Estrutura para disposição final de resíduos sólidos urbanos de forma controlada",
      "Estação de tratamento de esgoto",
    ],
    answer: "Estrutura para disposição final de resíduos sólidos urbanos de forma controlada",
    difficulty: 1,
  },
  {
    id: 30,
    question: "Qual a função da viga baldrame?",
    options: [
      "Sustentar o telhado",
      "Distribuir as cargas das paredes para as fundações",
      "Servir como elemento decorativo",
      "Conduzir água da chuva",
    ],
    answer: "Distribuir as cargas das paredes para as fundações",
    difficulty: 1,
  },

  // Nível 2
  {
    id: 31,
    question: "Em projetos de drenagem, o que é um bueiro?",
    options: [
      "Um tipo de bomba d'água",
      "Uma estrutura para passagem de água sob vias ou aterros",
      "Um reservatório de água",
      "Um sistema de irrigação",
    ],
    answer: "Uma estrutura para passagem de água sob vias ou aterros",
    difficulty: 2,
  },
  {
    id: 32,
    question: "Qual a diferença entre concreto usinado e concreto virado em obra?",
    options: [
      "Concreto usinado é mais barato.",
      "Concreto usinado é produzido em central e transportado pronto, garantindo maior controle de qualidade, enquanto o virado em obra é misturado no local.",
      "Concreto virado em obra tem maior resistência.",
      "Não há diferença na qualidade final.",
    ],
    answer: "Concreto usinado é produzido em central e transportado pronto, garantindo maior controle de qualidade, enquanto o virado em obra é misturado no local.",
    difficulty: 2,
  },
  {
    id: 33,
    question: "O que é um talude e qual sua importância na engenharia geotécnica?",
    options: [
      "Um tipo de rocha.",
      "Uma inclinação de terreno natural ou artificial, importante para a estabilidade de obras de terra e contenções.",
      "Um equipamento de perfuração.",
      "Um tipo de fundação.",
    ],
    answer: "Uma inclinação de terreno natural ou artificial, importante para a estabilidade de obras de terra e contenções.",
    difficulty: 2,
  },
  {
    id: 34,
    question: "Qual a função da armadura de cisalhamento (estribos) em vigas de concreto armado?",
    options: [
      "Resistir a esforços de tração.",
      "Resistir a esforços de compressão.",
      "Resistir a esforços cortantes.",
      "Aumentar a flexibilidade da viga.",
    ],
    answer: "Resistir a esforços cortantes.",
    difficulty: 2,
  },
  {
    id: 35,
    question: "O que é um ensaio de proctor na engenharia civil?",
    options: [
      "Ensaio para determinar a resistência do concreto.",
      "Ensaio para determinar a umidade ótima e a massa específica máxima de um solo para compactação.",
      "Ensaio para medir a permeabilidade do solo.",
      "Ensaio para verificar a qualidade do cimento.",
    ],
    answer: "Ensaio para determinar a umidade ótima e a massa específica máxima de um solo para compactação.",
    difficulty: 2,
  },

  // Nível 3
  {
    id: 36,
    question: "Explique o conceito de patologia das construções.",
    options: [
      "É o estudo de novas técnicas construtivas.",
      "É a área da engenharia que estuda as causas, mecanismos e consequências de anomalias e falhas em edificações e estruturas.",
      "É o processo de projeto de edifícios.",
      "É a manutenção preventiva de estruturas.",
    ],
    answer: "É a área da engenharia que estuda as causas, mecanismos e consequências de anomalias e falhas em edificações e estruturas.",
    difficulty: 3,
  },
  {
    id: 37,
    question: "Qual a importância da ventilação cruzada em projetos arquitetônicos e de engenharia?",
    options: [
      "Aumentar o consumo de energia.",
      "Melhorar o conforto térmico e a qualidade do ar interno, reduzindo a necessidade de climatização artificial.",
      "Diminuir a iluminação natural.",
      "Aumentar a umidade do ambiente.",
    ],
    answer: "Melhorar o conforto térmico e a qualidade do ar interno, reduzindo a necessidade de climatização artificial.",
    difficulty: 3,
  },
  {
    id: 38,
    question: "Descreva o processo de estaqueamento e suas aplicações.",
    options: [
      "É a construção de paredes de alvenaria.",
      "É a execução de fundações profundas por meio de estacas, utilizadas em solos de baixa capacidade de carga ou para transferir cargas para camadas mais profundas e resistentes.",
      "É a instalação de telhados.",
      "É a montagem de estruturas metálicas.",
    ],
    answer: "É a execução de fundações profundas por meio de estacas, utilizadas em solos de baixa capacidade de carga ou para transferir cargas para camadas mais profundas e resistentes.",
    difficulty: 3,
  },
  {
    id: 39,
    question: "O que é o coeficiente de recalque (kv) em solos e sua relevância?",
    options: [
      "É a resistência do solo ao cisalhamento.",
      "É um parâmetro que relaciona a tensão aplicada ao solo com o recalque resultante, indicando a rigidez do solo sob carregamento e sendo crucial no dimensionamento de fundações.",
      "É a capacidade de drenagem do solo.",
      "É a densidade do solo.",
    ],
    answer: "É um parâmetro que relaciona a tensão aplicada ao solo com o recalque resultante, indicando a rigidez do solo sob carregamento e sendo crucial no dimensionamento de fundações.",
    difficulty: 3,
  },
  {
    id: 40,
    question: "Qual a função da junta de dilatação em grandes estruturas de concreto?",
    options: [
      "Aumentar a resistência da estrutura.",
      "Permitir a movimentação da estrutura devido a variações térmicas, retração e fluência, evitando o surgimento de tensões excessivas e fissuras.",
      "Conduzir a água da chuva.",
      "Servir como elemento estético.",
    ],
    answer: "Permitir a movimentação da estrutura devido a variações térmicas, retração e fluência, evitando o surgimento de tensões excessivas e fissuras.",
    difficulty: 3,
  },

  // Nível 4
  {
    id: 41,
    question: "Discorra sobre a importância da gestão de resíduos na construção civil e as principais estratégias.",
    options: [
      "A gestão de resíduos na construção civil é irrelevante.",
      "A gestão de resíduos na construção civil é crucial para a sustentabilidade, reduzindo o impacto ambiental, otimizando recursos e gerando valor. Estratégias incluem a não geração, redução, reutilização, reciclagem e descarte adequado.",
      "A gestão de resíduos é apenas para grandes obras.",
      "A gestão de resíduos aumenta os custos da obra.",
    ],
    answer: "A gestão de resíduos na construção civil é crucial para a sustentabilidade, reduzindo o impacto ambiental, otimizando recursos e gerando valor. Estratégias incluem a não geração, redução, reutilização, reciclagem e descarte adequado.",
    difficulty: 4,
  },
  {
    id: 42,
    question: "Explique o conceito de análise de risco em projetos de engenharia civil.",
    options: [
      "Análise de risco é apenas para projetos financeiros.",
      "Análise de risco é o processo de identificar, avaliar e mitigar incertezas e potenciais eventos adversos que podem afetar o sucesso de um projeto, garantindo a segurança, qualidade e viabilidade.",
      "Análise de risco é feita apenas após a conclusão da obra.",
      "Análise de risco é o mesmo que controle de qualidade.",
    ],
    answer: "Análise de risco é o processo de identificar, avaliar e mitigar incertezas e potenciais eventos adversos que podem afetar o sucesso de um projeto, garantindo a segurança, qualidade e viabilidade.",
    difficulty: 4,
  },
  {
    id: 43,
    question: "Qual a função do sistema de reuso de água cinza em edificações?",
    options: [
      "Tratar água potável.",
      "Coletar e tratar a água proveniente de chuveiros, lavatórios e máquinas de lavar roupa para fins não potáveis, como descarga de vasos sanitários e irrigação, promovendo a economia de água.",
      "Descartar água suja diretamente no esgoto.",
      "Aumentar o consumo de água.",
    ],
    answer: "Coletar e tratar a água proveniente de chuveiros, lavatórios e máquinas de lavar roupa para fins não potáveis, como descarga de vasos sanitários e irrigação, promovendo a economia de água.",
    difficulty: 4,
  },
  {
    id: 44,
    question: "Descreva o processo de injeção de calda de cimento em solos e rochas.",
    options: [
      "É um método de escavação.",
      "É uma técnica de melhoramento de solos e rochas que consiste na injeção de uma mistura de cimento e água (calda) para preencher vazios, aumentar a resistência e reduzir a permeabilidade.",
      "É um método de impermeabilização de lajes.",
      "É um processo de cura do concreto.",
    ],
    answer: "É uma técnica de melhoramento de solos e rochas que consiste na injeção de uma mistura de cimento e água (calda) para preencher vazios, aumentar a resistência e reduzir a permeabilidade.",
    difficulty: 4,
  },
  {
    id: 45,
    question: "Qual a importância da topografia em todas as fases de um projeto de engenharia civil?",
    options: [
      "A topografia é importante apenas na fase de execução.",
      "A topografia é fundamental em todas as fases, desde o planejamento (levantamento de dados do terreno) até a execução (locação de obras e controle dimensional) e pós-obra (monitoramento), garantindo a precisão e a correta implantação do projeto.",
      "A topografia é utilizada apenas em projetos de estradas.",
      "A topografia não influencia o custo da obra.",
    ],
    answer: "A topografia é fundamental em todas as fases, desde o planejamento (levantamento de dados do terreno) até a execução (locação de obras e controle dimensional) e pós-obra (monitoramento), garantindo a precisão e a correta implantação do projeto.",
    difficulty: 4,
  },

  // Nível 5
  {
    id: 46,
    question: "Aborde o conceito de durabilidade das estruturas de concreto e os principais mecanismos de deterioração.",
    options: [
      "Durabilidade é apenas a resistência à compressão.",
      "Durabilidade refere-se à capacidade da estrutura de manter suas características de desempenho e segurança ao longo do tempo, sob as condições ambientais e de uso. Mecanismos de deterioração incluem carbonatação, ataque por cloretos, reação álcali-agregado, sulfatos e congelamento-descongelamento.",
      "Durabilidade é garantida apenas pela cura.",
      "Mecanismos de deterioração são irrelevantes.",
    ],
    answer: "Durabilidade refere-se à capacidade da estrutura de manter suas características de desempenho e segurança ao longo do tempo, sob as condições ambientais e de uso. Mecanismos de deterioração incluem carbonatação, ataque por cloretos, reação álcali-agregado, sulfatos e congelamento-descongelamento.",
    difficulty: 5,
  },
  {
    id: 47,
    question: "Explique a diferença entre análise estática e dinâmica de estruturas.",
    options: [
      "Análise estática considera cargas em movimento, e dinâmica cargas paradas.",
      "Análise estática considera cargas que não variam significativamente com o tempo, ou variam lentamente, enquanto a análise dinâmica considera cargas que variam rapidamente com o tempo (ex: terremotos, vento, vibrações), levando em conta a inércia e o amortecimento da estrutura.",
      "Análise estática é mais complexa que a dinâmica.",
      "Não há diferença prática entre elas.",
    ],
    answer: "Análise estática considera cargas que não variam significativamente com o tempo, ou variam lentamente, enquanto a análise dinâmica considera cargas que variam rapidamente com o tempo (ex: terremotos, vento, vibrações), levando em conta a inércia e o amortecimento da estrutura.",
    difficulty: 5,
  },
  {
    id: 48,
    question: "Discorra sobre os desafios e soluções na construção de edifícios em solos moles ou compressíveis.",
    options: [
      "Solos moles não apresentam desafios na construção.",
      "Desafios incluem recalques excessivos e diferenciais, baixa capacidade de carga e instabilidade. Soluções envolvem fundações profundas (estacas, tubulões), melhoramento de solo (adensamento, colunas de brita, injeções) e projetos de superestrutura flexíveis.",
      "A única solução é remover todo o solo mole.",
      "Construir em solos moles é sempre inviável.",
    ],
    answer: "Desafios incluem recalques excessivos e diferenciais, baixa capacidade de carga e instabilidade. Soluções envolvem fundações profundas (estacas, tubulões), melhoramento de solo (adensamento, colunas de brita, injeções) e projetos de superestrutura flexíveis.",
    difficulty: 5,
  },
  {
    id: 49,
    question: "Qual a importância da instrumentação e monitoramento em grandes obras de engenharia civil?",
    options: [
      "Instrumentação e monitoramento são apenas para obras de pequeno porte.",
      "A instrumentação e o monitoramento permitem acompanhar o comportamento real da estrutura e do solo durante e após a construção, verificando a conformidade com o projeto, detectando anomalias precocemente e garantindo a segurança e o desempenho da obra.",
      "Não há necessidade de monitoramento após a construção.",
      "A instrumentação é apenas para fins de pesquisa.",
    ],
    answer: "A instrumentação e o monitoramento permitem acompanhar o comportamento real da estrutura e do solo durante e após a construção, verificando a conformidade com o projeto, detectando anomalias precocemente e garantindo a segurança e o desempenho da obra.",
    difficulty: 5,
  },
  {
    id: 50,
    question: "Explique o conceito de análise de risco sísmico e suas implicações no projeto de edifícios.",
    options: [
      "Análise de risco sísmico é apenas para regiões com terremotos frequentes.",
      "Análise de risco sísmico avalia a probabilidade de ocorrência de terremotos e seus efeitos nas estruturas, permitindo o projeto de edifícios com resistência e ductilidade adequadas para suportar as ações sísmicas, minimizando danos e protegendo vidas.",
      "Análise de risco sísmico é um processo simples.",
      "Edifícios não precisam ser projetados para terremotos.",
    ],
    answer: "Análise de risco sísmico avalia a probabilidade de ocorrência de terremotos e seus efeitos nas estruturas, permitindo o projeto de edifícios com resistência e ductilidade adequadas para suportar as ações sísmicas, minimizando danos e protegendo vidas.",
    difficulty: 5,
  },
];

// Perguntas de Arquitetura
const arquiteturaQuizData = [


  // Nível 1: Perguntas básicas
  {
    id: 1,
    question: "Qual a principal função da ventilação natural em um projeto arquitetônico?",
    options: [
      "Aumentar o consumo de energia",
      "Promover o conforto térmico e a qualidade do ar interno",
      "Diminuir a iluminação natural",
      "Reduzir o custo da construção",
    ],
    answer: "Promover o conforto térmico e a qualidade do ar interno",
    difficulty: 1,
  },
  {
    id: 2,
    question: "O que é a NBR 9050?",
    options: [
      "Norma de estruturas de concreto",
      "Norma de acessibilidade a edificações",
      "Norma de instalações elétricas",
      "Norma de segurança contra incêndio",
    ],
    answer: "Norma de acessibilidade a edificações",
    difficulty: 1,
  },
  {
    id: 3,
    question: "Qual o instrumento básico utilizado para medir distâncias em levantamentos arquitetônicos?",
    options: [
      "Esquadro",
      "Trena",
      "Compasso",
      "Régua T",
    ],
    answer: "Trena",
    difficulty: 1,
  },
  {
    id: 4,
    question: "O que significa a sigla CAD em projetos arquitetônicos?",
    options: [
      "Cálculo Auxiliado por Dados",
      "Construção Assistida por Desenho",
      "Desenho Auxiliado por Computador",
      "Controle de Ações e Desenhos",
    ],
    answer: "Desenho Auxiliado por Computador",
    difficulty: 1,
  },
  {
    id: 5,
    question: "Qual o tipo de fundação mais comum em residências unifamiliares?",
    options: [
      "Radier",
      "Estacas",
      "Sapatas corridas",
      "Tubulões",
    ],
    answer: "Sapatas corridas",
    difficulty: 1,
  },

  // Nível 2: Perguntas de dificuldade média
  {
    id: 6,
    question: "Em um projeto de paisagismo, qual a função principal da drenagem?",
    options: [
      "Aumentar a umidade do solo",
      "Evitar encharcamento e erosão do terreno",
      "Diminuir a vegetação",
      "Reduzir a infiltração de água",
    ],
    answer: "Evitar encharcamento e erosão do terreno",
    difficulty: 2,
  },
  {
    id: 7,
    question: "O que é o conceito de modulação na arquitetura?",
    options: [
      "A repetição de elementos construtivos em dimensões padronizadas",
      "A resistência dos materiais",
      "O tempo de execução da obra",
      "A quantidade de pavimentos do edifício",
    ],
    answer: "A repetição de elementos construtivos em dimensões padronizadas",
    difficulty: 2,
  },
  {
    id: 8,
    question: "Qual a finalidade do estudo de insolação em projetos arquitetônicos?",
    options: [
      "Acelerar a construção",
      "Otimizar o aproveitamento da luz natural e controlar o ganho térmico",
      "Aumentar o consumo energético",
      "Reduzir o custo dos materiais",
    ],
    answer: "Otimizar o aproveitamento da luz natural e controlar o ganho térmico",
    difficulty: 2,
  },
  {
    id: 9,
    question: "O que é um programa de necessidades em arquitetura?",
    options: [
      "Um cronograma de obras",
      "Uma lista detalhada dos ambientes e suas características funcionais",
      "Um orçamento da construção",
      "Um projeto estrutural",
    ],
    answer: "Uma lista detalhada dos ambientes e suas características funcionais",
    difficulty: 2,
  },
  {
    id: 10,
    question: "Qual a importância do estudo do terreno em um projeto arquitetônico?",
    options: [
      "Determinar apenas o valor do imóvel",
      "Conhecer as características físicas, topográficas e legais para adequar o projeto",
      "Identificar apenas a vegetação existente",
      "Calcular somente a área construída",
    ],
    answer: "Conhecer as características físicas, topográficas e legais para adequar o projeto",
    difficulty: 2,
  },

  // Nível 3: Perguntas avançadas
  {
    id: 11,
    question: "Explique o conceito de conforto ambiental na arquitetura.",
    options: [
      "É apenas a decoração dos ambientes.",
      "É o conjunto de condições térmicas, acústicas, lumínicas e de qualidade do ar que proporcionam bem-estar aos usuários.",
      "É a capacidade de resistir a terremotos.",
      "É a facilidade de manutenção do edifício.",
    ],
    answer: "É o conjunto de condições térmicas, acústicas, lumínicas e de qualidade do ar que proporcionam bem-estar aos usuários.",
    difficulty: 3,
  },
  {
    id: 12,
    question: "Qual a diferença entre arquitetura vernacular e erudita?",
    options: [
      "Vernacular usa materiais caros e erudita materiais baratos.",
      "Vernacular é a arquitetura popular tradicional baseada em conhecimentos locais, enquanto erudita é a arquitetura acadêmica com base teórica formal.",
      "Vernacular é sempre moderna e erudita é sempre antiga.",
      "Não há diferença significativa entre elas.",
    ],
    answer: "Vernacular é a arquitetura popular tradicional baseada em conhecimentos locais, enquanto erudita é a arquitetura acadêmica com base teórica formal.",
    difficulty: 3,
  },
  {
    id: 13,
    question: "Descreva o conceito de sustentabilidade na arquitetura.",
    options: [
      "É apenas o uso de materiais recicláveis.",
      "É a prática de projetar edifícios que minimizam o impacto ambiental através do uso eficiente de recursos, energia e materiais sustentáveis.",
      "É a construção apenas com madeira.",
      "É o projeto de edifícios temporários.",
    ],
    answer: "É a prática de projetar edifícios que minimizam o impacto ambiental através do uso eficiente de recursos, energia e materiais sustentáveis.",
    difficulty: 3,
  },
  {
    id: 14,
    question: "O que é o conceito de flexibilidade espacial na arquitetura contemporânea?",
    options: [
      "É a capacidade de um edifício resistir a ventos.",
      "É a possibilidade de adaptar e reconfigurar os espaços internos conforme as necessidades dos usuários ao longo do tempo.",
      "É a facilidade de demolição do edifício.",
      "É a capacidade de expansão vertical apenas.",
    ],
    answer: "É a possibilidade de adaptar e reconfigurar os espaços internos conforme as necessidades dos usuários ao longo do tempo.",
    difficulty: 3,
  },
  {
    id: 15,
    question: "Qual a função dos elementos de proteção solar (brises) na arquitetura?",
    options: [
      "Aumentar o ganho térmico do edifício.",
      "Controlar a incidência solar, reduzindo o ganho térmico e o ofuscamento, mantendo a iluminação natural.",
      "Substituir as janelas completamente.",
      "Servir apenas como elemento decorativo.",
    ],
    answer: "Controlar a incidência solar, reduzindo o ganho térmico e o ofuscamento, mantendo a iluminação natural.",
    difficulty: 3,
  },

  // Nível 4: Perguntas mais avançadas
  {
    id: 16,
    question: "Explique o conceito de arquitetura bioclimática e suas estratégias.",
    options: [
      "É a arquitetura que usa apenas materiais naturais.",
      "É a arquitetura que considera as condições climáticas locais para otimizar o conforto ambiental através de estratégias passivas como orientação, ventilação natural, proteção solar e uso de materiais adequados.",
      "É a arquitetura que imita formas da natureza.",
      "É a arquitetura construída apenas em climas tropicais.",
    ],
    answer: "É a arquitetura que considera as condições climáticas locais para otimizar o conforto ambiental através de estratégias passivas como orientação, ventilação natural, proteção solar e uso de materiais adequados.",
    difficulty: 4,
  },
  {
    id: 17,
    question: "O que é o conceito de permeabilidade urbana e sua importância no planejamento?",
    options: [
      "É a capacidade do solo de absorver água.",
      "É a facilidade de circulação e conexão entre diferentes áreas urbanas, promovendo acessibilidade e integração social.",
      "É a resistência dos materiais urbanos.",
      "É a densidade populacional das cidades.",
    ],
    answer: "É a facilidade de circulação e conexão entre diferentes áreas urbanas, promovendo acessibilidade e integração social.",
    difficulty: 4,
  },
  {
    id: 18,
    question: "Descreva o conceito de gentrificação urbana e seus impactos.",
    options: [
      "É o processo de melhoria urbana sem consequências sociais.",
      "É o processo de transformação urbana que resulta na valorização imobiliária e pode levar ao deslocamento de populações de menor renda.",
      "É apenas a renovação de edifícios antigos.",
      "É a expansão horizontal das cidades.",
    ],
    answer: "É o processo de transformação urbana que resulta na valorização imobiliária e pode levar ao deslocamento de populações de menor renda.",
    difficulty: 4,
  },
  {
    id: 19,
    question: "Qual a importância da análise pós-ocupação (APO) em projetos arquitetônicos?",
    options: [
      "Reduzir o tempo de construção.",
      "Avaliar o desempenho do edifício em uso, identificando sucessos e problemas para melhorar futuros projetos.",
      "Aumentar o valor comercial do imóvel.",
      "Diminuir o custo de manutenção.",
    ],
    answer: "Avaliar o desempenho do edifício em uso, identificando sucessos e problemas para melhorar futuros projetos.",
    difficulty: 4,
  },
  {
    id: 20,
    question: "Diferencie espaço público e espaço coletivo na arquitetura urbana.",
    options: [
      "Espaço público é privado e coletivo é público.",
      "Espaço público é de propriedade e gestão pública, acessível a todos, enquanto espaço coletivo pode ser privado mas de uso compartilhado por um grupo específico.",
      "Espaço público é sempre coberto e coletivo é descoberto.",
      "Não há diferença entre os conceitos.",
    ],
    answer: "Espaço público é de propriedade e gestão pública, acessível a todos, enquanto espaço coletivo pode ser privado mas de uso compartilhado por um grupo específico.",
    difficulty: 4,
  },

  // Nível 5: Perguntas de alta dificuldade
  {
    id: 21,
    question: "Discorra sobre o conceito de arquitetura paramétrica e suas aplicações contemporâneas.",
    options: [
      "Arquitetura paramétrica usa apenas formas geométricas simples.",
      "Arquitetura paramétrica utiliza algoritmos e parâmetros variáveis para gerar formas complexas e otimizar soluções de projeto, permitindo explorar múltiplas possibilidades de design através de ferramentas computacionais.",
      "Arquitetura paramétrica é apenas para edifícios residenciais.",
      "Arquitetura paramétrica ignora as condições ambientais.",
    ],
    answer: "Arquitetura paramétrica utiliza algoritmos e parâmetros variáveis para gerar formas complexas e otimizar soluções de projeto, permitindo explorar múltiplas possibilidades de design através de ferramentas computacionais.",
    difficulty: 5,
  },
  {
    id: 22,
    question: "Explique a teoria da sintaxe espacial aplicada ao urbanismo.",
    options: [
      "A sintaxe espacial considera apenas a gramática da arquitetura.",
      "A sintaxe espacial é um método de análise que estuda como a configuração espacial urbana influencia os padrões de movimento, encontros sociais e atividades econômicas nas cidades.",
      "É uma teoria que se aplica apenas a edifícios isolados.",
      "A sintaxe espacial ignora os aspectos sociais do espaço.",
    ],
    answer: "A sintaxe espacial é um método de análise que estuda como a configuração espacial urbana influencia os padrões de movimento, encontros sociais e atividades econômicas nas cidades.",
    difficulty: 5,
  },
  {
    id: 23,
    question: "Qual a importância da fenomenologia na teoria arquitetônica contemporânea?",
    options: [
      "A fenomenologia garante que todos os edifícios sejam iguais.",
      "A fenomenologia na arquitetura enfatiza a experiência sensorial e emocional do espaço, considerando como os usuários percebem e vivenciam os ambientes através dos sentidos, memórias e significados.",
      "É um método apenas para calcular estruturas.",
      "A fenomenologia considera apenas aspectos visuais.",
    ],
    answer: "A fenomenologia na arquitetura enfatiza a experiência sensorial e emocional do espaço, considerando como os usuários percebem e vivenciam os ambientes através dos sentidos, memórias e significados.",
    difficulty: 5,
  },
  {
    id: 24,
    question: "Descreva os princípios da arquitetura regenerativa e sua diferença da sustentável.",
    options: [
      "Arquitetura regenerativa é igual à sustentável.",
      "Arquitetura regenerativa vai além da sustentabilidade, buscando não apenas minimizar impactos negativos, mas criar impactos positivos que restaurem e regenerem os sistemas naturais e sociais.",
      "Arquitetura regenerativa usa apenas materiais antigos.",
      "Arquitetura regenerativa é apenas para climas quentes.",
    ],
    answer: "Arquitetura regenerativa vai além da sustentabilidade, buscando não apenas minimizar impactos negativos, mas criar impactos positivos que restaurem e regenerem os sistemas naturais e sociais.",
    difficulty: 5,
  },
  {
    id: 25,
    question: "Aborde o conceito de resiliência urbana aplicado ao design arquitetônico.",
    options: [
      "Resiliência urbana refere-se apenas à resistência estrutural.",
      "Resiliência urbana no design arquitetônico envolve criar edifícios e espaços capazes de se adaptar, resistir e se recuperar de choques e mudanças, como mudanças climáticas, desastres naturais e transformações sociais.",
      "Resiliência urbana é apenas para edifícios altos.",
      "Resiliência urbana ignora aspectos ambientais.",
    ],
    answer: "Resiliência urbana no design arquitetônico envolve criar edifícios e espaços capazes de se adaptar, resistir e se recuperar de choques e mudanças, como mudanças climáticas, desastres naturais e transformações sociais.",
    difficulty: 5,
  },

  // Adicionar mais 25 perguntas para completar 50
  // Nível 1
  {
    id: 26,
    question: "Qual o principal material tradicionalmente usado em coberturas no Brasil?",
    options: [
      "Vidro",
      "Metal",
      "Telha cerâmica",
      "Plástico",
    ],
    answer: "Telha cerâmica",
    difficulty: 1,
  },
  {
    id: 27,
    question: "O que é uma planta baixa em arquitetura?",
    options: [
      "Uma vista externa do edifício",
      "Uma representação horizontal do edifício cortado a 1,50m do piso",
      "Um modelo tridimensional",
      "Uma perspectiva do interior",
    ],
    answer: "Uma representação horizontal do edifício cortado a 1,50m do piso",
    difficulty: 1,
  },
  {
    id: 28,
    question: "Qual a unidade de medida padrão para áreas em projetos arquitetônicos?",
    options: [
      "Centímetros quadrados",
      "Metros quadrados",
      "Quilômetros quadrados",
      "Hectares",
    ],
    answer: "Metros quadrados",
    difficulty: 1,
  },
  {
    id: 29,
    question: "O que é um memorial descritivo em arquitetura?",
    options: [
      "Uma lista de materiais",
      "Um documento que descreve as características e especificações do projeto",
      "Um cronograma de obras",
      "Um orçamento detalhado",
    ],
    answer: "Um documento que descreve as características e especificações do projeto",
    difficulty: 1,
  },
  {
    id: 30,
    question: "Qual a função principal de um hall de entrada?",
    options: [
      "Armazenar objetos",
      "Receber e distribuir os fluxos de circulação",
      "Servir como área de lazer",
      "Funcionar como escritório",
    ],
    answer: "Receber e distribuir os fluxos de circulação",
    difficulty: 1,
  },

  // Nível 2
  {
    id: 31,
    question: "Em projetos de interiores, o que é ergonomia?",
    options: [
      "O estilo decorativo do ambiente",
      "A adequação do espaço e mobiliário às necessidades e limitações humanas",
      "A escolha de cores do ambiente",
      "O sistema de iluminação artificial",
    ],
    answer: "A adequação do espaço e mobiliário às necessidades e limitações humanas",
    difficulty: 2,
  },
  {
    id: 32,
    question: "Qual a diferença entre arquitetura moderna e contemporânea?",
    options: [
      "Moderna é mais cara que contemporânea.",
      "Moderna refere-se ao movimento do século XX com princípios específicos, enquanto contemporânea é a arquitetura atual, diversa em estilos.",
      "Contemporânea usa apenas materiais antigos.",
      "Não há diferença entre os termos.",
    ],
    answer: "Moderna refere-se ao movimento do século XX com princípios específicos, enquanto contemporânea é a arquitetura atual, diversa em estilos.",
    difficulty: 2,
  },
  {
    id: 33,
    question: "O que é zoneamento em planejamento urbano?",
    options: [
      "A divisão de terrenos em lotes.",
      "A definição de áreas urbanas com usos específicos (residencial, comercial, industrial).",
      "O sistema de transporte público.",
      "A arborização das ruas.",
    ],
    answer: "A definição de áreas urbanas com usos específicos (residencial, comercial, industrial).",
    difficulty: 2,
  },
  {
    id: 34,
    question: "Qual a função da circulação vertical em edifícios?",
    options: [
      "Conectar apenas o térreo ao primeiro andar.",
      "Permitir o deslocamento entre diferentes pavimentos através de escadas, rampas e elevadores.",
      "Servir apenas para emergências.",
      "Funcionar como área de estar.",
    ],
    answer: "Permitir o deslocamento entre diferentes pavimentos através de escadas, rampas e elevadores.",
    difficulty: 2,
  },
  {
    id: 35,
    question: "O que é um estudo de viabilidade em arquitetura?",
    options: [
      "Análise apenas dos custos de construção.",
      "Avaliação técnica, legal, econômica e ambiental da possibilidade de realização do projeto.",
      "Estudo apenas da resistência estrutural.",
      "Análise apenas do terreno.",
    ],
    answer: "Avaliação técnica, legal, econômica e ambiental da possibilidade de realização do projeto.",
    difficulty: 2,
  },

  // Nível 3
  {
    id: 36,
    question: "Explique o conceito de patrimônio arquitetônico.",
    options: [
      "São apenas edifícios muito antigos.",
      "São bens culturais edificados que possuem valor histórico, artístico, cultural ou social, merecendo preservação.",
      "São apenas monumentos religiosos.",
      "São edifícios que custaram muito para construir.",
    ],
    answer: "São bens culturais edificados que possuem valor histórico, artístico, cultural ou social, merecendo preservação.",
    difficulty: 3,
  },
  {
    id: 37,
    question: "Qual a importância da iluminação natural na arquitetura hospitalar?",
    options: [
      "Reduzir apenas os custos de energia.",
      "Contribuir para o bem-estar dos pacientes, acelerar a recuperação e melhorar o ambiente de trabalho dos profissionais.",
      "Servir apenas para decoração.",
      "Facilitar apenas a limpeza dos ambientes.",
    ],
    answer: "Contribuir para o bem-estar dos pacientes, acelerar a recuperação e melhorar o ambiente de trabalho dos profissionais.",
    difficulty: 3,
  },
  {
    id: 38,
    question: "Descreva o conceito de densidade urbana e seus tipos.",
    options: [
      "É apenas o número de pessoas por área.",
      "É a relação entre população, edificações e área urbana, podendo ser demográfica (pessoas/área) ou construída (área edificada/área total).",
      "É apenas a altura dos edifícios.",
      "É a quantidade de ruas por bairro.",
    ],
    answer: "É a relação entre população, edificações e área urbana, podendo ser demográfica (pessoas/área) ou construída (área edificada/área total).",
    difficulty: 3,
  },
  {
    id: 39,
    question: "O que é o conceito de lugar na teoria arquitetônica?",
    options: [
      "É apenas a localização geográfica.",
      "É um espaço dotado de significado, identidade e experiências humanas, que vai além das características físicas.",
      "É apenas a área em metros quadrados.",
      "É a distância entre edifícios.",
    ],
    answer: "É um espaço dotado de significado, identidade e experiências humanas, que vai além das características físicas.",
    difficulty: 3,
  },
  {
    id: 40,
    question: "Qual a função dos espaços de transição na arquitetura?",
    options: [
      "Servir apenas como depósito.",
      "Mediar a passagem entre espaços com características diferentes, criando gradações e preparando o usuário para mudanças ambientais.",
      "Funcionar apenas como circulação.",
      "Servir apenas como elemento decorativo.",
    ],
    answer: "Mediar a passagem entre espaços com características diferentes, criando gradações e preparando o usuário para mudanças ambientais.",
    difficulty: 3,
  },

  // Nível 4
  {
    id: 41,
    question: "Discorra sobre a importância da psicologia ambiental na arquitetura.",
    options: [
      "A psicologia ambiental é irrelevante para a arquitetura.",
      "A psicologia ambiental estuda como o ambiente construído influencia o comportamento, emoções e bem-estar humano, orientando decisões de projeto para criar espaços mais adequados às necessidades psicológicas dos usuários.",
      "A psicologia ambiental considera apenas aspectos estéticos.",
      "A psicologia ambiental é apenas para hospitais psiquiátricos.",
    ],
    answer: "A psicologia ambiental estuda como o ambiente construído influencia o comportamento, emoções e bem-estar humano, orientando decisões de projeto para criar espaços mais adequados às necessidades psicológicas dos usuários.",
    difficulty: 4,
  },
  {
    id: 42,
    question: "Explique o conceito de arquitetura inclusiva e suas estratégias.",
    options: [
      "Arquitetura inclusiva é apenas para pessoas com deficiência.",
      "Arquitetura inclusiva projeta espaços acessíveis e utilizáveis por todas as pessoas, independentemente de idade, habilidade ou condição, através do design universal.",
      "Arquitetura inclusiva é apenas para edifícios públicos.",
      "Arquitetura inclusiva ignora aspectos funcionais.",
    ],
    answer: "Arquitetura inclusiva projeta espaços acessíveis e utilizáveis por todas as pessoas, independentemente de idade, habilidade ou condição, através do design universal.",
    difficulty: 4,
  },
  {
    id: 43,
    question: "Qual a função dos sistemas de captação de água da chuva na arquitetura sustentável?",
    options: [
      "Apenas decorar o edifício.",
      "Coletar, armazenar e reutilizar água pluvial para usos não potáveis, reduzindo o consumo de água tratada e contribuindo para a sustentabilidade.",
      "Aumentar o consumo de energia.",
      "Servir apenas para irrigação de jardins.",
    ],
    answer: "Coletar, armazenar e reutilizar água pluvial para usos não potáveis, reduzindo o consumo de água tratada e contribuindo para a sustentabilidade.",
    difficulty: 4,
  },
  {
    id: 44,
    question: "Descreva o conceito de arquitetura efêmera e suas aplicações.",
    options: [
      "É arquitetura que dura para sempre.",
      "É arquitetura temporária, projetada para eventos específicos ou períodos limitados, como pavilhões, instalações e estruturas para festivais.",
      "É arquitetura apenas para museus.",
      "É arquitetura que usa apenas materiais caros.",
    ],
    answer: "É arquitetura temporária, projetada para eventos específicos ou períodos limitados, como pavilhões, instalações e estruturas para festivais.",
    difficulty: 4,
  },
  {
    id: 45,
    question: "Qual a importância da ventilação cruzada em climas tropicais?",
    options: [
      "A ventilação cruzada é importante apenas no inverno.",
      "A ventilação cruzada é fundamental em climas tropicais para promover o resfriamento natural, renovar o ar interno e proporcionar conforto térmico sem uso de climatização artificial.",
      "A ventilação cruzada é usada apenas em edifícios industriais.",
      "A ventilação cruzada não influencia o conforto térmico.",
    ],
    answer: "A ventilação cruzada é fundamental em climas tropicais para promover o resfriamento natural, renovar o ar interno e proporcionar conforto térmico sem uso de climatização artificial.",
    difficulty: 4,
  },

  // Nível 5
  {
    id: 46,
    question: "Aborde o conceito de neuroarquitetura e suas implicações no design.",
    options: [
      "Neuroarquitetura é apenas sobre hospitais neurológicos.",
      "Neuroarquitetura aplica conhecimentos da neurociência para entender como o ambiente construído afeta o cérebro e o comportamento humano, orientando decisões de projeto baseadas em evidências científicas.",
      "Neuroarquitetura considera apenas aspectos visuais.",
      "Neuroarquitetura é irrelevante para o design.",
    ],
    answer: "Neuroarquitetura aplica conhecimentos da neurociência para entender como o ambiente construído afeta o cérebro e o comportamento humano, orientando decisões de projeto baseadas em evidências científicas.",
    difficulty: 5,
  },
  {
    id: 47,
    question: "Explique a diferença entre espaço e lugar na fenomenologia arquitetônica.",
    options: [
      "Espaço e lugar são conceitos idênticos.",
      "Espaço refere-se às dimensões físicas e geométricas, enquanto lugar incorpora significados, experiências e vínculos emocionais que os usuários desenvolvem com o espaço.",
      "Espaço é sempre maior que lugar.",
      "Lugar existe apenas em ambientes externos.",
    ],
    answer: "Espaço refere-se às dimensões físicas e geométricas, enquanto lugar incorpora significados, experiências e vínculos emocionais que os usuários desenvolvem com o espaço.",
    difficulty: 5,
  },
  {
    id: 48,
    question: "Discorra sobre os desafios da arquitetura em contextos de mudanças climáticas.",
    options: [
      "Mudanças climáticas não afetam a arquitetura.",
      "A arquitetura deve adaptar-se às mudanças climáticas através de estratégias de resiliência, eficiência energética, uso de materiais sustentáveis e design bioclimático para enfrentar eventos extremos e reduzir emissões.",
      "Apenas edifícios costeiros são afetados.",
      "A solução é construir apenas em ambientes controlados.",
    ],
    answer: "A arquitetura deve adaptar-se às mudanças climáticas através de estratégias de resiliência, eficiência energética, uso de materiais sustentáveis e design bioclimático para enfrentar eventos extremos e reduzir emissões.",
    difficulty: 5,
  },
  {
    id: 49,
    question: "Qual a importância da co-criação e participação comunitária no processo de projeto?",
    options: [
      "Participação comunitária apenas atrasa os projetos.",
      "A co-criação e participação comunitária garantem que os projetos atendam às reais necessidades dos usuários, promovam apropriação social e resultem em soluções mais adequadas e sustentáveis.",
      "Participação é necessária apenas em projetos públicos.",
      "Arquitetos devem projetar sem consultar usuários.",
    ],
    answer: "A co-criação e participação comunitária garantem que os projetos atendam às reais necessidades dos usuários, promovam apropriação social e resultem em soluções mais adequadas e sustentáveis.",
    difficulty: 5,
  },
  {
    id: 50,
    question: "Explique o conceito de arquitetura responsiva e suas tecnologias emergentes.",
    options: [
      "Arquitetura responsiva é apenas sobre responsabilidade social.",
      "Arquitetura responsiva utiliza tecnologias como sensores, materiais inteligentes e sistemas automatizados para adaptar-se dinamicamente às condições ambientais e necessidades dos usuários em tempo real.",
      "Arquitetura responsiva é apenas para edifícios comerciais.",
      "Arquitetura responsiva ignora aspectos tecnológicos.",
    ],
    answer: "Arquitetura responsiva utiliza tecnologias como sensores, materiais inteligentes e sistemas automatizados para adaptar-se dinamicamente às condições ambientais e necessidades dos usuários em tempo real.",
    difficulty: 5,
  },
];



// Perguntas de Engenharia Mecânica
const mecanicaQuizData = [
  // Nível 1: Perguntas básicas
  {
    id: 1,
    question: "Qual a principal função de um motor de combustão interna?",
    options: [
      "Gerar energia elétrica",
      "Converter energia química em energia mecânica",
      "Resfriar o sistema",
      "Filtrar combustível",
    ],
    answer: "Converter energia química em energia mecânica",
    difficulty: 1,
  },
  {
    id: 2,
    question: "O que é a primeira lei da termodinâmica?",
    options: [
      "Lei da conservação da massa",
      "Lei da conservação da energia",
      "Lei da conservação do momento",
      "Lei da conservação da temperatura",
    ],
    answer: "Lei da conservação da energia",
    difficulty: 1,
  },
  {
    id: 3,
    question: "Qual instrumento é usado para medir pressão em sistemas mecânicos?",
    options: [
      "Termômetro",
      "Manômetro",
      "Voltímetro",
      "Amperímetro",
    ],
    answer: "Manômetro",
    difficulty: 1,
  },
  {
    id: 4,
    question: "O que significa a sigla CAD na engenharia mecânica?",
    options: [
      "Controle Automático de Dados",
      "Cálculo Auxiliado por Dispositivos",
      "Desenho Auxiliado por Computador",
      "Comando Automático de Dispositivos",
    ],
    answer: "Desenho Auxiliado por Computador",
    difficulty: 1,
  },
  {
    id: 5,
    question: "Qual o tipo de transmissão mais comum em veículos automotivos?",
    options: [
      "Correia",
      "Corrente",
      "Engrenagens",
      "Cabo",
    ],
    answer: "Engrenagens",
    difficulty: 1,
  },

  // Nível 2: Perguntas de dificuldade média
  {
    id: 6,
    question: "Em sistemas hidráulicos, qual a função principal do fluido?",
    options: [
      "Apenas lubrificar componentes",
      "Transmitir potência através da pressão",
      "Resfriar o sistema",
      "Limpar os componentes",
    ],
    answer: "Transmitir potência através da pressão",
    difficulty: 2,
  },
  {
    id: 7,
    question: "O que é o coeficiente de atrito?",
    options: [
      "A relação entre força normal e força de atrito",
      "A velocidade de deslizamento entre superfícies",
      "A temperatura gerada pelo atrito",
      "A área de contato entre superfícies",
    ],
    answer: "A relação entre força normal e força de atrito",
    difficulty: 2,
  },
  {
    id: 8,
    question: "Qual a finalidade do tratamento térmico em metais?",
    options: [
      "Apenas aumentar a temperatura",
      "Modificar as propriedades mecânicas do material",
      "Reduzir o peso do material",
      "Mudar a cor do material",
    ],
    answer: "Modificar as propriedades mecânicas do material",
    difficulty: 2,
  },
  {
    id: 9,
    question: "O que é um diagrama de corpo livre na mecânica?",
    options: [
      "Um esquema de montagem",
      "Uma representação de um objeto isolado com todas as forças atuantes",
      "Um gráfico de velocidade",
      "Um desenho técnico detalhado",
    ],
    answer: "Uma representação de um objeto isolado com todas as forças atuantes",
    difficulty: 2,
  },
  {
    id: 10,
    question: "Qual a importância da lubrificação em máquinas?",
    options: [
      "Apenas limpar os componentes",
      "Reduzir o atrito, desgaste e aquecimento entre superfícies móveis",
      "Aumentar a velocidade de operação",
      "Melhorar a aparência da máquina",
    ],
    answer: "Reduzir o atrito, desgaste e aquecimento entre superfícies móveis",
    difficulty: 2,
  },

  // Nível 3: Perguntas avançadas
  {
    id: 11,
    question: "Explique o conceito de fadiga em materiais.",
    options: [
      "É a resistência inicial do material.",
      "É a falha do material devido a carregamentos cíclicos repetidos, mesmo abaixo do limite de escoamento.",
      "É a capacidade de absorver energia.",
      "É a deformação permanente do material.",
    ],
    answer: "É a falha do material devido a carregamentos cíclicos repetidos, mesmo abaixo do limite de escoamento.",
    difficulty: 3,
  },
  {
    id: 12,
    question: "Qual a diferença entre motor 2 tempos e 4 tempos?",
    options: [
      "2 tempos é elétrico e 4 tempos é a combustão.",
      "2 tempos completa o ciclo em duas voltas do virabrequim, 4 tempos em quatro voltas.",
      "2 tempos usa gasolina e 4 tempos usa diesel.",
      "Não há diferença significativa.",
    ],
    answer: "2 tempos completa o ciclo em duas voltas do virabrequim, 4 tempos em quatro voltas.",
    difficulty: 3,
  },
  {
    id: 13,
    question: "Descreva o processo de usinagem por torneamento.",
    options: [
      "É a soldagem de peças metálicas.",
      "É a remoção de material através da rotação da peça e avanço da ferramenta de corte.",
      "É o aquecimento de metais.",
      "É a montagem de componentes.",
    ],
    answer: "É a remoção de material através da rotação da peça e avanço da ferramenta de corte.",
    difficulty: 3,
  },
  {
    id: 14,
    question: "O que é análise modal em sistemas mecânicos?",
    options: [
      "É a análise de custos de produção.",
      "É o estudo das frequências naturais e modos de vibração de uma estrutura ou sistema.",
      "É a análise de materiais.",
      "É o estudo de fluxos de fluidos.",
    ],
    answer: "É o estudo das frequências naturais e modos de vibração de uma estrutura ou sistema.",
    difficulty: 3,
  },
  {
    id: 15,
    question: "Qual a função dos rolamentos em máquinas rotativas?",
    options: [
      "Aumentar a velocidade de rotação.",
      "Reduzir o atrito e suportar cargas radiais e axiais em eixos rotativos.",
      "Gerar energia elétrica.",
      "Controlar a temperatura do sistema.",
    ],
    answer: "Reduzir o atrito e suportar cargas radiais e axiais em eixos rotativos.",
    difficulty: 3,
  },

  // Nível 4: Perguntas mais avançadas
  {
    id: 16,
    question: "Explique o fenômeno de ressonância em sistemas mecânicos.",
    options: [
      "É o aumento da resistência do material.",
      "É a amplificação das vibrações quando a frequência de excitação coincide com a frequência natural do sistema.",
      "É a redução da velocidade de operação.",
      "É o aquecimento excessivo do sistema.",
    ],
    answer: "É a amplificação das vibrações quando a frequência de excitação coincide com a frequência natural do sistema.",
    difficulty: 4,
  },
  {
    id: 17,
    question: "O que é o ciclo de Carnot e sua importância?",
    options: [
      "É um ciclo de produção industrial.",
      "É um ciclo termodinâmico teórico que representa a máxima eficiência possível entre duas fontes térmicas.",
      "É um ciclo de manutenção de máquinas.",
      "É um ciclo de resfriamento de motores.",
    ],
    answer: "É um ciclo termodinâmico teórico que representa a máxima eficiência possível entre duas fontes térmicas.",
    difficulty: 4,
  },
  {
    id: 18,
    question: "Descreva o conceito de concentração de tensões em componentes mecânicos.",
    options: [
      "É a distribuição uniforme de tensões.",
      "É o aumento localizado de tensões em regiões com mudanças geométricas bruscas, como furos, entalhes e cantos vivos.",
      "É a redução de tensões em toda a peça.",
      "É a tensão média em um componente.",
    ],
    answer: "É o aumento localizado de tensões em regiões com mudanças geométricas bruscas, como furos, entalhes e cantos vivos.",
    difficulty: 4,
  },
  {
    id: 19,
    question: "Qual a importância da análise de elementos finitos (FEA) na engenharia mecânica?",
    options: [
      "Apenas para desenhos técnicos.",
      "Permite simular e analisar o comportamento de componentes e sistemas sob diferentes condições de carregamento, otimizando projetos.",
      "Apenas para cálculos manuais.",
      "Apenas para análise de custos.",
    ],
    answer: "Permite simular e analisar o comportamento de componentes e sistemas sob diferentes condições de carregamento, otimizando projetos.",
    difficulty: 4,
  },
  {
    id: 20,
    question: "Diferencie soldagem MIG/MAG de soldagem TIG.",
    options: [
      "MIG/MAG usa eletrodo consumível e TIG usa eletrodo não consumível.",
      "MIG/MAG é apenas para alumínio e TIG apenas para aço.",
      "MIG/MAG é mais lenta que TIG.",
      "Não há diferença entre os processos.",
    ],
    answer: "MIG/MAG usa eletrodo consumível e TIG usa eletrodo não consumível.",
    difficulty: 4,
  },

  // Nível 5: Perguntas de alta dificuldade
  {
    id: 21,
    question: "Discorra sobre a mecânica da fratura e sua aplicação em projetos.",
    options: [
      "Mecânica da fratura estuda apenas fraturas ósseas.",
      "Mecânica da fratura analisa o comportamento de materiais com trincas, determinando condições para propagação de fissuras e vida útil de componentes.",
      "Mecânica da fratura é apenas para materiais cerâmicos.",
      "Mecânica da fratura ignora aspectos de segurança.",
    ],
    answer: "Mecânica da fratura analisa o comportamento de materiais com trincas, determinando condições para propagação de fissuras e vida útil de componentes.",
    difficulty: 5,
  },
  {
    id: 22,
    question: "Explique a teoria da elasticidade aplicada a componentes mecânicos.",
    options: [
      "A teoria da elasticidade considera apenas deformações permanentes.",
      "A teoria da elasticidade estuda o comportamento de materiais que retornam à forma original após remoção da carga, estabelecendo relações entre tensões e deformações.",
      "É uma teoria que se aplica apenas a borrachas.",
      "A teoria da elasticidade ignora as propriedades dos materiais.",
    ],
    answer: "A teoria da elasticidade estuda o comportamento de materiais que retornam à forma original após remoção da carga, estabelecendo relações entre tensões e deformações.",
    difficulty: 5,
  },
  {
    id: 23,
    question: "Qual a importância da tribologia na engenharia mecânica?",
    options: [
      "Tribologia estuda apenas a cor dos materiais.",
      "Tribologia é a ciência que estuda atrito, desgaste e lubrificação, fundamental para projeto de componentes em contato e sistemas de transmissão.",
      "É apenas para análise de custos.",
      "Tribologia considera apenas aspectos estéticos.",
    ],
    answer: "Tribologia é a ciência que estuda atrito, desgaste e lubrificação, fundamental para projeto de componentes em contato e sistemas de transmissão.",
    difficulty: 5,
  },
  {
    id: 24,
    question: "Descreva os princípios da manufatura aditiva (impressão 3D) em metais.",
    options: [
      "Manufatura aditiva apenas remove material.",
      "Manufatura aditiva constrói peças camada por camada através de fusão seletiva de pó metálico, permitindo geometrias complexas e customização.",
      "É apenas para materiais plásticos.",
      "Manufatura aditiva é apenas para prototipagem.",
    ],
    answer: "Manufatura aditiva constrói peças camada por camada através de fusão seletiva de pó metálico, permitindo geometrias complexas e customização.",
    difficulty: 5,
  },
  {
    id: 25,
    question: "Aborde o conceito de manutenção preditiva em sistemas mecânicos.",
    options: [
      "Manutenção preditiva é feita apenas após falhas.",
      "Manutenção preditiva usa monitoramento contínuo e análise de dados para prever falhas antes que ocorram, otimizando disponibilidade e custos.",
      "É apenas para máquinas antigas.",
      "Manutenção preditiva ignora aspectos tecnológicos.",
    ],
    answer: "Manutenção preditiva usa monitoramento contínuo e análise de dados para prever falhas antes que ocorram, otimizando disponibilidade e custos.",
    difficulty: 5,
  },

  // Adicionar mais 25 perguntas para completar 50
  // Nível 1
  {
    id: 26,
    question: "Qual o principal combustível usado em motores diesel?",
    options: [
      "Gasolina",
      "Etanol",
      "Óleo diesel",
      "Gás natural",
    ],
    answer: "Óleo diesel",
    difficulty: 1,
  },
  {
    id: 27,
    question: "O que é torque em mecânica?",
    options: [
      "Uma força linear",
      "Um momento de força que causa rotação",
      "Uma velocidade angular",
      "Uma aceleração linear",
    ],
    answer: "Um momento de força que causa rotação",
    difficulty: 1,
  },
  {
    id: 28,
    question: "Qual a unidade de medida de potência no Sistema Internacional?",
    options: [
      "Joule",
      "Watt",
      "Newton",
      "Pascal",
    ],
    answer: "Watt",
    difficulty: 1,
  },
  {
    id: 29,
    question: "O que é um pistão em motores?",
    options: [
      "Uma válvula de controle",
      "Um componente que se move no cilindro transmitindo força",
      "Um sistema de refrigeração",
      "Um filtro de combustível",
    ],
    answer: "Um componente que se move no cilindro transmitindo força",
    difficulty: 1,
  },
  {
    id: 30,
    question: "Qual a função principal de um radiador automotivo?",
    options: [
      "Filtrar o ar",
      "Resfriar o motor através da troca de calor",
      "Gerar energia elétrica",
      "Comprimir o combustível",
    ],
    answer: "Resfriar o motor através da troca de calor",
    difficulty: 1,
  },

  // Nível 2
  {
    id: 31,
    question: "Em sistemas pneumáticos, qual gás é mais comumente usado?",
    options: [
      "Oxigênio",
      "Ar comprimido",
      "Nitrogênio puro",
      "Dióxido de carbono",
    ],
    answer: "Ar comprimido",
    difficulty: 2,
  },
  {
    id: 32,
    question: "Qual a diferença entre tensão e deformação?",
    options: [
      "Tensão é força por área e deformação é mudança dimensional relativa.",
      "Tensão é temperatura e deformação é pressão.",
      "Tensão é velocidade e deformação é aceleração.",
      "Não há diferença entre os conceitos.",
    ],
    answer: "Tensão é força por área e deformação é mudança dimensional relativa.",
    difficulty: 2,
  },
  {
    id: 33,
    question: "O que é um acoplamento em sistemas mecânicos?",
    options: [
      "Um tipo de combustível.",
      "Um dispositivo que conecta dois eixos para transmitir movimento.",
      "Um sistema de freios.",
      "Um tipo de lubrificante.",
    ],
    answer: "Um dispositivo que conecta dois eixos para transmitir movimento.",
    difficulty: 2,
  },
  {
    id: 34,
    question: "Qual a função de uma embreagem em veículos?",
    options: [
      "Acelerar o motor.",
      "Conectar e desconectar o motor da transmissão.",
      "Resfriar o sistema.",
      "Filtrar o combustível.",
    ],
    answer: "Conectar e desconectar o motor da transmissão.",
    difficulty: 2,
  },
  {
    id: 35,
    question: "O que é um ensaio de tração em materiais?",
    options: [
      "Teste de temperatura do material.",
      "Teste que determina propriedades mecânicas através da aplicação de força de tração.",
      "Teste de condutividade elétrica.",
      "Teste de cor do material.",
    ],
    answer: "Teste que determina propriedades mecânicas através da aplicação de força de tração.",
    difficulty: 2,
  },

  // Nível 3
  {
    id: 36,
    question: "Explique o conceito de eficiência térmica em motores.",
    options: [
      "É apenas a temperatura de operação.",
      "É a relação entre o trabalho útil produzido e a energia térmica fornecida ao motor.",
      "É a velocidade máxima do motor.",
      "É o consumo de combustível por hora.",
    ],
    answer: "É a relação entre o trabalho útil produzido e a energia térmica fornecida ao motor.",
    difficulty: 3,
  },
  {
    id: 37,
    question: "Qual a importância do balanceamento em máquinas rotativas?",
    options: [
      "Apenas para reduzir ruído.",
      "Reduzir vibrações, aumentar vida útil dos componentes e melhorar a performance.",
      "Apenas para economia de energia.",
      "Apenas para aspectos estéticos.",
    ],
    answer: "Reduzir vibrações, aumentar vida útil dos componentes e melhorar a performance.",
    difficulty: 3,
  },
  {
    id: 38,
    question: "Descreva o processo de forjamento de metais.",
    options: [
      "É a fusão de metais.",
      "É a conformação de metais através de aplicação de força compressiva, geralmente a quente.",
      "É a soldagem de peças.",
      "É o resfriamento rápido de metais.",
    ],
    answer: "É a conformação de metais através de aplicação de força compressiva, geralmente a quente.",
    difficulty: 3,
  },
  {
    id: 39,
    question: "O que é cavitação em bombas hidráulicas?",
    options: [
      "É o aumento da pressão.",
      "É a formação e colapso de bolhas de vapor que podem danificar componentes.",
      "É o aquecimento do fluido.",
      "É a redução da velocidade de rotação.",
    ],
    answer: "É a formação e colapso de bolhas de vapor que podem danificar componentes.",
    difficulty: 3,
  },
  {
    id: 40,
    question: "Qual a função dos amortecedores em sistemas de suspensão?",
    options: [
      "Apenas suportar o peso do veículo.",
      "Controlar as oscilações das molas e proporcionar estabilidade e conforto.",
      "Apenas melhorar a aparência.",
      "Apenas reduzir o consumo de combustível.",
    ],
    answer: "Controlar as oscilações das molas e proporcionar estabilidade e conforto.",
    difficulty: 3,
  },

  // Nível 4
  {
    id: 41,
    question: "Discorra sobre a importância da análise de vibrações em máquinas industriais.",
    options: [
      "Análise de vibrações é irrelevante.",
      "A análise de vibrações permite detectar problemas mecânicos precocemente, otimizar manutenção e evitar falhas catastróficas.",
      "É apenas para máquinas antigas.",
      "Análise de vibrações aumenta o consumo de energia.",
    ],
    answer: "A análise de vibrações permite detectar problemas mecânicos precocemente, otimizar manutenção e evitar falhas catastróficas.",
    difficulty: 4,
  },
  {
    id: 42,
    question: "Explique o conceito de fluência em materiais metálicos.",
    options: [
      "Fluência é apenas para líquidos.",
      "Fluência é a deformação lenta e contínua de materiais sob tensão constante, especialmente em altas temperaturas.",
      "Fluência é apenas para polímeros.",
      "Fluência é o mesmo que elasticidade.",
    ],
    answer: "Fluência é a deformação lenta e contínua de materiais sob tensão constante, especialmente em altas temperaturas.",
    difficulty: 4,
  },
  {
    id: 43,
    question: "Qual a função dos sistemas de controle PID em automação?",
    options: [
      "Apenas ligar e desligar equipamentos.",
      "Controlar variáveis de processo através de ações proporcional, integral e derivativa para manter setpoints.",
      "Apenas monitorar temperatura.",
      "Apenas controlar velocidade.",
    ],
    answer: "Controlar variáveis de processo através de ações proporcional, integral e derivativa para manter setpoints.",
    difficulty: 4,
  },
  {
    id: 44,
    question: "Descreva o conceito de manufatura enxuta (lean manufacturing).",
    options: [
      "É apenas redução de pessoal.",
      "É uma filosofia de produção focada na eliminação de desperdícios e otimização de processos para agregar valor ao cliente.",
      "É apenas para indústrias automotivas.",
      "É apenas redução de custos.",
    ],
    answer: "É uma filosofia de produção focada na eliminação de desperdícios e otimização de processos para agregar valor ao cliente.",
    difficulty: 4,
  },
  {
    id: 45,
    question: "Qual a importância da análise de confiabilidade em sistemas mecânicos?",
    options: [
      "Confiabilidade é apenas para eletrônicos.",
      "A análise de confiabilidade estuda a probabilidade de um sistema funcionar adequadamente durante um período específico, orientando projetos e manutenção.",
      "É apenas para sistemas simples.",
      "Confiabilidade não influencia custos.",
    ],
    answer: "A análise de confiabilidade estuda a probabilidade de um sistema funcionar adequadamente durante um período específico, orientando projetos e manutenção.",
    difficulty: 4,
  },

  // Nível 5
  {
    id: 46,
    question: "Aborde o conceito de otimização topológica em projetos mecânicos.",
    options: [
      "Otimização topológica é apenas para mapas.",
      "Otimização topológica é um método computacional que determina a distribuição ótima de material em um domínio para maximizar performance estrutural.",
      "É apenas para análise de custos.",
      "Otimização topológica ignora aspectos estruturais.",
    ],
    answer: "Otimização topológica é um método computacional que determina a distribuição ótima de material em um domínio para maximizar performance estrutural.",
    difficulty: 5,
  },
  {
    id: 47,
    question: "Explique a diferença entre análise linear e não-linear em mecânica.",
    options: [
      "Análise linear considera grandes deformações e não-linear pequenas.",
      "Análise linear assume proporcionalidade entre cargas e deslocamentos, enquanto não-linear considera efeitos como grandes deformações e não-linearidades do material.",
      "Análise linear é mais complexa que não-linear.",
      "Não há diferença prática entre elas.",
    ],
    answer: "Análise linear assume proporcionalidade entre cargas e deslocamentos, enquanto não-linear considera efeitos como grandes deformações e não-linearidades do material.",
    difficulty: 5,
  },
  {
    id: 48,
    question: "Discorra sobre os desafios da engenharia mecânica na era da Indústria 4.0.",
    options: [
      "Indústria 4.0 não afeta a engenharia mecânica.",
      "A Indústria 4.0 traz desafios como integração de IoT, manufatura inteligente, manutenção preditiva e sistemas ciber-físicos, exigindo novas competências.",
      "Apenas sistemas elétricos são afetados.",
      "A solução é ignorar novas tecnologias.",
    ],
    answer: "A Indústria 4.0 traz desafios como integração de IoT, manufatura inteligente, manutenção preditiva e sistemas ciber-físicos, exigindo novas competências.",
    difficulty: 5,
  },
  {
    id: 49,
    question: "Qual a importância da simulação multifísica em projetos complexos?",
    options: [
      "Simulação multifísica é apenas para pesquisa acadêmica.",
      "A simulação multifísica permite analisar interações entre diferentes fenômenos físicos (térmico, estrutural, fluídico) simultaneamente, otimizando projetos complexos.",
      "É apenas para sistemas simples.",
      "Simulação multifísica é apenas teórica.",
    ],
    answer: "A simulação multifísica permite analisar interações entre diferentes fenômenos físicos (térmico, estrutural, fluídico) simultaneamente, otimizando projetos complexos.",
    difficulty: 5,
  },
  {
    id: 50,
    question: "Explique o conceito de gêmeos digitais (digital twins) na engenharia mecânica.",
    options: [
      "Gêmeos digitais são apenas cópias de arquivos.",
      "Gêmeos digitais são réplicas virtuais de sistemas físicos que permitem monitoramento em tempo real, simulação e otimização de performance.",
      "É apenas para sistemas de software.",
      "Gêmeos digitais são apenas para visualização.",
    ],
    answer: "Gêmeos digitais são réplicas virtuais de sistemas físicos que permitem monitoramento em tempo real, simulação e otimização de performance.",
    difficulty: 5,
  },
];


// Perguntas de Engenharia Elétrica (versão resumida - 10 perguntas como exemplo)
const eletricaQuizData = [
  {
    id: 1,
    question: "Qual a lei fundamental que relaciona tensão, corrente e resistência?",
    options: ["Lei de Faraday", "Lei de Ohm", "Lei de Kirchhoff", "Lei de Lenz"],
    answer: "Lei de Ohm",
    difficulty: 1,
  },
  {
    id: 2,
    question: "O que é corrente alternada (CA)?",
    options: [
      "Corrente que flui sempre no mesmo sentido",
      "Corrente que muda de sentido periodicamente",
      "Corrente de alta tensão",
      "Corrente de baixa tensão"
    ],
    answer: "Corrente que muda de sentido periodicamente",
    difficulty: 1,
  },
  // ... (mais 48 perguntas seguindo o mesmo padrão)
];

// Perguntas de Engenharia de Produção (versão resumida)
const producaoQuizData = [
  {
    id: 1,
    question: "O que é o conceito de Just-in-Time (JIT)?",
    options: [
      "Produzir grandes lotes",
      "Produzir apenas o necessário, quando necessário",
      "Produzir com antecedência",
      "Produzir sem planejamento"
    ],
    answer: "Produzir apenas o necessário, quando necessário",
    difficulty: 1,
  },
  // ... (mais 49 perguntas)
];

// Perguntas de Engenharia de Software (versão resumida)
const softwareQuizData = [
  {
    id: 1,
    question: "O que é um algoritmo?",
    options: [
      "Um tipo de linguagem de programação",
      "Uma sequência de instruções para resolver um problema",
      "Um software específico",
      "Um tipo de hardware"
    ],
    answer: "Uma sequência de instruções para resolver um problema",
    difficulty: 1,
  },
  // ... (mais 49 perguntas)
];

// Perguntas de Engenharia Química (versão resumida)
const quimicaQuizData = [
  {
    id: 1,
    question: "O que é um processo de destilação?",
    options: [
      "Mistura de líquidos",
      "Separação de componentes baseada em diferentes pontos de ebulição",
      "Aquecimento de sólidos",
      "Resfriamento de gases"
    ],
    answer: "Separação de componentes baseada em diferentes pontos de ebulição",
    difficulty: 1,
  },
  // ... (mais 49 perguntas)
];

// Função para obter dados do quiz baseado no tipo
export const getQuizData = (quizType) => {
  switch (quizType) {
    case 'civil':
      return civilQuizData;
    case 'arquitetura':
      return arquiteturaQuizData;
    case 'mecanica':
      return mecanicaQuizData;
    case 'eletrica':
      return eletricaQuizData;
    case 'producao':
      return producaoQuizData;
    case 'software':
      return softwareQuizData;
    case 'quimica':
      return quimicaQuizData;
    default:
      return civilQuizData;
  }
};

// Função para obter o título do quiz
export const getQuizTitle = (quizType) => {
  switch (quizType) {
    case 'civil':
      return 'Quiz de Engenharia Civil';
    case 'arquitetura':
      return 'Quiz de Arquitetura';
    case 'mecanica':
      return 'Quiz de Engenharia Mecânica';
    case 'eletrica':
      return 'Quiz de Engenharia Elétrica';
    case 'producao':
      return 'Quiz de Engenharia de Produção';
    case 'software':
      return 'Quiz de Engenharia de Software';
    case 'quimica':
      return 'Quiz de Engenharia Química';
    default:
      return 'Quiz de Engenharia';
  }
};

// Exportação padrão para compatibilidade
export default civilQuizData;



import os
import re

def get_all_files(directory, extensions):
    file_list = []
    for root, _, files in os.walk(directory):
        for file in files:
            if any(file.endswith(ext) for ext in extensions):
                file_list.append(os.path.join(root, file))
    return file_list

def analyze_imports(file_path):
    imports = set()
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
        # Regex para importações de componentes e módulos
        # Ex: import { Button } from '@/components/ui/button.jsx'
        # Ex: import CronogramaOrcamento from './components/CronogramaOrcamentoModificado.jsx'
        # Ex: import './App.css'
        # Ex: import normasBg from './assets/normas-bg.webp'
        matches = re.findall(r"from ['\"](.*?)['\"]", content)
        for match in matches:
            # Tratar aliases como @/
            if match.startswith('@/'):
                match = match.replace('@/', 'src/')
            imports.add(match)
        
        # Regex para referências a imagens e outros assets dentro do código (ex: `url(${func.bgImage})`)
        # Isso é mais complexo e pode exigir análise mais profunda do JSX/JS
        # Por enquanto, vamos focar nas importações diretas e adicionar uma observação sobre isso no relatório.
        
    return imports

def resolve_import_path(importer_path, imported_path):
    # Remove a extensão se houver
    imported_path_no_ext = re.sub(r'\.(jsx|js|css|webp|jpg|png)$', '', imported_path)
    
    # Se for um caminho relativo, resolve-o
    if imported_path_no_ext.startswith('.'):
        base_dir = os.path.dirname(importer_path)
        resolved_path = os.path.abspath(os.path.join(base_dir, imported_path_no_ext))
    else:
        # Para caminhos absolutos ou aliases já resolvidos (ex: src/components/ui/button)
        resolved_path = os.path.abspath(os.path.join('/home/ubuntu/site', imported_path_no_ext))

    # Tentar adicionar extensões comuns se o arquivo não for encontrado diretamente
    possible_paths = [
        resolved_path + '.jsx',
        resolved_path + '.js',
        resolved_path + '.css',
        resolved_path + '.webp',
        resolved_path + '.jpg',
        resolved_path + '.png',
        resolved_path + '/index.jsx',
        resolved_path + '/index.js',
    ]
    
    for p in possible_paths:
        if os.path.exists(p):
            return p
    
    # Se não encontrou com extensões, retorna o caminho original (pode ser um módulo de node_modules)
    return resolved_path


def main():
    project_root = '/home/ubuntu/site'
    src_dir = os.path.join(project_root, 'src')
    
    js_jsx_files = get_all_files(src_dir, ('.js', '.jsx'))
    css_files = get_all_files(src_dir, ('.css',))
    image_files = get_all_files(src_dir, ('.png', '.jpg', '.jpeg', '.gif', '.svg', '.webp'))

    all_project_files = set(js_jsx_files + css_files + image_files)
    
    # Arquivos que são pontos de entrada
    entry_points = [
        os.path.join(src_dir, 'main.jsx'),
        os.path.join(src_dir, 'App.jsx')
    ]

    # Mapear todas as importações
    imported_files = set()
    for file_path in js_jsx_files:
        imports = analyze_imports(file_path)
        for imp in imports:
            resolved = resolve_import_path(file_path, imp)
            if resolved and os.path.exists(resolved):
                imported_files.add(resolved)
            elif 'node_modules' not in imp: # Ignorar módulos de node_modules por enquanto
                # print(f"Could not resolve import: {imp} from {file_path}")
                pass

    # Adicionar arquivos CSS e de imagem referenciados diretamente no App.jsx
    # Esta parte é manual e baseada na análise do App.jsx que fiz anteriormente
    # Em um sistema mais robusto, isso seria feito por uma análise de AST ou regex mais complexa
    app_jsx_content = open(os.path.join(src_dir, 'App.jsx'), 'r', encoding='utf-8').read()
    
    # Regex para imagens importadas diretamente
    image_imports = re.findall(r"import .* from ['\"]\./assets/(.*?)['\"]", app_jsx_content)
    for img_imp in image_imports:
        # Tentar resolver o caminho completo da imagem
        resolved_img_path = resolve_import_path(os.path.join(src_dir, 'App.jsx'), f'./assets/{img_imp}')
        if resolved_img_path and os.path.exists(resolved_img_path):
            imported_files.add(resolved_img_path)

    # Adicionar o App.css
    imported_files.add(os.path.join(src_dir, 'App.css'))
    imported_files.add(os.path.join(src_dir, 'index.css'))

    # Incluir todos os arquivos que são pontos de entrada
    for ep in entry_points:
        if os.path.exists(ep):
            imported_files.add(ep)

    # Identificar arquivos não utilizados
    unused_files = []
    for file in all_project_files:
        if file not in imported_files and file not in entry_points:
            unused_files.append(file)

    # Gerar relatório
    report_path = '/home/ubuntu/site/arquivos_nao_utilizados.txt'
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write("Relatório de Arquivos Não Utilizados\n")
        f.write("=====================================\n\n")
        f.write("Os seguintes arquivos e componentes não foram encontrados como importações diretas ou referências em outros arquivos do projeto (main.jsx, App.jsx e componentes importados):\n\n")
        if unused_files:
            for uf in unused_files:
                f.write(f"- {uf}\n")
        else:
            f.write("Nenhum arquivo não utilizado encontrado com base na análise de importações.\n")
        f.write("\nObservação: Esta análise foca em importações diretas e referências explícitas. Arquivos referenciados dinamicamente (ex: por strings em código JavaScript) ou que são carregados de outras formas (ex: via HTML diretamente sem importação JS/JSX) podem não ser detectados. Além disso, arquivos de configuração ou de teste que não são parte do bundle final também não são considerados 'não utilizados' por esta análise.\n")

    print(f"Relatório gerado em: {report_path}")

if __name__ == '__main__':
    main()



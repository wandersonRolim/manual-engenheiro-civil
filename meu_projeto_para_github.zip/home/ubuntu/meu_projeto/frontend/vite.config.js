import { fileURLToPath } from 'url'
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import path from 'path'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(fileURLToPath(new URL('.', import.meta.url)), "./src"),
    },
  },
  server: {
    host: true,
    port: 5174,
    strictPort: false,
    cors: true,
    hmr: {
      port: 5174
    },
    fs: {
      strict: false,
      allow: ["/home/ubuntu/site/home/ubuntu/server_files"]
    },
    allowedHosts: ["*"],
  },
})


